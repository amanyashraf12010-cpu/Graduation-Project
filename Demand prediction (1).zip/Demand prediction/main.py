import os
from datetime import date
from datetime import datetime, timedelta
from typing import Optional, List, Dict, Any
import traceback
from zoneinfo import ZoneInfo

from dotenv import load_dotenv
import pandas as pd
from fastapi import FastAPI, HTTPException, Request, Header
from fastapi.responses import JSONResponse, FileResponse
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from sklearn.linear_model import LinearRegression, LogisticRegression
from sklearn.preprocessing import LabelEncoder, StandardScaler

# مهم: override=True عشان يقرأ القيم الجديدة من .env
load_dotenv(override=True)

print("NEW MAIN FILE RUNNING")

APP_TZ = ZoneInfo(os.getenv("APP_TZ", "Africa/Cairo"))


def app_today() -> date:
    return datetime.now(APP_TZ).date()


app = FastAPI(
    title="Demand Prediction API",
    description="Predict orders, visitors, and demand level using Supabase + Egypt calendar Excel",
    version="3.1.0"
)


app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# =========================
# Globals
# =========================
REG_MODEL = None
CLS_MODEL = None
LABEL_ENCODER = None
SCALER = None

SUPABASE = None
ORDERS_DAILY = None
CALENDAR_DF = None
CALENDAR_SOURCE = "unknown"
STARTUP_ERRORS = {"supabase": None, "calendar": None, "training": None}

INTERNAL_KEY = os.getenv("DEMAND_INTERNAL_API_KEY", "")
SUPABASE_URL = os.getenv("SUPABASE_URL", "")
SUPABASE_KEY = os.getenv("SUPABASE_KEY", "")
ORDER_CONVERSION_FACTOR = float(os.getenv("ORDER_CONVERSION_FACTOR", "0.60"))
TRAIN_DAYS_BACK = int(os.getenv("TRAIN_DAYS_BACK", "180") or "180")

FEATURES = [
    "day_of_week_num",
    "is_weekend",
    "holiday_flg",
    "is_ramadan",
    "lag_7",
    "rolling_mean_7",
]

DAY_NAMES_AR = {
    "Monday": "الاثنين",
    "Tuesday": "الثلاثاء",
    "Wednesday": "الأربعاء",
    "Thursday": "الخميس",
    "Friday": "الجمعة",
    "Saturday": "السبت",
    "Sunday": "الأحد",
}

# ترقيم الأيام بنفس منطق التقويم المصري (السبت=1 .. الجمعة=7)
_DAY_NUM_MAP = {
    "Saturday": 1, "Sunday": 2, "Monday": 3,
    "Tuesday": 4, "Wednesday": 5, "Thursday": 6, "Friday": 7,
}
# نهاية الأسبوع في مصر = الجمعة والسبت
_IS_WEEKEND_MAP = {"Friday": 1, "Saturday": 1}


class PredictionInput(BaseModel):
    restaurant_id: str
    day_of_week_num: int
    is_weekend: int
    holiday_flg: int
    is_ramadan: int
    lag_7: float
    rolling_mean_7: float


def _date_to_iso_start(d: date) -> str:
    return datetime(d.year, d.month, d.day).isoformat() + "Z"


def _calendar_base_df(calendar_df: pd.DataFrame, start_day: date, end_day: date) -> pd.DataFrame:
    if start_day > end_day:
        start_day, end_day = end_day, start_day

    if calendar_df is not None and not calendar_df.empty and "prediction_date" in calendar_df.columns:
        base = calendar_df.copy()
        base["prediction_date"] = pd.to_datetime(base["prediction_date"], errors="coerce").dt.date
        base = base.dropna(subset=["prediction_date"])
        base = base[(base["prediction_date"] >= start_day) & (base["prediction_date"] <= end_day)].copy()
        keep = [c for c in ["prediction_date", "day_of_week", "day_of_week_num", "is_weekend", "holiday_flg", "is_ramadan"] if c in base.columns]
        base = base[keep].drop_duplicates(subset=["prediction_date"]).sort_values("prediction_date").reset_index(drop=True)
        base = base.rename(columns={"prediction_date": "order_date"})
    else:
        dates = pd.date_range(start_day, end_day, freq="D").date
        base = pd.DataFrame({"order_date": dates})
        dt = pd.to_datetime(base["order_date"])
        base["day_of_week"] = dt.dt.day_name()
        base["day_of_week_num"] = base["day_of_week"].map(_DAY_NUM_MAP).fillna(dt.dt.weekday).astype(int)
        base["is_weekend"] = base["day_of_week"].map(_IS_WEEKEND_MAP).fillna(0).astype(int)
        base["holiday_flg"] = 0
        base["is_ramadan"] = 0

    missing_mask = base.get("day_of_week").isna() if "day_of_week" in base.columns else pd.Series([True] * len(base))
    if missing_mask.any():
        fallback_dates = pd.to_datetime(base.loc[missing_mask, "order_date"])
        day_names = fallback_dates.dt.day_name()
        base.loc[missing_mask, "day_of_week"] = day_names.values
        base.loc[missing_mask, "day_of_week_num"] = day_names.map(_DAY_NUM_MAP).values
        base.loc[missing_mask, "is_weekend"] = day_names.map(_IS_WEEKEND_MAP).fillna(0).astype(int).values
        base.loc[missing_mask, "holiday_flg"] = 0
        base.loc[missing_mask, "is_ramadan"] = 0

    for col in ["day_of_week_num", "is_weekend", "holiday_flg", "is_ramadan"]:
        if col not in base.columns:
            base[col] = 0
        base[col] = pd.to_numeric(base[col], errors="coerce").fillna(0).astype(int)

    if "day_of_week" not in base.columns:
        dt = pd.to_datetime(base["order_date"])
        base["day_of_week"] = dt.dt.day_name()
    base["day_of_week"] = base["day_of_week"].astype(str)

    base = base.sort_values("order_date").reset_index(drop=True)
    return base


def fetch_orders_for_restaurant(restaurant_id: str, days_back: int = 60) -> pd.DataFrame:
    if SUPABASE is None:
        raise RuntimeError("Supabase is not initialized.")
    rid = (restaurant_id or "").strip()
    if not rid:
        raise RuntimeError("restaurant_id missing")

    start_day = app_today() - timedelta(days=max(1, int(days_back)))
    start_iso = _date_to_iso_start(start_day)

    rows: List[Dict[str, Any]] = []
    page_size = 1000
    start = 0

    while True:
        end = start + page_size - 1
        response = (
            SUPABASE
            .table("orders")
            .select("id, restaurant_id, created_at, status, user_id")
            .eq("restaurant_id", rid)
            .neq("status", "cancelled")
            .gte("created_at", start_iso)
            .range(start, end)
            .execute()
        )

        batch = response.data or []
        if not batch:
            break
        rows.extend(batch)
        if len(batch) < page_size:
            break
        start += page_size

    if not rows:
        return pd.DataFrame(columns=["restaurant_id", "created_at", "status", "user_id"])

    df = pd.DataFrame(rows)
    df["created_at"] = pd.to_datetime(df["created_at"], utc=True, errors="coerce")
    df = df.dropna(subset=["created_at"]).copy()
    return df


def build_daily_metrics_for_restaurant(orders_df: pd.DataFrame, calendar_df: pd.DataFrame) -> pd.DataFrame:
    if orders_df is None or orders_df.empty:
        return pd.DataFrame(columns=[
            "restaurant_id",
            "order_date",
            "orders_count",
            "unique_customers",
            "day_of_week",
            "day_of_week_num",
            "is_weekend",
            "holiday_flg",
            "is_ramadan",
        ])

    orders_df = orders_df.copy()
    orders_df["order_date"] = orders_df["created_at"].dt.tz_convert(APP_TZ).dt.date

    orders_count = (
        orders_df
        .groupby(["restaurant_id", "order_date"])
        .size()
        .reset_index(name="orders_count")
    )

    customers = None
    if "user_id" in orders_df.columns:
        customers = (
            orders_df
            .dropna(subset=["user_id"])
            .groupby(["restaurant_id", "order_date"])["user_id"]
            .nunique()
            .reset_index(name="unique_customers")
        )

    out_frames = []
    for rid in sorted(orders_count["restaurant_id"].dropna().astype(str).unique().tolist()):
        rest_counts = orders_count[orders_count["restaurant_id"] == rid].copy()
        rest_counts["order_date"] = pd.to_datetime(rest_counts["order_date"], errors="coerce").dt.date
        rest_counts = rest_counts.dropna(subset=["order_date"])
        if rest_counts.empty:
            continue

        start_day = min(rest_counts["order_date"])
        end_day = max(max(rest_counts["order_date"]), app_today())
        base = _calendar_base_df(calendar_df, start_day, end_day)
        base["restaurant_id"] = rid

        merged = base.merge(rest_counts[["order_date", "orders_count"]], on="order_date", how="left")
        merged["orders_count"] = pd.to_numeric(merged["orders_count"], errors="coerce").fillna(0).astype(int)

        if customers is not None:
            rest_customers = customers[customers["restaurant_id"] == rid].copy()
            rest_customers["order_date"] = pd.to_datetime(rest_customers["order_date"], errors="coerce").dt.date
            rest_customers = rest_customers.dropna(subset=["order_date"])
            merged = merged.merge(rest_customers[["order_date", "unique_customers"]], on="order_date", how="left")
            merged["unique_customers"] = pd.to_numeric(merged["unique_customers"], errors="coerce").fillna(0).astype(int)
        else:
            merged["unique_customers"] = 0

        out_frames.append(merged)

    if not out_frames:
        return pd.DataFrame(columns=[
            "restaurant_id",
            "order_date",
            "orders_count",
            "unique_customers",
            "day_of_week",
            "day_of_week_num",
            "is_weekend",
            "holiday_flg",
            "is_ramadan",
        ])

    daily = pd.concat(out_frames, ignore_index=True)
    daily = daily.sort_values(["restaurant_id", "order_date"]).reset_index(drop=True)
    return daily


def fetch_events_for_restaurant(restaurant_id: str, days_back: int = 60) -> pd.DataFrame:
    if SUPABASE is None:
        raise RuntimeError("Supabase is not initialized.")
    rid = (restaurant_id or "").strip()
    if not rid:
        raise RuntimeError("restaurant_id missing")

    start_day = app_today() - timedelta(days=max(1, int(days_back)))
    start_iso = _date_to_iso_start(start_day)

    rows: List[Dict[str, Any]] = []
    page_size = 1000
    start = 0

    while True:
        end = start + page_size - 1
        try:
            response = (
                SUPABASE
                .table("analytics_events")
                .select("id, restaurant_id, created_at, event_type, session_id")
                .eq("restaurant_id", rid)
                .gte("created_at", start_iso)
                .range(start, end)
                .execute()
            )
        except Exception:
            return pd.DataFrame(columns=["restaurant_id", "created_at", "event_type", "session_id"])

        batch = response.data or []
        if not batch:
            break
        rows.extend(batch)
        if len(batch) < page_size:
            break
        start += page_size

    if not rows:
        return pd.DataFrame(columns=["restaurant_id", "created_at", "event_type", "session_id"])

    df = pd.DataFrame(rows)
    df["created_at"] = pd.to_datetime(df["created_at"], utc=True, errors="coerce")
    df = df.dropna(subset=["created_at"]).copy()
    return df


def fetch_saved_predictions_for_restaurant(restaurant_id: str, days_forward: int = 7) -> List[Dict[str, Any]]:
    if SUPABASE is None:
        return []
    rid = (restaurant_id or "").strip()
    if not rid:
        return []

    days_i = int(days_forward) if str(days_forward).isdigit() else 7
    days_i = max(1, min(14, days_i))

    start = app_today() + timedelta(days=1)
    end = start + timedelta(days=days_i - 1)
    start_date = str(start)
    end_date = str(end)

    try:
        resp = (
            SUPABASE
            .table("demand_predictions")
            .select("prediction_date,predicted_orders,predicted_visitors,order_level,demand_level,day_of_week_num,is_weekend,holiday_flg,is_ramadan")
            .eq("restaurant_id", rid)
            .gte("prediction_date", start_date)
            .lte("prediction_date", end_date)
            .order("prediction_date", desc=False)
            .execute()
        )
    except Exception:
        return []

    rows = resp.data or []
    out: List[Dict[str, Any]] = []
    for r in rows:
        if not isinstance(r, dict):
            continue
        out.append({
            "date": r.get("prediction_date"),
            "predicted_orders": int(r.get("predicted_orders") or 0),
            "predicted_visitors": int(r.get("predicted_visitors") or 0),
            "order_level": r.get("order_level"),
            "demand_level": r.get("demand_level"),
            "day_of_week_num": int(r.get("day_of_week_num") or 0),
            "is_weekend": bool(r.get("is_weekend")),
            "holiday_flg": bool(r.get("holiday_flg")),
            "is_ramadan": bool(r.get("is_ramadan")),
        })
    return out


def build_daily_sessions_for_restaurant(events_df: pd.DataFrame) -> pd.DataFrame:
    if events_df is None or events_df.empty:
        return pd.DataFrame(columns=["restaurant_id", "order_date", "sessions", "page_views"])

    df = events_df.copy()
    df["order_date"] = df["created_at"].dt.tz_convert(APP_TZ).dt.date
    df["event_type"] = df["event_type"].astype(str).str.strip().str.lower()

    page_views = (
        df[df["event_type"].isin(["restaurant_view", "restaurant_menu_view", "menu_view"])]
        .groupby(["restaurant_id", "order_date"])
        .size()
        .reset_index(name="page_views")
    )

    sessions = (
        df[df["event_type"].isin(["session_start", "app_open"])]
        .groupby(["restaurant_id", "order_date"])
        .size()
        .reset_index(name="sessions")
    )

    out = page_views.merge(sessions, on=["restaurant_id", "order_date"], how="outer")
    out["page_views"] = pd.to_numeric(out["page_views"], errors="coerce").fillna(0).astype(int)
    out["sessions"] = pd.to_numeric(out["sessions"], errors="coerce").fillna(0).astype(int)
    return out


def _predict_one_day(restaurant_id: str, target_day: date, series: List[Dict[str, Any]]) -> Dict[str, Any]:
    if REG_MODEL is None or CLS_MODEL is None or LABEL_ENCODER is None or SCALER is None:
        raise RuntimeError("Models/data not loaded yet")

    cal = get_calendar_row(target_day)
    history_vals = [int(v.get("orders_count", 0)) for v in series]

    if len(history_vals) < 7:
        raise RuntimeError("Not enough history to predict (need >= 7 days)")

    lag_7 = float(history_vals[-7])
    rolling_mean_7 = float(sum(history_vals[-7:]) / 7.0)

    row_df = pd.DataFrame([{
        "day_of_week_num": float(cal["day_of_week_num"]),
        "is_weekend": float(cal["is_weekend"]),
        "holiday_flg": float(cal["holiday_flg"]),
        "is_ramadan": float(cal["is_ramadan"]),
        "lag_7": lag_7,
        "rolling_mean_7": rolling_mean_7,
    }])

    predicted_orders = int(round(REG_MODEL.predict(row_df)[0]))
    predicted_orders = max(predicted_orders, 0)

    # per-restaurant classification بدل global
    order_level = _order_level_for_restaurant(predicted_orders, history_vals)

    predicted_visitors = predict_visitors_from_orders(predicted_orders)
    demand_level = order_level

    return {
        "restaurant_id": restaurant_id,
        "prediction_date": str(target_day),
        "day_of_week": cal["day_of_week"],
        "day_of_week_num": int(cal["day_of_week_num"]),
        "is_weekend": bool(cal["is_weekend"]),
        "holiday_flg": bool(cal["holiday_flg"]),
        "is_ramadan": bool(cal["is_ramadan"]),
        "lag_7": round(lag_7, 1),
        "rolling_mean_7": round(rolling_mean_7, 1),
        "predicted_orders": predicted_orders,
        "order_level": order_level,
        "predicted_visitors": predicted_visitors,
        "demand_level": demand_level,
        "order_conversion_factor": ORDER_CONVERSION_FACTOR,
    }


# =========================
# Auth middleware
# =========================
@app.middleware("http")
async def require_internal_key(request: Request, call_next):
    open_prefixes = (
        "/health",
        "/docs",
        "/openapi.json",
        "/redoc",
        "/calendar",
        "/dashboard",
        "/restaurants",
        "/today-prediction",
        "/favicon.ico",
    )

    is_open = any(
        request.url.path == p or request.url.path.startswith(p)
        for p in open_prefixes
    )

    if INTERNAL_KEY and not is_open:
        if request.headers.get("x-internal-key") != INTERNAL_KEY:
            return JSONResponse({"detail": "Unauthorized"}, status_code=401)

    return await call_next(request)


# =========================
# Supabase init
# =========================
def init_supabase():
    global SUPABASE

    if not SUPABASE_URL or not SUPABASE_KEY:
        raise RuntimeError(
            f"SUPABASE_URL or SUPABASE_KEY missing in .env | "
            f"SUPABASE_URL exists={bool(SUPABASE_URL)} | SUPABASE_KEY exists={bool(SUPABASE_KEY)}"
        )

    try:
        from supabase import create_client
        SUPABASE = create_client(SUPABASE_URL, SUPABASE_KEY)
        print("Supabase client initialized successfully.")
    except Exception as e:
        err_msg = traceback.format_exc()
        print(err_msg)
        raise RuntimeError(f"Failed to initialize Supabase: {err_msg}")


# =========================
# Excel calendar loading
# =========================
def load_calendar_excel() -> pd.DataFrame:
    base_dir = os.path.dirname(os.path.abspath(__file__))

    candidate_files = [
        "fixed_egypt_calendar_2026.xlsx",
        "fixed_egypt_calender_2026.xlsx",
    ]

    excel_path = None
    for filename in candidate_files:
        path = os.path.join(base_dir, filename)
        if os.path.exists(path):
            excel_path = path
            break

    if excel_path is None:
        raise FileNotFoundError(
            "Could not find fixed_egypt_calendar_2026.xlsx or fixed_egypt_calender_2026.xlsx "
            "in the same folder as main.py"
        )

    print(f"Excel calendar file loaded from: {excel_path}")

    xls = pd.ExcelFile(excel_path)
    sheet_name = "calendar_flags_2026" if "calendar_flags_2026" in xls.sheet_names else xls.sheet_names[0]

    df = pd.read_excel(excel_path, sheet_name=sheet_name)

    required_cols = {
        "prediction_date",
        "day_of_week",
        "day_of_week_num",
        "is_weekend",
        "holiday_flg",
        "is_ramadan",
    }

    missing = required_cols - set(df.columns)
    if missing:
        raise ValueError(f"Missing required columns in Excel: {missing}")

    df["prediction_date"] = pd.to_datetime(df["prediction_date"]).dt.date
    df["day_of_week"] = df["day_of_week"].astype(str)

    for col in ["day_of_week_num", "is_weekend", "holiday_flg", "is_ramadan"]:
        df[col] = pd.to_numeric(df[col], errors="coerce").fillna(0).astype(int)

    base_cols = [
        "prediction_date",
        "day_of_week",
        "day_of_week_num",
        "is_weekend",
        "holiday_flg",
        "is_ramadan",
    ]
    optional_cols = ["holiday_name", "holiday_name_ar", "holiday_group", "notes"]
    keep_cols = base_cols + [c for c in optional_cols if c in df.columns]

    return df[keep_cols].drop_duplicates()


def fetch_calendar_flags_from_supabase() -> pd.DataFrame:
    if SUPABASE is None:
        return pd.DataFrame()
    try:
        resp = (
            SUPABASE
            .table("calendar_flags")
            .select("*")
            .order("prediction_date", desc=False)
            .execute()
        )
    except Exception:
        return pd.DataFrame()

    rows = resp.data or []
    if not rows:
        return pd.DataFrame()

    df = pd.DataFrame(rows)
    if "prediction_date" in df.columns:
        df["prediction_date"] = pd.to_datetime(df["prediction_date"], errors="coerce").dt.date
    if "day_of_week" in df.columns:
        df["day_of_week"] = df["day_of_week"].astype(str)
    for col in ["day_of_week_num", "is_weekend", "holiday_flg", "is_ramadan"]:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors="coerce").fillna(0).astype(int)
    return df.dropna(subset=["prediction_date"]).drop_duplicates()


def load_calendar_flags() -> pd.DataFrame:
    global CALENDAR_SOURCE
    df = fetch_calendar_flags_from_supabase()
    if df is not None and not df.empty:
        CALENDAR_SOURCE = "supabase"
        return df
    CALENDAR_SOURCE = "excel"
    return load_calendar_excel()


def upsert_calendar_flags_to_supabase(calendar_df: pd.DataFrame, batch_size: int = 500) -> Dict[str, Any]:
    if SUPABASE is None:
        return {"ok": False, "error": "Supabase not initialized"}
    if calendar_df is None or calendar_df.empty:
        return {"ok": False, "error": "calendar_df is empty"}

    if "prediction_date" not in calendar_df.columns:
        return {"ok": False, "error": "prediction_date column missing"}

    df = calendar_df.copy()
    df["prediction_date"] = pd.to_datetime(df["prediction_date"], errors="coerce").dt.date
    df = df.dropna(subset=["prediction_date"])

    rows = df.to_dict(orient="records")
    inserted = 0
    batches = 0

    for i in range(0, len(rows), batch_size):
        chunk = rows[i:i + batch_size]
        try:
            (
                SUPABASE
                .table("calendar_flags")
                .upsert(chunk, on_conflict="prediction_date")
                .execute()
            )
        except Exception as e:
            return {"ok": False, "error": str(e), "inserted": inserted, "batches": batches}
        inserted += len(chunk)
        batches += 1

    return {"ok": True, "upserted": inserted, "batches": batches}


# =========================
# Supabase orders loading
# =========================
def fetch_all_orders() -> pd.DataFrame:
    if SUPABASE is None:
        raise RuntimeError("Supabase is not initialized.")

    start_day = app_today() - timedelta(days=max(1, int(TRAIN_DAYS_BACK)))
    start_iso = _date_to_iso_start(start_day)

    rows: List[Dict[str, Any]] = []
    page_size = 1000
    start = 0

    while True:
        end = start + page_size - 1
        response = (
            SUPABASE
            .table("orders")
            .select("id, restaurant_id, created_at, status")
            .neq("status", "cancelled")
            .gte("created_at", start_iso)
            .range(start, end)
            .execute()
        )

        batch = response.data or []
        if not batch:
            break

        rows.extend(batch)

        if len(batch) < page_size:
            break

        start += page_size

    if not rows:
        raise RuntimeError("No orders found in Supabase.")

    df = pd.DataFrame(rows)
    df["created_at"] = pd.to_datetime(df["created_at"], utc=True, errors="coerce")
    df = df.dropna(subset=["restaurant_id", "created_at"]).copy()

    print(f"Fetched orders rows from Supabase: {len(df)}")
    return df


def build_daily_orders_dataset(orders_df: pd.DataFrame, calendar_df: pd.DataFrame) -> pd.DataFrame:
    orders_df["order_date"] = orders_df["created_at"].dt.tz_convert(APP_TZ).dt.date

    counts = (
        orders_df
        .groupby(["restaurant_id", "order_date"])
        .size()
        .reset_index(name="orders_count")
    )

    out_frames = []
    for rid in sorted(counts["restaurant_id"].dropna().astype(str).unique().tolist()):
        rest = counts[counts["restaurant_id"] == rid].copy()
        rest["order_date"] = pd.to_datetime(rest["order_date"], errors="coerce").dt.date
        rest = rest.dropna(subset=["order_date"])
        if rest.empty:
            continue

        start_day = min(rest["order_date"])
        end_day = max(rest["order_date"])
        base = _calendar_base_df(calendar_df, start_day, end_day)
        base["restaurant_id"] = rid

        merged = base.merge(rest[["order_date", "orders_count"]], on="order_date", how="left")
        merged["orders_count"] = pd.to_numeric(merged["orders_count"], errors="coerce").fillna(0).astype(int)
        out_frames.append(merged)

    if not out_frames:
        raise RuntimeError("No daily data could be built from orders.")

    daily = pd.concat(out_frames, ignore_index=True)
    daily = daily.sort_values(["restaurant_id", "order_date"]).reset_index(drop=True)

    daily["lag_7"] = daily.groupby("restaurant_id")["orders_count"].shift(7)
    daily["rolling_mean_7"] = (
        daily.groupby("restaurant_id")["orders_count"]
        .shift(1)
        .rolling(window=7)
        .mean()
    )

    daily = daily.dropna(subset=["lag_7", "rolling_mean_7"]).copy()

    low_th = daily["orders_count"].quantile(0.80)
    high_th = daily["orders_count"].quantile(0.95)

    def order_level_q(v):
        if v <= low_th:
            return "Low"
        elif v <= high_th:
            return "Medium"
        return "High"

    daily["order_level"] = daily["orders_count"].apply(order_level_q)

    print(f"Daily aggregated rows used for training: {len(daily)}")
    return daily


# =========================
# Model training
# =========================
def train_models_from_supabase_orders(daily_df: pd.DataFrame):
    x_reg = daily_df[FEATURES]
    y_reg = daily_df["orders_count"]

    reg_model = LinearRegression()
    reg_model.fit(x_reg, y_reg)

    le = LabelEncoder()
    daily_df["order_label"] = le.fit_transform(daily_df["order_level"])

    x_clf = daily_df[FEATURES]
    y_clf = daily_df["order_label"]

    scaler = StandardScaler()
    x_clf_scaled = scaler.fit_transform(x_clf)

    cls_model = LogisticRegression(
        max_iter=3000,
        solver="lbfgs",
        class_weight="balanced",
        random_state=42
    )
    cls_model.fit(x_clf_scaled, y_clf)

    return reg_model, cls_model, le, scaler


# =========================
# Utility functions
# =========================
def predict_visitors_from_orders(predicted_orders: int) -> int:
    if ORDER_CONVERSION_FACTOR <= 0:
        return predicted_orders
    return max(int(round(predicted_orders / ORDER_CONVERSION_FACTOR)), 0)


def _order_level_for_restaurant(predicted: int, history: list) -> str:
    """
    يحسب مستوى الطلب بناءً على تاريخ المطعم نفسه (مش global).
    Low    = أقل من 80th percentile من تاريخه
    Medium = بين 80th و 95th percentile
    High   = أعلى من 95th percentile
    """
    if not history or len(history) < 3:
        # بيانات مش كافية → نرجع Low كقيمة افتراضية آمنة
        return "Low"
    s = pd.Series([float(v) for v in history])
    low_th  = s.quantile(0.80)
    high_th = s.quantile(0.95)
    if predicted <= low_th:
        return "Low"
    elif predicted <= high_th:
        return "Medium"
    return "High"


def get_calendar_row(target_date: date) -> Dict[str, Any]:
    row = CALENDAR_DF[CALENDAR_DF["prediction_date"] == target_date]

    if not row.empty:
        r = row.iloc[0]
        day_en = str(r["day_of_week"])
        return {
            "day_of_week": DAY_NAMES_AR.get(day_en, day_en),
            "day_of_week_num": int(r["day_of_week_num"]),
            "is_weekend": int(r["is_weekend"]),
            "holiday_flg": int(r["holiday_flg"]),
            "is_ramadan": int(r["is_ramadan"]),
        }

    dt = pd.Timestamp(target_date)
    day_en = dt.day_name()
    return {
        "day_of_week": DAY_NAMES_AR.get(day_en, day_en),
        "day_of_week_num": int(_DAY_NUM_MAP.get(day_en, dt.weekday())),
        "is_weekend": int(_IS_WEEKEND_MAP.get(day_en, 0)),
        "holiday_flg": 0,
        "is_ramadan": 0,
    }


def save_prediction_to_supabase(
    restaurant_id: str,
    prediction_date: str,
    predicted_visitors: int,
    predicted_orders: int,
    demand_level: str,
    order_level: str,
    day_of_week_num: int,
    is_weekend: bool,
    holiday_flg: bool,
    is_ramadan: bool,
    lag_7: float,
    rolling_mean_7: float,
    day_of_week: str,
):
    if SUPABASE is None:
        return {"saved": False, "reason": "Supabase client not initialized"}

    payload = {
        "restaurant_id": restaurant_id,
        "prediction_date": prediction_date,
        "predicted_visitors": int(predicted_visitors),
        "predicted_orders": int(predicted_orders),
        "demand_level": demand_level,
        "order_level": order_level,
        "day_of_week_num": int(day_of_week_num),
        "is_weekend": bool(is_weekend),
        "holiday_flg": bool(holiday_flg),
        "is_ramadan": bool(is_ramadan),
        "lag_7": int(round(lag_7)),
        "rolling_mean_7": float(round(rolling_mean_7, 2)),
        "day_of_week": day_of_week,
    }

    try:
        existing = (
            SUPABASE.table("demand_predictions")
            .select("id")
            .eq("restaurant_id", restaurant_id)
            .eq("prediction_date", prediction_date)
            .limit(1)
            .execute()
        )

        if existing.data:
            row_id = existing.data[0]["id"]
            SUPABASE.table("demand_predictions").update(payload).eq("id", row_id).execute()
            return {"saved": True, "mode": "updated"}
        else:
            SUPABASE.table("demand_predictions").insert(payload).execute()
            return {"saved": True, "mode": "inserted"}

    except Exception as e:
        err_msg = traceback.format_exc()
        print(err_msg)
        return {"saved": False, "reason": err_msg}


# =========================
# Startup
# =========================
@app.on_event("startup")
def startup_event():
    global REG_MODEL, CLS_MODEL, LABEL_ENCODER, SCALER, ORDERS_DAILY, CALENDAR_DF, CALENDAR_SOURCE, STARTUP_ERRORS

    print("Starting app startup...")

    STARTUP_ERRORS = {"supabase": None, "calendar": None, "training": None}

    try:
        init_supabase()
    except Exception as e:
        err_msg = traceback.format_exc()
        print(err_msg)
        STARTUP_ERRORS["supabase"] = str(e) or "Supabase init failed"

    try:
        CALENDAR_DF = load_calendar_flags()
    except Exception as e:
        err_msg = traceback.format_exc()
        print(err_msg)
        STARTUP_ERRORS["calendar"] = str(e) or "Calendar load failed"
        CALENDAR_DF = pd.DataFrame()
        CALENDAR_SOURCE = "error"

    try:
        if SUPABASE is None:
            raise RuntimeError("Supabase not initialized; skipping orders/model training")

        orders_df = fetch_all_orders()
        ORDERS_DAILY = build_daily_orders_dataset(orders_df, CALENDAR_DF if CALENDAR_DF is not None else pd.DataFrame())

        if ORDERS_DAILY.empty:
            print("No trainable daily orders data after preprocessing.")
        else:
            REG_MODEL, CLS_MODEL, LABEL_ENCODER, SCALER = train_models_from_supabase_orders(ORDERS_DAILY)
            print(f"Rows used for training: {len(ORDERS_DAILY)}")
    except Exception as e:
        err_msg = traceback.format_exc()
        print("Startup error during model training:")
        print(err_msg)
        STARTUP_ERRORS["training"] = str(e) or "Training failed"

    print("Main startup complete.")


# =========================
# Routes
# =========================
@app.get("/")
def home():
    return {"message": "Demand Prediction FastAPI is running on Supabase orders + Egypt calendar flags", "calendar_source": CALENDAR_SOURCE}


@app.get("/calendar/source")
def calendar_source():
    count = 0
    if CALENDAR_DF is not None and not CALENDAR_DF.empty:
        count = int(len(CALENDAR_DF))
    return {"calendar_source": CALENDAR_SOURCE, "rows": count}


@app.post("/calendar/import")
def calendar_import(x_internal_key: Optional[str] = Header(None)):
    if not INTERNAL_KEY or (x_internal_key or "") != INTERNAL_KEY:
        raise HTTPException(status_code=401, detail="Unauthorized")

    try:
        df = load_calendar_excel()
        res = upsert_calendar_flags_to_supabase(df)
        if not res.get("ok"):
            raise HTTPException(status_code=400, detail=res.get("error") or "import_failed")

        global CALENDAR_DF
        CALENDAR_DF = load_calendar_flags()

        return {"ok": True, "result": res, "calendar_source": CALENDAR_SOURCE}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/dashboard")
def serve_dashboard():
    return FileResponse("dashboard.html", media_type="text/html")


@app.get("/health")
def health():
    return {
        "status": "ok",
        "new_main_running": True,
        "supabase_connected": SUPABASE is not None,
        "excel_loaded": CALENDAR_DF is not None,
        "orders_rows": 0 if ORDERS_DAILY is None else len(ORDERS_DAILY),
        "startup_ok": not any(STARTUP_ERRORS.values()),
        "startup_errors": STARTUP_ERRORS,
        "env": {
            "SUPABASE_URL_exists": bool(SUPABASE_URL),
            "SUPABASE_KEY_exists": bool(SUPABASE_KEY),
            "ORDER_CONVERSION_FACTOR": ORDER_CONVERSION_FACTOR,
        },
    }


@app.get("/restaurants")
def get_restaurants():
    """
    Returns restaurants from Supabase (real app data).
    """
    if SUPABASE is None:
        return {"error": "Supabase not initialized"}

    try:
        response = (
            SUPABASE.table("restaurants")
            .select("id, name, is_active, created_at")
            .order("created_at", desc=False)
            .execute()
        )

        return {
            "success": True,
            "count": len(response.data) if response.data else 0,
            "data": response.data or []
        }

    except Exception as e:
        err_msg = traceback.format_exc()
        print(err_msg)
        return {
            "success": False,
            "error": err_msg,
            "supabase_url_exists": bool(SUPABASE_URL),
            "supabase_key_exists": bool(SUPABASE_KEY),
        }


@app.get("/today-prediction/{restaurant_id}")
def today_prediction(restaurant_id: str):
    if REG_MODEL is None or CLS_MODEL is None or LABEL_ENCODER is None or SCALER is None:
        raise HTTPException(status_code=503, detail="Models/data not loaded yet")

    orders_df = fetch_orders_for_restaurant(restaurant_id, days_back=60)
    daily = build_daily_metrics_for_restaurant(orders_df, CALENDAR_DF if CALENDAR_DF is not None else pd.DataFrame())
    rest = daily[daily["restaurant_id"] == restaurant_id].sort_values("order_date").reset_index(drop=True)

    today = app_today()
    rest_hist = rest[rest["order_date"] < today].copy()
    if len(rest_hist) < 7:
        raise HTTPException(
            status_code=404,
            detail=f"Not enough historical order data for restaurant '{restaurant_id}'"
        )

    cal = get_calendar_row(today)

    recent_orders = pd.to_numeric(rest_hist["orders_count"], errors="coerce").fillna(0).values
    lag_7 = float(recent_orders[-7])
    rolling_mean_7 = float(recent_orders[-7:].mean())

    row_df = pd.DataFrame([{
        "day_of_week_num": float(cal["day_of_week_num"]),
        "is_weekend": float(cal["is_weekend"]),
        "holiday_flg": float(cal["holiday_flg"]),
        "is_ramadan": float(cal["is_ramadan"]),
        "lag_7": lag_7,
        "rolling_mean_7": rolling_mean_7,
    }])

    predicted_orders = int(round(REG_MODEL.predict(row_df)[0]))
    predicted_orders = max(predicted_orders, 0)

    # per-restaurant classification بدل global
    order_level = _order_level_for_restaurant(predicted_orders, recent_orders.tolist())

    predicted_visitors = predict_visitors_from_orders(predicted_orders)
    demand_level = order_level

    last_7 = rest_hist.tail(7)[["order_date", "orders_count"]].copy()
    trend = [
        {"date": str(r["order_date"]), "orders": int(r["orders_count"])}
        for _, r in last_7.iterrows()
    ]

    save_result = save_prediction_to_supabase(
        restaurant_id=restaurant_id,
        prediction_date=str(today),
        predicted_visitors=predicted_visitors,
        predicted_orders=predicted_orders,
        demand_level=demand_level,
        order_level=order_level,
        day_of_week_num=int(cal["day_of_week_num"]),
        is_weekend=bool(cal["is_weekend"]),
        holiday_flg=bool(cal["holiday_flg"]),
        is_ramadan=bool(cal["is_ramadan"]),
        lag_7=lag_7,
        rolling_mean_7=rolling_mean_7,
        day_of_week=cal["day_of_week"],
    )

    return {
        "restaurant_id": restaurant_id,
        "prediction_date": str(today),
        "day_of_week": cal["day_of_week"],
        "day_of_week_num": int(cal["day_of_week_num"]),
        "is_weekend": bool(cal["is_weekend"]),
        "holiday_flg": bool(cal["holiday_flg"]),
        "is_ramadan": bool(cal["is_ramadan"]),
        "lag_7": round(lag_7, 1),
        "rolling_mean_7": round(rolling_mean_7, 1),
        "predicted_orders": predicted_orders,
        "order_level": order_level,
        "predicted_visitors": predicted_visitors,
        "demand_level": demand_level,
        "order_conversion_factor": ORDER_CONVERSION_FACTOR,
        "last_7_days": trend,
        "supabase_save": save_result,
    }


@app.post("/predict")
def predict(
    input_data: PredictionInput
):
    if REG_MODEL is None or CLS_MODEL is None or LABEL_ENCODER is None or SCALER is None:
        raise HTTPException(status_code=503, detail="Models/data not loaded yet")
    try:
        row_df = pd.DataFrame([{
            "day_of_week_num": float(input_data.day_of_week_num),
            "is_weekend": float(input_data.is_weekend),
            "holiday_flg": float(input_data.holiday_flg),
            "is_ramadan": float(input_data.is_ramadan),
            "lag_7": float(input_data.lag_7),
            "rolling_mean_7": float(input_data.rolling_mean_7),
        }])

        predicted_orders = int(round(REG_MODEL.predict(row_df)[0]))
        predicted_orders = max(predicted_orders, 0)

        row_scaled = SCALER.transform(row_df)
        pred_label = CLS_MODEL.predict(row_scaled)[0]
        order_level = LABEL_ENCODER.inverse_transform([int(pred_label)])[0]

        predicted_visitors = predict_visitors_from_orders(predicted_orders)
        demand_level = order_level

        save_result = save_prediction_to_supabase(
            restaurant_id=input_data.restaurant_id,
            prediction_date=str(date.today()),
            predicted_visitors=predicted_visitors,
            predicted_orders=predicted_orders,
            demand_level=demand_level,
            order_level=order_level,
            day_of_week_num=int(input_data.day_of_week_num),
            is_weekend=bool(input_data.is_weekend),
            holiday_flg=bool(input_data.holiday_flg),
            is_ramadan=bool(input_data.is_ramadan),
            lag_7=float(input_data.lag_7),
            rolling_mean_7=float(input_data.rolling_mean_7),
            day_of_week="manual",
        )

        return {
            "restaurant_id": input_data.restaurant_id,
            "prediction_date": str(date.today()),
            "predicted_orders": predicted_orders,
            "order_level": order_level,
            "predicted_visitors": predicted_visitors,
            "demand_level": demand_level,
            "order_conversion_factor": ORDER_CONVERSION_FACTOR,
            "supabase_save": save_result,
        }

    except Exception as e:
        print(traceback.format_exc())
        raise HTTPException(status_code=400, detail="Bad request")


def _forecast_impl(restaurant_id: str, days_i: int, do_save: bool) -> Dict[str, Any]:
    orders_df = fetch_orders_for_restaurant(restaurant_id, days_back=60)
    daily = build_daily_metrics_for_restaurant(orders_df, CALENDAR_DF)
    daily_rest = daily[daily["restaurant_id"] == restaurant_id].sort_values("order_date").reset_index(drop=True)
    if daily_rest.empty:
        raise HTTPException(status_code=404, detail="No historical order data for this restaurant")

    series = [{"order_date": r["order_date"], "orders_count": int(r["orders_count"])} for _, r in daily_rest.iterrows()]
    last_day = series[-1]["order_date"]
    start_day = max(app_today() + timedelta(days=1), last_day + timedelta(days=1))

    out = []
    for i in range(days_i):
        target_day = start_day + timedelta(days=i)
        pred = _predict_one_day(restaurant_id, target_day, series)
        if do_save:
            save_prediction_to_supabase(
                restaurant_id=restaurant_id,
                prediction_date=str(target_day),
                predicted_visitors=int(pred["predicted_visitors"]),
                predicted_orders=int(pred["predicted_orders"]),
                demand_level=str(pred["demand_level"]),
                order_level=str(pred["order_level"]),
                day_of_week_num=int(pred["day_of_week_num"]),
                is_weekend=bool(pred["is_weekend"]),
                holiday_flg=bool(pred["holiday_flg"]),
                is_ramadan=bool(pred["is_ramadan"]),
                lag_7=float(pred["lag_7"]),
                rolling_mean_7=float(pred["rolling_mean_7"]),
                day_of_week=str(pred["day_of_week"]),
            )
        out.append(pred)
        series.append({"order_date": target_day, "orders_count": int(pred["predicted_orders"])})

    return {"restaurant_id": restaurant_id, "days": days_i, "forecast": out, "saved": bool(do_save)}


@app.get("/forecast/{restaurant_id}")
def forecast_restaurant(request: Request, restaurant_id: str, days: int = 7, save: int = 0):
    days_i = int(days) if str(days).isdigit() else 7
    days_i = max(1, min(14, days_i))
    requested_save = bool(int(save)) if str(save).isdigit() else False
    is_cron_call = (str(request.headers.get("x-cron") or "").strip() == "1")
    do_save = requested_save and is_cron_call
    return _forecast_impl(restaurant_id=restaurant_id, days_i=days_i, do_save=do_save)


@app.get("/dashboard-data/{restaurant_id}")
def dashboard_data(restaurant_id: str, days: int = 7):
    days_i = int(days) if str(days).isdigit() else 7
    days_i = max(3, min(30, days_i))

    orders_df = fetch_orders_for_restaurant(restaurant_id, days_back=max(60, days_i + 14))
    daily = build_daily_metrics_for_restaurant(orders_df, CALENDAR_DF)
    daily_rest = daily[daily["restaurant_id"] == restaurant_id].sort_values("order_date").reset_index(drop=True)
    if daily_rest.empty:
        raise HTTPException(status_code=404, detail="No historical order data for this restaurant")

    events_df = fetch_events_for_restaurant(restaurant_id, days_back=max(60, days_i + 14))
    sessions_daily = build_daily_sessions_for_restaurant(events_df)
    if not sessions_daily.empty:
        daily_rest = daily_rest.merge(
            sessions_daily[sessions_daily["restaurant_id"] == restaurant_id],
            on=["restaurant_id", "order_date"],
            how="left"
        )
        daily_rest["sessions"] = pd.to_numeric(daily_rest.get("sessions"), errors="coerce").fillna(0).astype(int)
        daily_rest["page_views"] = pd.to_numeric(daily_rest.get("page_views"), errors="coerce").fillna(0).astype(int)
    else:
        daily_rest["sessions"] = 0
        daily_rest["page_views"] = 0

    tail = daily_rest.tail(days_i)
    actual = [
        {
            "date": str(r["order_date"]),
            "orders": int(r["orders_count"]),
            "unique_customers": int(r.get("unique_customers", 0)),
            "sessions": int(r.get("sessions", 0)),
            "page_views": int(r.get("page_views", 0)),
        }
        for _, r in tail.iterrows()
    ]

    total_orders = int(pd.to_numeric(tail["orders_count"], errors="coerce").fillna(0).sum())
    total_sessions = int(pd.to_numeric(tail.get("sessions"), errors="coerce").fillna(0).sum())
    conversion_rate = (float(total_orders) / float(total_sessions)) if total_sessions > 0 else None

    today_out = None
    try:
        today_out = today_prediction(restaurant_id)
    except Exception:
        today_out = None

    saved_forecast = fetch_saved_predictions_for_restaurant(restaurant_id, days_forward=days_i)

    return {
        "restaurant_id": restaurant_id,
        "actual_days": days_i,
        "actual": actual,
        "summary": {
            "total_orders": total_orders,
            "total_sessions": total_sessions,
            "conversion_rate": conversion_rate,
        },
        "today_prediction": today_out,
        "saved_forecast_days": days_i,
        "saved_forecast": saved_forecast,
    }


@app.post("/cron/daily-forecast")
def cron_daily_forecast(days: int = 7, save: int = 1, active_only: int = 1):
    if SUPABASE is None:
        raise HTTPException(status_code=503, detail="Supabase not initialized")

    days_i = int(days) if str(days).isdigit() else 7
    days_i = max(1, min(14, days_i))
    do_save = bool(int(save)) if str(save).isdigit() else True
    only_active = bool(int(active_only)) if str(active_only).isdigit() else True

    q = SUPABASE.table("restaurants").select("id")
    if only_active:
        q = q.eq("is_active", True)
    resp = q.execute()

    rows = resp.data or []
    restaurant_ids = [r.get("id") for r in rows if isinstance(r, dict) and r.get("id")]

    ok_count = 0
    skipped = []
    failed = []

    for rid in restaurant_ids:
        try:
            _forecast_impl(restaurant_id=rid, days_i=days_i, do_save=do_save)
            ok_count += 1
        except HTTPException as e:
            if e.status_code in (404, 503):
                skipped.append({"restaurant_id": rid, "status": e.status_code, "detail": e.detail})
            else:
                failed.append({"restaurant_id": rid, "status": e.status_code, "detail": e.detail})
        except Exception as e:
            failed.append({"restaurant_id": rid, "status": 500, "detail": str(e)})

    return {
        "ok": True,
        "days": days_i,
        "save": do_save,
        "active_only": only_active,
        "restaurants_total": len(restaurant_ids),
        "forecast_ok": ok_count,
        "skipped_count": len(skipped),
        "failed_count": len(failed),
        "skipped": skipped[:50],
        "failed": failed[:50],
    }