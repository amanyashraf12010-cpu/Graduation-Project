export default {
  async fetch(request, env) {
    // ---------------- BASIC REQUEST INFO ----------------
    const SUPABASE_URL = "https://nihqgkohnnpgbbyohfwt.supabase.co";
    const method = request.method;
    const url = new URL(request.url);
    const path = url.pathname;
    const RECOMMEND_BASE_URL = (env.RECOMMEND_BASE_URL || "").replace(/\/+$/, "");
    const RECOMMEND_API_KEY = env.RECOMMEND_API_KEY;


    // ---------------- CORS (BROWSER SUPPORT) ----------------
    const corsHeaders = (req) => {
      const origin = req.headers.get("Origin") || "*";
      return {
        "Access-Control-Allow-Origin": origin,
        "Access-Control-Allow-Methods": "GET,POST,OPTIONS",
        "Access-Control-Allow-Headers": "Authorization, Content-Type, Idempotency-Key",
        "Access-Control-Expose-Headers": "X-Next-Offset, X-Next-Cursor",
        "Access-Control-Max-Age": "86400"
      };
    };

    const normalizeTaxonomyValue = (value) => {
      if (typeof value !== "string") return null;
      const cleaned = value.trim().toLowerCase().replace(/\s+/g, "_");
      return cleaned || null;
    };

    const normalizeMealTags = (value) => {
      const raw = Array.isArray(value)
        ? value
        : (typeof value === "string" ? value.split(",") : []);
      return raw
        .map((v) => typeof v === "string" ? v.trim().toLowerCase().replace(/\s+/g, "_") : "")
        .filter(Boolean)
        .filter((v, i, arr) => arr.indexOf(v) === i)
        .slice(0, 20);
    };

    const normalizeMoneyValue = (value) => {
      const numeric = typeof value === "number"
        ? value
        : (typeof value === "string" && value.trim() !== "" ? Number(value) : NaN);
      if (!Number.isFinite(numeric)) return null;
      return Math.round(numeric * 100) / 100;
    };

    // Preflight requests must not require auth
    if (method === "OPTIONS") {
      return new Response(null, { status: 204, headers: corsHeaders(request) });
    }

    if ((method === "GET" || method === "HEAD") && path.startsWith("/r2/")) {
      const bucket = env.MEALS_BUCKET;
      if (!bucket) {
        return new Response("R2 bucket not configured", { status: 500 });
      }

      const key = decodeURIComponent(path.slice("/r2/".length));
      if (!key) return new Response("Not found", { status: 404 });

      const obj = await bucket.get(key);
      if (!obj) return new Response("Not found", { status: 404 });

      const headers = new Headers();
      headers.set("ETag", obj.httpEtag || obj.etag);
      headers.set("Cache-Control", "public, max-age=31536000, immutable");
      if (obj.httpMetadata?.contentType) headers.set("Content-Type", obj.httpMetadata.contentType);
      headers.set("Access-Control-Allow-Origin", "*");

      return new Response(method === "HEAD" ? null : obj.body, { status: 200, headers });
    }

    // ---------------- AUTH (FIREBASE ID TOKEN) ----------------
    const authHeader = request.headers.get("Authorization");
    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return new Response("Authorization header missing or invalid", { status: 401, headers: corsHeaders(request) });
    }

    const idToken = authHeader.split(" ")[1];

    function getTokenClaims(token) {
      try {
        const parts = typeof token === "string" ? token.split(".") : [];
        if (parts.length < 2) return null;
        let p = parts[1].replace(/-/g, "+").replace(/_/g, "/");
        const padLen = (4 - (p.length % 4)) % 4;
        if (padLen) p = p + "=".repeat(padLen);
        const payload = JSON.parse(atob(p));
        const provider = payload && payload.firebase && typeof payload.firebase.sign_in_provider === "string"
          ? payload.firebase.sign_in_provider
          : null;
        const email = payload && typeof payload.email === "string" ? payload.email : null;
        const name = payload && typeof payload.name === "string" ? payload.name : null;
        return { provider, email, name };
      } catch {
        return null;
      }
    }

    // Verify Firebase ID token with Google Identity Toolkit -> returns Firebase UID + user info
    async function verifyToken(idToken) {
      const res = await fetch(
        `https://identitytoolkit.googleapis.com/v1/accounts:lookup?key=${env.FIREBASE_API_KEY}`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ idToken })
        }
      );

      if (!res.ok) throw new Error("Invalid token");

      const data = await res.json();
      if (!data.users || data.users.length === 0) throw new Error("Invalid token");

      const u = data.users[0];
      const providers = Array.isArray(u?.providerUserInfo) ? u.providerUserInfo : [];
      const hasGoogleProvider = providers.some((p) => p && p.providerId === "google.com");
      const googleProvider = providers.find((p) => p && p.providerId === "google.com") || null;
      const hasFacebookProvider = providers.some((p) => p && p.providerId === "facebook.com");
      const facebookProvider = providers.find((p) => p && p.providerId === "facebook.com") || null;
      const providerEmail =
        (googleProvider && typeof googleProvider.email === "string" ? googleProvider.email : null) ??
        (facebookProvider && typeof facebookProvider.email === "string" ? facebookProvider.email : null);
      const providerName =
        (googleProvider && typeof googleProvider.displayName === "string" ? googleProvider.displayName : null) ??
        (facebookProvider && typeof facebookProvider.displayName === "string" ? facebookProvider.displayName : null);
      return {
        uid: u.localId,
        email: typeof u.email === "string" ? u.email : providerEmail,
        name: typeof u.displayName === "string" ? u.displayName : providerName,
        hasGoogleProvider,
        hasFacebookProvider
      };
    }

    let firebase_user;
    let firebase_uid;
    let firebase_email;
    let firebase_name;
    let firebase_sign_in_provider;
    let firebase_is_google = false;
    let firebase_is_facebook = false;
    let firebase_is_social = false;
    

    // Extract Firebase UID from the token (or reject the request)
    try {
      firebase_user = await verifyToken(idToken);
      firebase_uid = firebase_user.uid;
      const tokenClaims = getTokenClaims(idToken);
      firebase_email = firebase_user.email ?? (tokenClaims ? tokenClaims.email : null);
      firebase_name = firebase_user.name ?? (tokenClaims ? tokenClaims.name : null);
      firebase_sign_in_provider = tokenClaims ? tokenClaims.provider : null;
      firebase_is_google = firebase_user.hasGoogleProvider === true || firebase_sign_in_provider === "google.com";
      firebase_is_facebook = firebase_user.hasFacebookProvider === true || firebase_sign_in_provider === "facebook.com";
      firebase_is_social = firebase_is_google || firebase_is_facebook;
    } catch (err) {
      return new Response("Invalid Firebase token", { status: 401, headers: corsHeaders(request) });
    }

    // ---------------- DEEPSEARCH PROXY (CLOUD RUN) ----------------
    // These routes forward requests to your FastAPI service on Cloud Run.
    if (path.startsWith("/deepsearch/")) {
      // Cloud Run base URL (set this in Worker env vars). Fallback is your current deployed URL.
      const base = (env.DEEPSEARCH_BASE_URL || "https://deepsearch-app-340625622680.europe-west8.run.app").replace(/\/+$/, "");

      // Map Worker route -> Cloud Run route
      let upstreamPath = null;
      if (method === "GET" && path === "/deepsearch/health") upstreamPath = "/health";
      if (method === "POST" && path === "/deepsearch/chat") upstreamPath = "/chat";
      if (method === "POST" && path === "/deepsearch/deep-search") upstreamPath = "/deep-search";

      if (!upstreamPath) {
        return new Response("Route not found", { status: 404, headers: corsHeaders(request) });
      }

      // Forward request body as-is (JSON)
      const upstreamUrl = base + upstreamPath + (url.search || "");
      const contentType = request.headers.get("Content-Type") || "application/json";
      const bodyText = method === "GET" || method === "HEAD" ? null : await request.text();
      const upstreamHeaders = { "Content-Type": contentType };
      if (env.DEEPSEARCH_INTERNAL_KEY) upstreamHeaders["X-Internal-Key"] = env.DEEPSEARCH_INTERNAL_KEY;

      const upstreamResp = await fetch(upstreamUrl, {
        method,
        headers: upstreamHeaders,
        body: bodyText
      });

      if (method === "POST" && path === "/deepsearch/chat" && upstreamResp.ok) {
        let chatJson = null;
        try {
          chatJson = await upstreamResp.json();
        } catch (e) {
          chatJson = null;
        }

        const chatOutput = (chatJson && typeof chatJson.chat_output === "string") ? chatJson.chat_output : "";
        const readyPhrases = [
          /please\s+press\s+the\s+deep\s+search\s+button/i,
          /press\s+the\s+deep\s+search\s+button/i,
          /من\s*فضلك\s*اضغط/i,
          /اضغط\s*على\s*زر\s*البحث\s*العميق/i
        ];
        const hasFlag = chatJson && chatJson.should_deep_search === true;
        const shouldAuto = hasFlag || readyPhrases.some((r) => r.test(chatOutput));

        if (shouldAuto && chatJson && chatJson.session_id) {
          const readTextSafe = async (resp) => {
            try {
              const t = await resp.text();
              return (t || "").slice(0, 2000);
            } catch {
              return "";
            }
          };

          const deepBody = JSON.stringify({ session_id: chatJson.session_id, query: null });
          const deepController = new AbortController();
          const deepTimeout = setTimeout(() => deepController.abort(), 25000);

          let deepResp = null;
          try {
            deepResp = await fetch(base + "/deep-search", {
              method: "POST",
              headers: { ...upstreamHeaders, "Content-Type": "application/json" },
              body: deepBody,
              signal: deepController.signal
            });
          } catch {
            deepResp = null;
          } finally {
            clearTimeout(deepTimeout);
          }

          if (!deepResp) {
            chatJson.deep_search = { ok: false, status: 0, error: "deep_search_fetch_failed" };
          } else {
            const deepContentType = deepResp.headers.get("content-type") || "";
            if (deepContentType.includes("application/json")) {
              try {
                chatJson.deep_search = await deepResp.json();
              } catch {
                chatJson.deep_search = {
                  ok: false,
                  status: deepResp.status,
                  error: "deep_search_invalid_json",
                  body: await readTextSafe(deepResp)
                };
              }
            } else {
              chatJson.deep_search = {
                ok: deepResp.ok,
                status: deepResp.status,
                content_type: deepContentType,
                body: await readTextSafe(deepResp)
              };
            }
          }
        }

        const headers = new Headers({ "Content-Type": "application/json" });
        const cors = corsHeaders(request);
        for (const [k, v] of Object.entries(cors)) headers.set(k, v);
        return new Response(JSON.stringify(chatJson ?? {}), { status: 200, headers });
      }

      const headers = new Headers(upstreamResp.headers);
      const cors = corsHeaders(request);
      for (const [k, v] of Object.entries(cors)) headers.set(k, v);
      return new Response(upstreamResp.body, { status: upstreamResp.status, headers });
    }

    if (path.startsWith("/demand/")) {
      const base = (env.DEMAND_BASE_URL || "").replace(/\/+$/, "");
      if (!base) {
        return new Response(
          JSON.stringify({ error: "DEMAND_BASE_URL_MISSING" }),
          { status: 500, headers: { "Content-Type": "application/json", ...corsHeaders(request) } }
        );
      }

      const upstreamPath = path.replace(/^\/demand/, "");
      if (!upstreamPath || upstreamPath === "/") {
        return new Response("Route not found", { status: 404, headers: corsHeaders(request) });
      }

      const upstreamUrl = base + upstreamPath + (url.search || "");
      const contentType = request.headers.get("Content-Type") || "application/json";
      const bodyText = method === "GET" || method === "HEAD" ? null : await request.text();
      const upstreamHeaders = { "Content-Type": contentType };
      const internalKey = env.DEMAND_INTERNAL_API_KEY;
      if (internalKey) upstreamHeaders["X-Internal-Key"] = internalKey;

      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 25000);
      let upstreamResp = null;
      try {
        upstreamResp = await fetch(upstreamUrl, { method, headers: upstreamHeaders, body: bodyText, signal: controller.signal });
      } catch {
        upstreamResp = null;
      } finally {
        clearTimeout(timeout);
      }

      if (!upstreamResp) {
        return new Response(
          JSON.stringify({ ok: false, status: 0, error: "upstream_fetch_failed" }),
          { status: 502, headers: { "Content-Type": "application/json", ...corsHeaders(request) } }
        );
      }

      const headers = new Headers(upstreamResp.headers);
      const cors = corsHeaders(request);
      for (const [k, v] of Object.entries(cors)) headers.set(k, v);
      return new Response(upstreamResp.body, { status: upstreamResp.status, headers });
    }

    if (path.startsWith("/analytics/")) {
      const cors = corsHeaders(request);
      const SUPABASE_KEY = env.SUPABASE_ROLE_KEY || env.SUPABASE_SERVICE_ROLE_KEY || env.SUPABASE_ANON_KEY;
      if (!SUPABASE_KEY) {
        return new Response(JSON.stringify({ error: "SUPABASE_KEY_MISSING" }), {
          status: 500,
          headers: { "Content-Type": "application/json", ...cors }
        });
      }

      const key = SUPABASE_KEY;
      if (!key) {
        return new Response(JSON.stringify({ error: "SUPABASE_KEY_MISSING" }), {
          status: 500,
          headers: { "Content-Type": "application/json", ...cors }
        });
      }

      if (method === "POST" && path === "/analytics/event") {
        let body = null;
        try {
          body = await request.json();
        } catch {
          body = null;
        }

        const eventType = body && typeof body.event_type === "string" ? body.event_type.trim() : "";
        if (!eventType) {
          return new Response(JSON.stringify({ error: "event_type is required" }), {
            status: 400,
            headers: { "Content-Type": "application/json", ...cors }
          });
        }

        if (eventType.toLowerCase() === "page_view") {
          return new Response("[]", { status: 200, headers: { "Content-Type": "application/json", ...cors } });
        }

        const sessionId = body && typeof body.session_id === "string" ? body.session_id.trim() : null;
        const restaurantId = body && typeof body.restaurant_id === "string" ? body.restaurant_id.trim() : null;

        const insert = {
          event_type: eventType,
          session_id: sessionId,
          restaurant_id: restaurantId
        };

        const insertRes = await fetch(`${SUPABASE_URL}/rest/v1/analytics_events`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "apikey": key,
            "Authorization": `Bearer ${key}`,
            "Prefer": "return=representation"
          },
          body: JSON.stringify(insert)
        });

        const t = await insertRes.text().catch(() => "");
        return new Response(t || "[]", {
          status: insertRes.status,
          headers: { "Content-Type": "application/json", ...cors }
        });
      }

      return new Response("Route not found", { status: 404, headers: cors });
    }

    const SUPABASE_KEY = env.SUPABASE_ROLE_KEY || env.SUPABASE_SERVICE_ROLE_KEY || env.SUPABASE_ANON_KEY;

    // ---------------- PROFILE LOOKUP (SUPABASE) ----------------
    // Get profile_id + role from Firebase UID.
    async function getProfile(firebase_uid) {
      const res = await fetch(`${SUPABASE_URL}/rest/v1/profiles?firebase_uid=eq.${firebase_uid}&select=id,role,full_name,email`, {
        headers: {
          "apikey": SUPABASE_KEY,
          "Authorization": `Bearer ${SUPABASE_KEY}`
        }
      });

      const data = await res.json();
      if (!data || data.length === 0) throw new Error("Profile not found");
      return {
        profile_id: data[0].id,
        role: data[0].role,
        full_name: data[0].full_name ?? null,
        email: data[0].email ?? null
      };
    }

    let profile;
    try {
      profile = await getProfile(firebase_uid);
    } catch (err) {
      profile = null;
    }

    const supabaseHeaders = {
      "apikey": SUPABASE_KEY,
      "Authorization": `Bearer ${SUPABASE_KEY}`
    };

    async function fetchRestaurantByProfile(profileId, selectFields = "id,is_active,is_accepting_orders,pause_reason,accepting_orders_updated_at,name,img_url,rest_img_url,description,address,created_at") {
      const res = await fetch(`${SUPABASE_URL}/rest/v1/restaurants?profile_id=eq.${profileId}&select=${encodeURIComponent(selectFields)}`, {
        headers: supabaseHeaders
      });
      const text = await res.text().catch(() => "");
      let rows = [];
      try { rows = JSON.parse(text || "[]"); } catch { rows = []; }
      return { res, text, restaurant: Array.isArray(rows) ? rows[0] : null };
    }

    function getCairoWeekdayAndTime(now = new Date()) {
      const weekdayName = new Intl.DateTimeFormat("en-US", {
        timeZone: "Africa/Cairo",
        weekday: "long"
      }).format(now);
      const time = new Intl.DateTimeFormat("en-GB", {
        timeZone: "Africa/Cairo",
        hour12: false,
        hour: "2-digit",
        minute: "2-digit",
        second: "2-digit"
      }).format(now);
      const weekdayMap = {
        Monday: 0,
        Tuesday: 1,
        Wednesday: 2,
        Thursday: 3,
        Friday: 4,
        Saturday: 5,
        Sunday: 6
      };
      return {
        day_of_week: weekdayMap[weekdayName],
        current_time: time
      };
    }

    function timeInWindow(currentTime, openTime, closeTime) {
      if (!openTime || !closeTime) return true;
      const current = String(currentTime).slice(0, 8);
      const start = String(openTime).slice(0, 8);
      const end = String(closeTime).slice(0, 8);
      if (start <= end) return current >= start && current <= end;
      return current >= start || current <= end;
    }

    async function fetchOpeningHoursMap(restaurantIds) {
      const ids = Array.from(new Set((restaurantIds || []).filter((v) => typeof v === "string" && v.trim().length > 0)));
      if (ids.length === 0) return {};
      const { day_of_week } = getCairoWeekdayAndTime();
      const params = new URLSearchParams();
      params.set("select", "restaurant_id,day_of_week,open_time,close_time,is_closed");
      params.set("restaurant_id", `in.(${ids.join(",")})`);
      if (typeof day_of_week === "number") {
        params.set("day_of_week", `eq.${day_of_week}`);
      }
      const res = await fetch(`${SUPABASE_URL}/rest/v1/restaurant_opening_hours?${params.toString()}`, {
        headers: supabaseHeaders
      });
      if (!res.ok) return {};
      let rows = [];
      try { rows = await res.json(); } catch { rows = []; }
      const out = {};
      for (const row of Array.isArray(rows) ? rows : []) {
        const rid = row?.restaurant_id;
        if (typeof rid !== "string" || !rid.trim()) continue;
        if (!out[rid]) out[rid] = [];
        out[rid].push(row);
      }
      return out;
    }

    function computeRestaurantOrderability(restaurant, openingHoursMap = {}) {
      const rid = restaurant?.id;
      const isActive = restaurant?.is_active !== false;
      const isAcceptingOrders = restaurant?.is_accepting_orders !== false;
      let isOpenNow = null;
      if (typeof rid === "string" && rid.trim()) {
        const rows = openingHoursMap[rid] || [];
        if (rows.length > 0) {
          const { current_time } = getCairoWeekdayAndTime();
          let hasOpenWindow = false;
          isOpenNow = false;
          for (const row of rows) {
            if (row?.is_closed) continue;
            hasOpenWindow = true;
            if (timeInWindow(current_time, row?.open_time, row?.close_time)) {
              isOpenNow = true;
              break;
            }
          }
          if (!hasOpenWindow) isOpenNow = false;
        }
      }
      const isOrderableNow = Boolean(isActive && isAcceptingOrders && isOpenNow !== false);
      return {
        ...restaurant,
        is_accepting_orders: isAcceptingOrders,
        is_open_now: isOpenNow,
        is_orderable_now: isOrderableNow
      };
    }

    async function annotateRestaurantsWithOrderability(restaurants) {
      const ids = (Array.isArray(restaurants) ? restaurants : [])
        .map((r) => r?.id)
        .filter((v) => typeof v === "string" && v.trim().length > 0);
      const openingHoursMap = await fetchOpeningHoursMap(ids);
      return (Array.isArray(restaurants) ? restaurants : []).map((restaurant) =>
        computeRestaurantOrderability(restaurant, openingHoursMap)
      );
    }

    async function annotateMealsWithOrderability(meals, { requireOrderable = false } = {}) {
      const rows = Array.isArray(meals) ? meals : [];
      const restaurantIds = rows
        .map((meal) => meal?.restaurants?.id || meal?.restaurant_id)
        .filter((v) => typeof v === "string" && v.trim().length > 0);
      const openingHoursMap = await fetchOpeningHoursMap(restaurantIds);
      const out = [];
      for (const meal of rows) {
        const restaurant = meal?.restaurants;
        if (!restaurant || typeof restaurant !== "object") continue;
        const enrichedRestaurant = computeRestaurantOrderability(restaurant, openingHoursMap);
        if (requireOrderable && !enrichedRestaurant.is_orderable_now) continue;
        out.push({
          ...meal,
          restaurants: enrichedRestaurant,
          is_open_now: enrichedRestaurant.is_open_now,
          is_orderable_now: enrichedRestaurant.is_orderable_now
        });
      }
      return out;
    }

    function enrichOfferRow(offer, enrichedRestaurant = null) {
      const meal = offer?.meals && typeof offer.meals === "object" ? offer.meals : null;
      const imageUrl =
        (typeof offer?.offer_img_url === "string" && offer.offer_img_url.trim())
          ? offer.offer_img_url.trim()
          : ((typeof meal?.meal_img_url === "string" && meal.meal_img_url.trim()) ? meal.meal_img_url.trim() : null);
      const title =
        (typeof offer?.title === "string" && offer.title.trim())
          ? offer.title.trim()
          : ((typeof meal?.title === "string" && meal.title.trim()) ? meal.title.trim() : null);
      const description =
        (typeof offer?.description === "string" && offer.description.trim())
          ? offer.description.trim()
          : ((typeof meal?.description === "string" && meal.description.trim()) ? meal.description.trim() : null);
      const originalPriceRaw =
        typeof offer?.original_price === "number"
          ? offer.original_price
          : (typeof offer?.original_price === "string" && offer.original_price !== "" ? Number(offer.original_price) : null);
      const offerPriceRaw =
        typeof offer?.offer_price === "number"
          ? offer.offer_price
          : (typeof offer?.offer_price === "string" && offer.offer_price !== "" ? Number(offer.offer_price) : null);
      const originalPrice = Number.isFinite(originalPriceRaw) ? Math.trunc(originalPriceRaw) : null;
      const offerPrice = Number.isFinite(offerPriceRaw) ? Math.trunc(offerPriceRaw) : null;
      const discountPercent =
        Number.isFinite(originalPrice) && Number.isFinite(offerPrice) && originalPrice > 0 && offerPrice >= 0 && offerPrice <= originalPrice
          ? Math.round(((originalPrice - offerPrice) / originalPrice) * 100)
          : null;
      const restaurant = enrichedRestaurant || offer?.restaurants || null;
      return {
        ...offer,
        title,
        description,
        offer_img_url: imageUrl,
        image_url: imageUrl,
        original_price: originalPrice,
        offer_price: offerPrice,
        discount_percent: discountPercent,
        restaurants: restaurant,
        is_open_now: restaurant?.is_open_now ?? null,
        is_orderable_now: restaurant?.is_orderable_now ?? null
      };
    }

    async function annotateOffersWithOrderability(offers, { requireOrderable = false } = {}) {
      const rows = Array.isArray(offers) ? offers : [];
      const restaurantIds = rows
        .map((offer) => offer?.restaurants?.id || offer?.restaurant_id)
        .filter((v) => typeof v === "string" && v.trim().length > 0);
      const openingHoursMap = await fetchOpeningHoursMap(restaurantIds);
      const out = [];
      for (const offer of rows) {
        const restaurant = offer?.restaurants;
        if (!restaurant || typeof restaurant !== "object") continue;
        const enrichedRestaurant = computeRestaurantOrderability(restaurant, openingHoursMap);
        if (requireOrderable && !enrichedRestaurant.is_orderable_now) continue;
        out.push(enrichOfferRow(offer, enrichedRestaurant));
      }
      return out;
    }

    async function fetchMealForRestaurant(restaurantId, mealId) {
      if (typeof restaurantId !== "string" || !restaurantId.trim()) return null;
      if (typeof mealId !== "string" || !mealId.trim()) return null;
      const select = "id,restaurant_id,title,description,price,meal_img_url,category,cuisine,tags,is_available,expiry_time";
      const mealRes = await fetch(
        `${SUPABASE_URL}/rest/v1/meals?id=eq.${mealId}&restaurant_id=eq.${restaurantId}&select=${encodeURIComponent(select)}&limit=1`,
        { headers: supabaseHeaders }
      );
      if (!mealRes.ok) return null;
      let rows = [];
      try { rows = await mealRes.json(); } catch { rows = []; }
      return Array.isArray(rows) ? (rows[0] ?? null) : null;
    }

    async function fetchActiveOffersMapByMealIds(mealIds) {
      const ids = Array.from(new Set((mealIds || []).filter((v) => typeof v === "string" && v.trim())));
      if (ids.length === 0) return {};
      const nowIso = new Date().toISOString();
      const params = new URLSearchParams();
      params.set("meal_id", `in.(${ids.join(",")})`);
      params.set("is_active", "eq.true");
      params.set("and", `(or(starts_at.is.null,starts_at.lte.${nowIso}),or(expires_at.is.null,expires_at.gt.${nowIso}))`);
      params.set("select", "id,meal_id,title,description,offer_img_url,original_price,offer_price,quantity,is_active,category,cuisine,tags,starts_at,expires_at,created_at,updated_at");
      params.set("order", "created_at.desc");
      const res = await fetch(`${SUPABASE_URL}/rest/v1/offers?${params.toString()}`, {
        headers: supabaseHeaders
      });
      if (!res.ok) return {};
      let rows = [];
      try { rows = await res.json(); } catch { rows = []; }
      const out = {};
      for (const row of Array.isArray(rows) ? rows : []) {
        if (row?.quantity !== null && row?.quantity !== undefined) {
          const qty = Number(row.quantity);
          if (Number.isFinite(qty) && qty <= 0) continue;
        }
        const mealId = row?.meal_id;
        if (typeof mealId !== "string" || !mealId.trim()) continue;
        if (!out[mealId]) out[mealId] = row;
      }
      return out;
    }

    async function attachMealOffers(meals, { hideMealsWithActiveOffer = false } = {}) {
      const rows = Array.isArray(meals) ? meals : [];
      const mealIds = rows.map((meal) => meal?.id).filter((v) => typeof v === "string" && v.trim());
      const offersMap = await fetchActiveOffersMapByMealIds(mealIds);
      const out = [];
      for (const meal of rows) {
        const activeOffer = meal?.id ? (offersMap[meal.id] || null) : null;
        if (hideMealsWithActiveOffer && activeOffer) continue;
        out.push({
          ...meal,
          active_offer: activeOffer ? enrichOfferRow(activeOffer) : null,
          has_active_offer: Boolean(activeOffer)
        });
      }
      return out;
    }

    //-----------------RECOMMENDATION SYSTEM------------------
    if (path.startsWith("/recommend")) {
      const cors = corsHeaders(request);

      if (!firebase_uid) {
        return new Response(JSON.stringify({ error: "UNAUTHORIZED" }), {
          status: 401,
          headers: { "Content-Type": "application/json", ...cors }
        });
      }

      if (!profile || profile.role !== "user") {
        return new Response(JSON.stringify({ error: "ONLY_USERS_CAN_ACCESS_RECOMMEND" }), {
          status: 403,
          headers: { "Content-Type": "application/json", ...cors }
        });
      }

      if (!RECOMMEND_BASE_URL) {
        return new Response(JSON.stringify({ error: "RECOMMEND_BASE_URL_NOT_SET" }), {
          status: 500,
          headers: { "Content-Type": "application/json", ...cors }
        });
      }

      const upstreamUrl = new URL(`${RECOMMEND_BASE_URL}/recommend`);
      upstreamUrl.searchParams.set("user_id", firebase_uid);
      for (const key of ["topn", "candidate_limit", "use_cache"]) {
        const value = url.searchParams.get(key);
        if (typeof value === "string" && value.trim() !== "") {
          upstreamUrl.searchParams.set(key, value.trim());
        }
      }

      const resp = await fetch(upstreamUrl.toString(), {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
          ...(RECOMMEND_API_KEY ? { "x-api-key": RECOMMEND_API_KEY } : {})
        }
      });

      const rawBody = await resp.text().catch(() => "");
      const upstreamContentType = resp.headers.get("Content-Type") || "application/json";
      let responseBody = rawBody || "{}";
      let responseContentType = upstreamContentType;

      if (upstreamContentType.includes("application/json")) {
        try {
          responseBody = JSON.stringify(JSON.parse(rawBody || "{}"));
          responseContentType = "application/json";
        } catch {
          responseBody = JSON.stringify({
            error: "RECOMMEND_UPSTREAM_INVALID_JSON",
            status: resp.status,
            detail: rawBody || ""
          });
          responseContentType = "application/json";
        }
      }

      if (resp.status === 401) {
        return new Response(JSON.stringify({
          error: "RECOMMEND_UPSTREAM_UNAUTHORIZED",
          detail: "Recommendation service rejected the internal API key or auth configuration"
        }), {
          status: 502,
          headers: { "Content-Type": "application/json", ...cors }
        });
      }

      return new Response(responseBody, {
        status: resp.status,
        headers: { "Content-Type": responseContentType, ...cors }
      });
    }

    if (!profile && firebase_is_social && (path.startsWith("/profile") || path.startsWith("/user"))) {
      const expectedRole = url.searchParams.get("expected_role");
      if (expectedRole && expectedRole !== "user") {
        return new Response(
          JSON.stringify({
            error: "ROLE_MISMATCH",
            expected_role: expectedRole,
            actual_role: "user"
          }),
          {
            status: 403,
            headers: { "Content-Type": "application/json", ...corsHeaders(request) }
          }
        );
      }

      const email = typeof firebase_email === "string" ? firebase_email : null;
      const full_name = typeof firebase_name === "string" && firebase_name ? firebase_name : (email && email.includes("@") ? email.split("@")[0] : "User");

      if (!email && path === "/profile/me") {
        const providerLabel = firebase_is_facebook ? "Facebook" : "Google";
        const errorCode = firebase_is_facebook ? "FACEBOOK_EMAIL_MISSING" : "GOOGLE_EMAIL_MISSING";
        return new Response(
          JSON.stringify({
            error: errorCode,
            message: `${providerLabel} login did not return an email address. Ensure the provider is configured to return email, and the user granted the email permission/scope.`
          }),
          {
            status: 400,
            headers: { "Content-Type": "application/json", ...corsHeaders(request) }
          }
        );
      }

      if (email) {
        const headers = {
          "Content-Type": "application/json",
          "apikey": SUPABASE_KEY,
          "Authorization": `Bearer ${SUPABASE_KEY}`
        };

        let provisioned = false;

        const ensureResp = await fetch(`${SUPABASE_URL}/rest/v1/rpc/ensure_user_profile`, {
          method: "POST",
          headers,
          body: JSON.stringify({
            p_firebase_uid: firebase_uid,
            p_email: email,
            p_full_name: full_name
          })
        });

        const ensureText = await ensureResp.text().catch(() => "");
        const ensureLower = (ensureText || "").toLowerCase();
        if (ensureLower.includes("role_mismatch")) {
          return new Response(
            JSON.stringify({
              error: "ROLE_MISMATCH",
              expected_role: "user"
            }),
            {
              status: 403,
              headers: { "Content-Type": "application/json", ...corsHeaders(request) }
            }
          );
        }

        if (ensureResp.ok) {
          provisioned = true;
        } else {
          const fallbackResp = await fetch(`${SUPABASE_URL}/rest/v1/rpc/register_user`, {
            method: "POST",
            headers,
            body: JSON.stringify({
              p_full_name: full_name,
              p_email: email,
              p_role: "user",
              p_firebase_uid: firebase_uid
            })
          });
          const fallbackText = await fallbackResp.text().catch(() => "");
          const fallbackLower = (fallbackText || "").toLowerCase();
          if (fallbackLower.includes("role_mismatch")) {
            return new Response(
              JSON.stringify({
                error: "ROLE_MISMATCH",
                expected_role: "user"
              }),
              {
                status: 403,
                headers: { "Content-Type": "application/json", ...corsHeaders(request) }
              }
            );
          }

          if (!fallbackResp.ok && path === "/profile/me") {
            return new Response(
              JSON.stringify({
                error: "PROFILE_PROVISION_FAILED",
                ensure_status: ensureResp.status,
                ensure_body: ensureText,
                fallback_status: fallbackResp.status,
                fallback_body: fallbackText
              }),
              {
                status: 500,
                headers: { "Content-Type": "application/json", ...corsHeaders(request) }
              }
            );
          }

          provisioned = fallbackResp.ok;
        }

        if (provisioned) {
          try {
            profile = await getProfile(firebase_uid);
          } catch {
            profile = null;
          }
        }
      }
    }

    if (!profile && !path.startsWith("/signup")) {
      const extra = path === "/profile/me"
        ? {
          firebase_is_google,
          firebase_is_facebook,
          firebase_is_social,
          firebase_sign_in_provider: firebase_sign_in_provider ?? null,
          has_email: typeof firebase_email === "string" && !!firebase_email
        }
        : null;

      return new Response(
        JSON.stringify({
          error: "PROFILE_NOT_FOUND",
          message: "User must complete signup",
          ...(extra ? { debug: extra } : {})
      }),
      {
        status: 403,
        headers: {
          "Content-Type": "application/json",
          ...corsHeaders(request)
        }
      }
    );
  }

    // ---------------- SUPABASE RPC HELPER ----------------
    // Calls Postgres functions via Supabase RPC.
    async function callRPC(functionName, body, req) {
      const cors = corsHeaders(req);
      const response = await fetch(`${SUPABASE_URL}/rest/v1/rpc/${functionName}`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "apikey": SUPABASE_KEY,
          "Authorization": `Bearer ${SUPABASE_KEY}`
        },
        body: JSON.stringify(body)
      });
      const text = await response.text();
      return new Response(text, {
        status: response.status,
        headers: {
          "Content-Type": "application/json",
          ...cors
        }
      });
    }

    async function putMealImageToR2({ file, profile_id }) {
      const bucket = env.MEALS_BUCKET;
      if (!bucket) throw new Error("R2 bucket not configured");

      const name = (file && typeof file.name === "string") ? file.name : "image";
      const type = (file && typeof file.type === "string" && file.type) ? file.type : "application/octet-stream";
      const ext = name.includes(".") ? name.split(".").pop() : "";
      const safeExt = (ext || (type === "image/jpeg" ? "jpg" : type === "image/png" ? "png" : type === "image/webp" ? "webp" : "bin")).replace(/[^a-zA-Z0-9]/g, "");
      const key = `meals/${profile_id}/${Date.now()}-${crypto.randomUUID()}.${safeExt}`;

      const buf = await file.arrayBuffer();
      await bucket.put(key, buf, { httpMetadata: { contentType: type } });

      const publicBase = (env.R2_PUBLIC_BASE_URL || `${url.origin}/r2`).replace(/\/+$/, "");
      return { key, url: `${publicBase}/${encodeURIComponent(key)}` };
    }

    async function putRestaurantImageToR2({ file, profile_id }) {
      const bucket = env.MEALS_BUCKET;
      if (!bucket) throw new Error("R2 bucket not configured");

      const name = (file && typeof file.name === "string") ? file.name : "image";
      const type = (file && typeof file.type === "string" && file.type) ? file.type : "application/octet-stream";
      const ext = name.includes(".") ? name.split(".").pop() : "";
      const safeExt = (ext || (type === "image/jpeg" ? "jpg" : type === "image/png" ? "png" : type === "image/webp" ? "webp" : "bin")).replace(/[^a-zA-Z0-9]/g, "");
      const key = `restaurants/${profile_id}/${Date.now()}-${crypto.randomUUID()}.${safeExt}`;

      const buf = await file.arrayBuffer();
      await bucket.put(key, buf, { httpMetadata: { contentType: type } });

      const publicBase = (env.R2_PUBLIC_BASE_URL || `${url.origin}/r2`).replace(/\/+$/, "");
      return { key, url: `${publicBase}/${encodeURIComponent(key)}` };
      
    }
// ─────────────────────────────────────────────────────────────────────────────
// PUSH NOTIFICATION HELPERS
// ─────────────────────────────────────────────────────────────────────────────

    function b64UrlDecode(str) {
      const pad = str.length % 4 === 0 ? "" : "=".repeat(4 - (str.length % 4));
      return Uint8Array.from(
        atob(str.replace(/-/g, "+").replace(/_/g, "/") + pad),
        c => c.charCodeAt(0)
      );
    }

    function b64UrlEncode(buf) {
      return btoa(String.fromCharCode(...new Uint8Array(buf)))
        .replace(/\+/g, "-").replace(/\//g, "_").replace(/=/g, "");
    }

    async function buildVapidAuthHeader(endpoint) {
      const VAPID_PUBLIC_KEY  = env.VAPID_PUBLIC_KEY;
      const VAPID_PRIVATE_KEY = env.VAPID_PRIVATE_KEY;
      const VAPID_SUBJECT     = env.VAPID_SUBJECT || "mailto:admin@eat2beat.com";
      if (!VAPID_PUBLIC_KEY || !VAPID_PRIVATE_KEY) return null;

      const audience = new URL(endpoint).origin;
      const exp      = Math.floor(Date.now() / 1000) + 12 * 3600;
      const header   = b64UrlEncode(new TextEncoder().encode(JSON.stringify({ typ: "JWT", alg: "ES256" })));
      const payload  = b64UrlEncode(new TextEncoder().encode(JSON.stringify({ aud: audience, exp, sub: VAPID_SUBJECT })));
      const unsigned = `${header}.${payload}`;

      const privKey = await crypto.subtle.importKey(
        "pkcs8",
        b64UrlDecode(VAPID_PRIVATE_KEY),
        { name: "ECDSA", namedCurve: "P-256" },
        false,
        ["sign"]
      );
      const sig = await crypto.subtle.sign(
        { name: "ECDSA", hash: "SHA-256" },
        privKey,
        new TextEncoder().encode(unsigned)
      );
      const jwt = `${unsigned}.${b64UrlEncode(sig)}`;
      return `vapid t=${jwt}, k=${VAPID_PUBLIC_KEY}`;
    }

    async function encryptPushPayload(p256dhB64, authB64, plaintext) {
      const enc      = new TextEncoder();
      const plainBuf = enc.encode(typeof plaintext === "string" ? plaintext : JSON.stringify(plaintext));

      const receiverPubKey = await crypto.subtle.importKey(
        "raw",
        b64UrlDecode(p256dhB64),
        { name: "ECDH", namedCurve: "P-256" },
        true,
        []
      );

      // @ts-ignore
      const senderKeyPair  = await crypto.subtle.generateKey({ name: "ECDH", namedCurve: "P-256" }, true, ["deriveBits"]);
      // @ts-ignore
      const senderPrivKey  = senderKeyPair.privateKey;
      // @ts-ignore
      const senderPubKey   = senderKeyPair.publicKey;

      // @ts-ignore
      const senderPubBytes   = new Uint8Array(await crypto.subtle.exportKey("raw", senderPubKey));
      const receiverPubBytes = b64UrlDecode(p256dhB64);

      // @ts-ignore
      const sharedBits = await crypto.subtle.deriveBits({ name: "ECDH", public: receiverPubKey }, senderPrivKey, 256);

      const authSecretBytes = b64UrlDecode(authB64);
      const prkBaseKey = await crypto.subtle.importKey("raw", authSecretBytes, "HKDF", false, ["deriveBits"]);
      const prkBits    = await crypto.subtle.deriveBits(
        { name: "HKDF", hash: "SHA-256", salt: new Uint8Array(32), info: enc.encode("Content-Encoding: auth\0") },
        prkBaseKey,
        256
      );

      const sharedBaseKey = await crypto.subtle.importKey("raw", sharedBits, "HKDF", false, ["deriveBits"]);
      const salt          = crypto.getRandomValues(new Uint8Array(16));

      const keyInfo = new Uint8Array([
        ...enc.encode("Content-Encoding: aesgcm\0"), 0x00, 0x41,
        ...senderPubBytes, 0x00, 0x41,
        ...receiverPubBytes
      ]);
      const cekBits = await crypto.subtle.deriveBits(
        { name: "HKDF", hash: "SHA-256", salt: prkBits, info: keyInfo },
        sharedBaseKey,
        128
      );

      const nonceInfo = new Uint8Array([
        ...enc.encode("Content-Encoding: nonce\0"), 0x00, 0x41,
        ...senderPubBytes, 0x00, 0x41,
        ...receiverPubBytes
      ]);
      const nonceBits = await crypto.subtle.deriveBits(
        { name: "HKDF", hash: "SHA-256", salt: prkBits, info: nonceInfo },
        sharedBaseKey,
        96
      );

      const cek   = await crypto.subtle.importKey("raw", cekBits, "AES-GCM", false, ["encrypt"]);
      const nonce = new Uint8Array(nonceBits);

      const padded = new Uint8Array(2 + plainBuf.length);
      padded.set(plainBuf, 2);

      const ciphertext = await crypto.subtle.encrypt({ name: "AES-GCM", iv: nonce }, cek, padded);

      return {
        ciphertext:   new Uint8Array(ciphertext),
        salt,
        senderPubRaw: senderPubBytes
      };
    }

    async function sendPushNotification(sub, payload) {
      try {
        const { ciphertext, salt, senderPubRaw } = await encryptPushPayload(
          sub.p256dh,
          sub.auth,
          JSON.stringify(payload)
        );

        const vapidAuth = await buildVapidAuthHeader(sub.endpoint);
        if (!vapidAuth) return false;

        const res = await fetch(sub.endpoint, {
          method: "POST",
          headers: {
            "Content-Type":     "application/octet-stream",
            "Content-Encoding": "aesgcm",
            "Encryption":       `salt=${b64UrlEncode(salt)}`,
            "Crypto-Key":       `dh=${b64UrlEncode(senderPubRaw)};${vapidAuth}`,
            "Authorization":    vapidAuth,
            "TTL":              "86400"
          },
          body: ciphertext
        });

        if (res.status === 410 || res.status === 404) {
          await fetch(
            `${SUPABASE_URL}/rest/v1/push_subscriptions?endpoint=eq.${encodeURIComponent(sub.endpoint)}`,
            {
              method:  "DELETE",
              headers: { "apikey": SUPABASE_KEY, "Authorization": `Bearer ${SUPABASE_KEY}` }
            }
          ).catch(() => {});
        }

        return res.ok;
      } catch {
        return false;
      }
    }

    async function sendPushToProfile(profileId, payload) {
      try {
        const subsRes = await fetch(
          `${SUPABASE_URL}/rest/v1/push_subscriptions?profile_id=eq.${profileId}&select=endpoint,p256dh,auth`,
          { headers: { "apikey": SUPABASE_KEY, "Authorization": `Bearer ${SUPABASE_KEY}` } }
        );
        if (!subsRes.ok) return;
        const subs = await subsRes.json();
        if (!Array.isArray(subs) || subs.length === 0) return;
        await Promise.allSettled(subs.map(sub => sendPushNotification(sub, payload)));
      } catch { }
    }

    async function notify(profileId, type, title, bodyText, linkPath, pushPayload) {
      try {
        await fetch(`${SUPABASE_URL}/rest/v1/notifications`, {
          method: "POST",
          headers: {
            "Content-Type":  "application/json",
            "apikey":        SUPABASE_KEY,
            "Authorization": `Bearer ${SUPABASE_KEY}`,
            "Prefer":        "return=minimal"
          },
          body: JSON.stringify({
            profile_id: profileId,
            type,
            title,
            body:      bodyText,
            link_path: linkPath
          })
        });
      } catch { }

      if (pushPayload) {
        await sendPushToProfile(profileId, {
          ...pushPayload,
          link: linkPath,
          icon: "/icons/icon-192.png"
        });
      }
    }


    // ---------------- ROUTES (APP API) ----------------

    // Signup route (create profile)
    if (path.startsWith("/signup")) {
      if (method === "POST" && path === "/signup/create-profile") {
        const body = await request.json();
        if (!body.full_name || !body.email || !body.role) {
          return new Response("Missing required fields", { status: 400 });
        }

        // Create a profile tied to the Firebase UID we verified above
        return callRPC("register_user", {
          p_full_name: body.full_name,
          p_email: body.email,
          p_role: body.role,
          p_firebase_uid: firebase_uid
        }, request);
      }
    }

    if (method === "GET" && path === "/profile/me") {
      const expectedRole = url.searchParams.get("expected_role");
      if (expectedRole) {
        const allowed = new Set(["user", "restaurant", "charity"]);
        if (!allowed.has(expectedRole)) {
          return new Response(
            JSON.stringify({ error: "INVALID_EXPECTED_ROLE", expected_role: expectedRole }),
            {
              status: 400,
              headers: { "Content-Type": "application/json", ...corsHeaders(request) }
            }
          );
        }

        if (profile.role !== expectedRole) {
          return new Response(
            JSON.stringify({
              error: "ROLE_MISMATCH",
              expected_role: expectedRole,
              actual_role: profile.role
            }),
            {
              status: 403,
              headers: { "Content-Type": "application/json", ...corsHeaders(request) }
            }
          );
        }
      }

      return new Response(JSON.stringify(profile), {
        status: 200,
        headers: {
          "Content-Type": "application/json",
          ...corsHeaders(request)
        }
      });
    }


// GET NOTIFICATIONS  GET /notifications
    if (method === "GET" && path === "/notifications") {
        const cors = corsHeaders(request);
        const limitRaw = url.searchParams.get("limit");
        const limit = limitRaw && Number.isFinite(Number(limitRaw))
            ? Math.max(1, Math.min(50, Math.trunc(Number(limitRaw)))) : 20;
        const unreadOnly = url.searchParams.get("unread") === "true";

        const params = new URLSearchParams();
        params.set("select", "id,type,title,body,link_path,read_at,created_at");
        params.set("profile_id", `eq.${profile.profile_id}`);
        params.set("order", "created_at.desc");
        params.set("limit", String(limit));
        if (unreadOnly) params.set("read_at", "is.null");

        const notifRes = await fetch(`${SUPABASE_URL}/rest/v1/notifications?${params}`, {
            headers: { "apikey": SUPABASE_KEY, "Authorization": `Bearer ${SUPABASE_KEY}` }
        });
        const text = await notifRes.text();

        // also return unread count in header
        const unreadRes = await fetch(
            `${SUPABASE_URL}/rest/v1/notifications?profile_id=eq.${profile.profile_id}&read_at=is.null&select=id`,
            { headers: { "apikey": SUPABASE_KEY, "Authorization": `Bearer ${SUPABASE_KEY}`, "Prefer": "count=exact" } }
        );
        const unreadCount = unreadRes.headers.get("content-range")?.split("/")?.[1] ?? "0";

        return new Response(text, {
            status: notifRes.status,
            headers: { "Content-Type": "application/json", ...cors, "X-Unread-Count": unreadCount }
        });
    }

    // MARK NOTIFICATIONS READ  POST /notifications/read
    if (method === "POST" && path === "/notifications/read") {
        const cors = corsHeaders(request);
        let body = null;
        try { body = await request.json(); } catch { body = null; }

        // if no ids supplied, mark ALL unread as read
        const ids = body && Array.isArray(body.ids) ? body.ids.filter(id => typeof id === "string") : null;

        if (ids !== null && ids.length === 0) {
            return new Response(JSON.stringify({ updated: 0 }), {
                status: 200, headers: { "Content-Type": "application/json", ...cors }
            });
        }

        if (ids !== null) {
            return callRPC("mark_notifications_read", {
                p_profile_id: profile.profile_id,
                p_notification_ids: ids
            }, request);
        }

        // mark all
        const patchRes = await fetch(
            `${SUPABASE_URL}/rest/v1/notifications?profile_id=eq.${profile.profile_id}&read_at=is.null`,
            {
                method: "PATCH",
                headers: {
                    "Content-Type": "application/json",
                    "apikey": SUPABASE_KEY,
                    "Authorization": `Bearer ${SUPABASE_KEY}`,
                    "Prefer": "return=minimal"
                },
                body: JSON.stringify({ read_at: new Date().toISOString() })
            }
        );
        return new Response(JSON.stringify({ ok: patchRes.ok }), {
            status: patchRes.ok ? 200 : patchRes.status,
            headers: { "Content-Type": "application/json", ...cors }
        });
    }

    // SAVE PUSH SUBSCRIPTION  POST /push/subscribe
    if (method === "POST" && path === "/push/subscribe") {
        const cors = corsHeaders(request);
        let body = null;
        try { body = await request.json(); } catch { body = null; }

        const endpoint = body && typeof body.endpoint === "string" ? body.endpoint.trim() : "";
        const p256dh = body && typeof body.p256dh === "string" ? body.p256dh.trim() : "";
        const auth = body && typeof body.auth === "string" ? body.auth.trim() : "";
        const ua = request.headers.get("User-Agent") || null;

        if (!endpoint || !p256dh || !auth) {
            return new Response(JSON.stringify({ error: "endpoint, p256dh and auth are required" }), {
                status: 400, headers: { "Content-Type": "application/json", ...cors }
            });
        }

        // upsert so re-subscribing the same endpoint just updates the keys
        const upsertRes = await fetch(`${SUPABASE_URL}/rest/v1/push_subscriptions`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "apikey": SUPABASE_KEY,
                "Authorization": `Bearer ${SUPABASE_KEY}`,
                "Prefer": "resolution=merge-duplicates,return=representation"
            },
            body: JSON.stringify({
                profile_id: profile.profile_id,
                endpoint,
                p256dh,
                auth,
                user_agent: ua
            })
        });
        const text = await upsertRes.text();
        return new Response(text, {
            status: upsertRes.ok ? 201 : upsertRes.status,
            headers: { "Content-Type": "application/json", ...cors }
        });
    }

    // REMOVE PUSH SUBSCRIPTION  POST /push/unsubscribe
    if (method === "POST" && path === "/push/unsubscribe") {
        const cors = corsHeaders(request);
        let body = null;
        try { body = await request.json(); } catch { body = null; }

        const endpoint = body && typeof body.endpoint === "string" ? body.endpoint.trim() : "";
        if (!endpoint) {
            return new Response(JSON.stringify({ error: "endpoint is required" }), {
                status: 400, headers: { "Content-Type": "application/json", ...cors }
            });
        }

        const delRes = await fetch(
            `${SUPABASE_URL}/rest/v1/push_subscriptions?profile_id=eq.${profile.profile_id}&endpoint=eq.${encodeURIComponent(endpoint)}`,
            {
                method: "DELETE",
                headers: { "apikey": SUPABASE_KEY, "Authorization": `Bearer ${SUPABASE_KEY}` }
            }
        );

        return new Response(JSON.stringify({ ok: delRes.ok }), {
            status: delRes.ok ? 200 : delRes.status,
            headers: { "Content-Type": "application/json", ...cors }
        });
    }

    // Restaurant routes (restaurant-only)
    if (path.startsWith("/restaurant")) {
      if (!profile || profile.role !== "restaurant") {
        return new Response("Only restaurants can access this route", { status: 403 });
      }

      if (method === "GET" && path === "/restaurant/orderability") {
        const cors = corsHeaders(request);
        const lookup = await fetchRestaurantByProfile(profile.profile_id);
        if (!lookup.res.ok) {
          return new Response(lookup.text || "Restaurant lookup failed", {
            status: lookup.res.status,
            headers: { "Content-Type": "application/json", ...cors }
          });
        }
        if (!lookup.restaurant || !lookup.restaurant.id) {
          return new Response(JSON.stringify({ error: "RESTAURANT_NOT_FOUND" }), {
            status: 400,
            headers: { "Content-Type": "application/json", ...cors }
          });
        }

        const hoursRes = await fetch(`${SUPABASE_URL}/rest/v1/restaurant_opening_hours?restaurant_id=eq.${lookup.restaurant.id}&select=id,restaurant_id,day_of_week,open_time,close_time,is_closed,created_at,updated_at&order=day_of_week.asc`, {
          headers: supabaseHeaders
        });
        const hoursText = await hoursRes.text().catch(() => "[]");
        let hours = [];
        try { hours = JSON.parse(hoursText || "[]"); } catch { hours = []; }
        const enriched = (await annotateRestaurantsWithOrderability([lookup.restaurant]))[0] || lookup.restaurant;
        return new Response(JSON.stringify({
          restaurant: enriched,
          opening_hours: Array.isArray(hours) ? hours : []
        }), {
          status: 200,
          headers: { "Content-Type": "application/json", ...cors }
        });
      }

      if (method === "POST" && path === "/restaurant/orderability/update") {
        const cors = corsHeaders(request);
        let body = {};
        try {
          body = await request.json();
        } catch {
          body = {};
        }
        if (typeof body.is_accepting_orders !== "boolean") {
          return new Response(JSON.stringify({ error: "is_accepting_orders must be boolean" }), {
            status: 400,
            headers: { "Content-Type": "application/json", ...cors }
          });
        }
        const lookup = await fetchRestaurantByProfile(profile.profile_id);
        if (!lookup.res.ok) {
          return new Response(lookup.text || "Restaurant lookup failed", {
            status: lookup.res.status,
            headers: { "Content-Type": "application/json", ...cors }
          });
        }
        if (!lookup.restaurant || !lookup.restaurant.id) {
          return new Response(JSON.stringify({ error: "RESTAURANT_NOT_FOUND" }), {
            status: 400,
            headers: { "Content-Type": "application/json", ...cors }
          });
        }

        const pauseReasonRaw = typeof body.pause_reason === "string" ? body.pause_reason.trim() : "";
        const patchPayload = {
          is_accepting_orders: body.is_accepting_orders,
          pause_reason: body.is_accepting_orders ? null : (pauseReasonRaw || null),
          accepting_orders_updated_at: new Date().toISOString()
        };
        const patchRes = await fetch(`${SUPABASE_URL}/rest/v1/restaurants?id=eq.${lookup.restaurant.id}`, {
          method: "PATCH",
          headers: {
            "Content-Type": "application/json",
            ...supabaseHeaders,
            "Prefer": "return=representation"
          },
          body: JSON.stringify(patchPayload)
        });
        const patchText = await patchRes.text().catch(() => "");
        if (!patchRes.ok) {
          return new Response(patchText || JSON.stringify({ error: "ORDERABILITY_UPDATE_FAILED" }), {
            status: patchRes.status,
            headers: { "Content-Type": "application/json", ...cors }
          });
        }
        let rows = [];
        try { rows = JSON.parse(patchText || "[]"); } catch { rows = []; }
        const enriched = (await annotateRestaurantsWithOrderability(Array.isArray(rows) ? rows : []))[0] || (Array.isArray(rows) ? rows[0] : patchPayload);
        return new Response(JSON.stringify(enriched), {
          status: 200,
          headers: { "Content-Type": "application/json", ...cors }
        });
      }

      if (method === "GET" && path === "/restaurant/opening-hours") {
        const cors = corsHeaders(request);
        const lookup = await fetchRestaurantByProfile(profile.profile_id, "id");
        if (!lookup.res.ok) {
          return new Response(lookup.text || "Restaurant lookup failed", {
            status: lookup.res.status,
            headers: { "Content-Type": "application/json", ...cors }
          });
        }
        if (!lookup.restaurant || !lookup.restaurant.id) {
          return new Response(JSON.stringify({ error: "RESTAURANT_NOT_FOUND" }), {
            status: 400,
            headers: { "Content-Type": "application/json", ...cors }
          });
        }
        const hoursRes = await fetch(`${SUPABASE_URL}/rest/v1/restaurant_opening_hours?restaurant_id=eq.${lookup.restaurant.id}&select=id,restaurant_id,day_of_week,open_time,close_time,is_closed,created_at,updated_at&order=day_of_week.asc`, {
          headers: supabaseHeaders
        });
        const hoursText = await hoursRes.text().catch(() => "[]");
        return new Response(hoursText || "[]", {
          status: hoursRes.status,
          headers: { "Content-Type": "application/json", ...cors }
        });
      }

      if (method === "POST" && path === "/restaurant/opening-hours/upsert") {
        const cors = corsHeaders(request);
        let body = {};
        try {
          body = await request.json();
        } catch {
          body = {};
        }
        const hours = Array.isArray(body?.hours) ? body.hours : [];
        if (hours.length === 0) {
          return new Response(JSON.stringify({ error: "hours array is required" }), {
            status: 400,
            headers: { "Content-Type": "application/json", ...cors }
          });
        }
        const lookup = await fetchRestaurantByProfile(profile.profile_id, "id");
        if (!lookup.res.ok) {
          return new Response(lookup.text || "Restaurant lookup failed", {
            status: lookup.res.status,
            headers: { "Content-Type": "application/json", ...cors }
          });
        }
        if (!lookup.restaurant || !lookup.restaurant.id) {
          return new Response(JSON.stringify({ error: "RESTAURANT_NOT_FOUND" }), {
            status: 400,
            headers: { "Content-Type": "application/json", ...cors }
          });
        }

        const rows = [];
        for (const item of hours) {
          const day = Number(item?.day_of_week);
          const isClosed = item?.is_closed === true;
          const openTime = typeof item?.open_time === "string" && item.open_time.trim() ? item.open_time.trim() : null;
          const closeTime = typeof item?.close_time === "string" && item.close_time.trim() ? item.close_time.trim() : null;
          if (!Number.isInteger(day) || day < 0 || day > 6) {
            return new Response(JSON.stringify({ error: "day_of_week must be integer between 0 and 6" }), {
              status: 400,
              headers: { "Content-Type": "application/json", ...cors }
            });
          }
          if (!isClosed && (!openTime || !closeTime)) {
            return new Response(JSON.stringify({ error: "open_time and close_time are required unless is_closed=true" }), {
              status: 400,
              headers: { "Content-Type": "application/json", ...cors }
            });
          }
          rows.push({
            restaurant_id: lookup.restaurant.id,
            day_of_week: day,
            open_time: isClosed ? null : openTime,
            close_time: isClosed ? null : closeTime,
            is_closed: isClosed
          });
        }

        const upsertRes = await fetch(`${SUPABASE_URL}/rest/v1/restaurant_opening_hours?on_conflict=restaurant_id,day_of_week`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            ...supabaseHeaders,
            "Prefer": "resolution=merge-duplicates,return=representation"
          },
          body: JSON.stringify(rows)
        });
        const upsertText = await upsertRes.text().catch(() => "");
        return new Response(upsertText || "[]", {
          status: upsertRes.status,
          headers: { "Content-Type": "application/json", ...cors }
        });
      }

      if (method === "GET" && path === "/restaurant/offers") {
        const cors = corsHeaders(request);
        const includeInactive = (url.searchParams.get("include_inactive") || "").toLowerCase() === "true";
        const lookup = await fetchRestaurantByProfile(profile.profile_id, "id,is_active");
        if (!lookup.res.ok) {
          return new Response(lookup.text || "Restaurant lookup failed", {
            status: lookup.res.status,
            headers: { "Content-Type": "application/json", ...cors }
          });
        }
        if (!lookup.restaurant || !lookup.restaurant.id) {
          return new Response(JSON.stringify({ error: "RESTAURANT_NOT_FOUND" }), {
            status: 400,
            headers: { "Content-Type": "application/json", ...cors }
          });
        }
        const params = new URLSearchParams();
        params.set("restaurant_id", `eq.${lookup.restaurant.id}`);
        params.set(
          "select",
          "id,restaurant_id,meal_id,title,description,offer_img_url,original_price,offer_price,quantity,is_active,category,cuisine,tags,starts_at,expires_at,created_at,updated_at,meals(id,title,description,price,meal_img_url),restaurants!inner(id,name,img_url,rest_img_url,is_active,is_accepting_orders,pause_reason,accepting_orders_updated_at)"
        );
        params.set("order", "created_at.desc");
        if (!includeInactive) params.set("is_active", "eq.true");
        const offersRes = await fetch(`${SUPABASE_URL}/rest/v1/offers?${params.toString()}`, {
          headers: supabaseHeaders
        });
        const offersText = await offersRes.text().catch(() => "[]");
        if (!offersRes.ok) {
          return new Response(offersText || JSON.stringify({ error: "OFFERS_FETCH_FAILED" }), {
            status: offersRes.status,
            headers: { "Content-Type": "application/json", ...cors }
          });
        }
        let rows = [];
        try { rows = JSON.parse(offersText || "[]"); } catch { rows = []; }
        const annotated = await annotateOffersWithOrderability(rows, { requireOrderable: false });
        return new Response(JSON.stringify(annotated), {
          status: 200,
          headers: { "Content-Type": "application/json", ...cors }
        });
      }

      if (method === "POST" && path === "/restaurant/offers/create") {
        const cors = corsHeaders(request);
        let body = {};
        try {
          body = await request.json();
        } catch {
          body = {};
        }
        const lookup = await fetchRestaurantByProfile(profile.profile_id, "id,is_active");
        if (!lookup.res.ok) {
          return new Response(lookup.text || "Restaurant lookup failed", {
            status: lookup.res.status,
            headers: { "Content-Type": "application/json", ...cors }
          });
        }
        if (!lookup.restaurant || !lookup.restaurant.id) {
          return new Response(JSON.stringify({ error: "RESTAURANT_NOT_FOUND" }), {
            status: 400,
            headers: { "Content-Type": "application/json", ...cors }
          });
        }
        if (lookup.restaurant.is_active === false) {
          return new Response(JSON.stringify({ error: "RESTAURANT_INACTIVE" }), {
            status: 403,
            headers: { "Content-Type": "application/json", ...cors }
          });
        }

        const mealId = typeof body?.meal_id === "string" && body.meal_id.trim() ? body.meal_id.trim() : null;
        const linkedMeal = mealId ? await fetchMealForRestaurant(lookup.restaurant.id, mealId) : null;
        if (mealId && (!linkedMeal || !linkedMeal.id)) {
          return new Response(JSON.stringify({ error: "MEAL_NOT_FOUND_FOR_RESTAURANT" }), {
            status: 400,
            headers: { "Content-Type": "application/json", ...cors }
          });
        }

        let offerImgUrl = typeof body?.offer_img_url === "string" && body.offer_img_url.trim() ? body.offer_img_url.trim() : "";
        if (!offerImgUrl && typeof body?.offer_img_base64 === "string" && body.offer_img_base64.trim()) {
          const match = body.offer_img_base64.match(/^data:(.+?);base64,(.+)$/);
          if (!match) {
            return new Response(JSON.stringify({ error: "INVALID_BASE64_IMAGE" }), {
              status: 400,
              headers: { "Content-Type": "application/json", ...cors }
            });
          }
          const mime = match[1];
          const b64 = match[2];
          const bin = Uint8Array.from(atob(b64), (c) => c.charCodeAt(0));
          const file = new File([bin], `offer.${mime === "image/jpeg" ? "jpg" : mime === "image/png" ? "png" : mime === "image/webp" ? "webp" : "bin"}`, { type: mime });
          try {
            const stored = await putMealImageToR2({ file, profile_id: profile.profile_id });
            offerImgUrl = stored.url;
          } catch {
            return new Response(JSON.stringify({ error: "IMAGE_UPLOAD_FAILED" }), {
              status: 500,
              headers: { "Content-Type": "application/json", ...cors }
            });
          }
        }
        if (!offerImgUrl && typeof linkedMeal?.meal_img_url === "string" && linkedMeal.meal_img_url.trim()) {
          offerImgUrl = linkedMeal.meal_img_url.trim();
        }

        const title =
          (typeof body?.title === "string" && body.title.trim())
            ? body.title.trim()
            : ((typeof linkedMeal?.title === "string" && linkedMeal.title.trim()) ? linkedMeal.title.trim() : "");
        const description =
          (typeof body?.description === "string" && body.description.trim())
            ? body.description.trim()
            : ((typeof linkedMeal?.description === "string" && linkedMeal.description.trim()) ? linkedMeal.description.trim() : null);
        const originalPriceRaw =
          typeof body?.original_price === "number"
            ? body.original_price
            : (typeof body?.original_price === "string" && body.original_price !== "" ? Number(body.original_price) : linkedMeal?.price);
        const offerPriceRaw =
          typeof body?.offer_price === "number"
            ? body.offer_price
            : (typeof body?.offer_price === "string" && body.offer_price !== "" ? Number(body.offer_price) : NaN);
        const quantityRaw = null;
        const originalPrice = Number.isFinite(originalPriceRaw) ? Math.trunc(originalPriceRaw) : NaN;
        const offerPrice = Number.isFinite(offerPriceRaw) ? Math.trunc(offerPriceRaw) : NaN;
        const quantity = null;
        const startsAt = body?.starts_at === null ? null : (typeof body?.starts_at === "string" && body.starts_at.trim() ? body.starts_at.trim() : null);
        const expiresAt = body?.expires_at === null ? null : (typeof body?.expires_at === "string" && body.expires_at.trim() ? body.expires_at.trim() : null);
        const category = body?.category === undefined
          ? (typeof linkedMeal?.category === "string" ? linkedMeal.category : null)
          : normalizeTaxonomyValue(body?.category);
        const cuisine = body?.cuisine === undefined
          ? (typeof linkedMeal?.cuisine === "string" ? linkedMeal.cuisine : null)
          : normalizeTaxonomyValue(body?.cuisine);
        const tags = body?.tags === undefined
          ? normalizeMealTags(linkedMeal?.tags)
          : normalizeMealTags(body?.tags);

        if (!title) {
          return new Response(JSON.stringify({ error: "title is required" }), {
            status: 400,
            headers: { "Content-Type": "application/json", ...cors }
          });
        }
        if (!offerImgUrl) {
          return new Response(JSON.stringify({ error: "offer image is required or provide meal_id with image" }), {
            status: 400,
            headers: { "Content-Type": "application/json", ...cors }
          });
        }
        if (!Number.isFinite(originalPrice) || originalPrice < 0) {
          return new Response(JSON.stringify({ error: "original_price must be a number >= 0" }), {
            status: 400,
            headers: { "Content-Type": "application/json", ...cors }
          });
        }
        if (!Number.isFinite(offerPrice) || offerPrice < 0) {
          return new Response(JSON.stringify({ error: "offer_price must be a number >= 0" }), {
            status: 400,
            headers: { "Content-Type": "application/json", ...cors }
          });
        }
        if (offerPrice > originalPrice) {
          return new Response(JSON.stringify({ error: "offer_price must be <= original_price" }), {
            status: 400,
            headers: { "Content-Type": "application/json", ...cors }
          });
        }
        if (startsAt && expiresAt && startsAt >= expiresAt) {
          return new Response(JSON.stringify({ error: "starts_at must be before expires_at" }), {
            status: 400,
            headers: { "Content-Type": "application/json", ...cors }
          });
        }

        const payload = {
          restaurant_id: lookup.restaurant.id,
          meal_id: mealId,
          title,
          description,
          offer_img_url: offerImgUrl,
          original_price: originalPrice,
          offer_price: offerPrice,
          quantity,
          is_active: body?.is_active === false ? false : true,
          category: category || null,
          cuisine: cuisine || null,
          tags,
          starts_at: startsAt,
          expires_at: expiresAt
        };
        const insertRes = await fetch(`${SUPABASE_URL}/rest/v1/offers`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            ...supabaseHeaders,
            "Prefer": "return=representation"
          },
          body: JSON.stringify(payload)
        });
        const insertText = await insertRes.text().catch(() => "");
        return new Response(insertText || "[]", {
          status: insertRes.status,
          headers: { "Content-Type": "application/json", ...cors }
        });
      }

      if (method === "POST" && path === "/restaurant/offers/update") {
        const cors = corsHeaders(request);
        let body = {};
        try {
          body = await request.json();
        } catch {
          body = {};
        }
        const offerId = typeof body?.offer_id === "string" ? body.offer_id.trim() : "";
        if (!offerId) {
          return new Response(JSON.stringify({ error: "offer_id is required" }), {
            status: 400,
            headers: { "Content-Type": "application/json", ...cors }
          });
        }
        const lookup = await fetchRestaurantByProfile(profile.profile_id, "id,is_active");
        if (!lookup.res.ok) {
          return new Response(lookup.text || "Restaurant lookup failed", {
            status: lookup.res.status,
            headers: { "Content-Type": "application/json", ...cors }
          });
        }
        if (!lookup.restaurant || !lookup.restaurant.id) {
          return new Response(JSON.stringify({ error: "RESTAURANT_NOT_FOUND" }), {
            status: 400,
            headers: { "Content-Type": "application/json", ...cors }
          });
        }

        const existingRes = await fetch(
          `${SUPABASE_URL}/rest/v1/offers?id=eq.${offerId}&restaurant_id=eq.${lookup.restaurant.id}&select=id,meal_id,title,description,offer_img_url,original_price,offer_price,quantity,is_active,category,cuisine,tags,starts_at,expires_at&limit=1`,
          { headers: supabaseHeaders }
        );
        const existingText = await existingRes.text().catch(() => "[]");
        if (!existingRes.ok) {
          return new Response(existingText || JSON.stringify({ error: "OFFER_LOOKUP_FAILED" }), {
            status: existingRes.status,
            headers: { "Content-Type": "application/json", ...cors }
          });
        }
        let existingRows = [];
        try { existingRows = JSON.parse(existingText || "[]"); } catch { existingRows = []; }
        const existing = Array.isArray(existingRows) ? (existingRows[0] ?? null) : null;
        if (!existing || !existing.id) {
          return new Response(JSON.stringify({ error: "OFFER_NOT_FOUND" }), {
            status: 404,
            headers: { "Content-Type": "application/json", ...cors }
          });
        }

        let nextMealId = existing.meal_id;
        let linkedMeal = null;
        if (body?.meal_id !== undefined) {
          if (body?.meal_id === null || body?.meal_id === "") {
            nextMealId = null;
          } else if (typeof body.meal_id === "string" && body.meal_id.trim()) {
            nextMealId = body.meal_id.trim();
            linkedMeal = await fetchMealForRestaurant(lookup.restaurant.id, nextMealId);
            if (!linkedMeal || !linkedMeal.id) {
              return new Response(JSON.stringify({ error: "MEAL_NOT_FOUND_FOR_RESTAURANT" }), {
                status: 400,
                headers: { "Content-Type": "application/json", ...cors }
              });
            }
          }
        }

        let offerImgUrl = undefined;
        if (typeof body?.offer_img_url === "string") {
          offerImgUrl = body.offer_img_url.trim() || null;
        } else if (typeof body?.offer_img_base64 === "string" && body.offer_img_base64.trim()) {
          const match = body.offer_img_base64.match(/^data:(.+?);base64,(.+)$/);
          if (!match) {
            return new Response(JSON.stringify({ error: "INVALID_BASE64_IMAGE" }), {
              status: 400,
              headers: { "Content-Type": "application/json", ...cors }
            });
          }
          const mime = match[1];
          const b64 = match[2];
          const bin = Uint8Array.from(atob(b64), (c) => c.charCodeAt(0));
          const file = new File([bin], `offer.${mime === "image/jpeg" ? "jpg" : mime === "image/png" ? "png" : mime === "image/webp" ? "webp" : "bin"}`, { type: mime });
          try {
            const stored = await putMealImageToR2({ file, profile_id: profile.profile_id });
            offerImgUrl = stored.url;
          } catch {
            return new Response(JSON.stringify({ error: "IMAGE_UPLOAD_FAILED" }), {
              status: 500,
              headers: { "Content-Type": "application/json", ...cors }
            });
          }
        }

        const patchPayload = {};
        if (body?.meal_id !== undefined) patchPayload.meal_id = nextMealId;
        if (typeof body?.title === "string") patchPayload.title = body.title.trim() || existing.title;
        if (typeof body?.description === "string" || body?.description === null) patchPayload.description = body?.description === null ? null : (body.description.trim() || null);
        if (offerImgUrl !== undefined) patchPayload.offer_img_url = offerImgUrl;
        if (body?.original_price !== undefined) {
          const value = typeof body.original_price === "number" ? body.original_price : Number(body.original_price);
          if (!Number.isFinite(value) || value < 0) {
            return new Response(JSON.stringify({ error: "original_price must be a number >= 0" }), {
              status: 400,
              headers: { "Content-Type": "application/json", ...cors }
            });
          }
          patchPayload.original_price = Math.trunc(value);
        }
        if (body?.offer_price !== undefined) {
          const value = typeof body.offer_price === "number" ? body.offer_price : Number(body.offer_price);
          if (!Number.isFinite(value) || value < 0) {
            return new Response(JSON.stringify({ error: "offer_price must be a number >= 0" }), {
              status: 400,
              headers: { "Content-Type": "application/json", ...cors }
            });
          }
          patchPayload.offer_price = Math.trunc(value);
        }
        if (body?.quantity !== undefined) patchPayload.quantity = null;
        if (typeof body?.is_active === "boolean") patchPayload.is_active = body.is_active;
        if (body?.starts_at !== undefined) patchPayload.starts_at = body.starts_at === null ? null : (typeof body.starts_at === "string" && body.starts_at.trim() ? body.starts_at.trim() : null);
        if (body?.expires_at !== undefined) patchPayload.expires_at = body.expires_at === null ? null : (typeof body.expires_at === "string" && body.expires_at.trim() ? body.expires_at.trim() : null);
        if (body?.category !== undefined) patchPayload.category = normalizeTaxonomyValue(body.category);
        if (body?.cuisine !== undefined) patchPayload.cuisine = normalizeTaxonomyValue(body.cuisine);
        if (body?.tags !== undefined) patchPayload.tags = normalizeMealTags(body.tags);

        const nextOriginalPrice = patchPayload.original_price ?? Number(existing.original_price);
        const nextOfferPrice = patchPayload.offer_price ?? Number(existing.offer_price);
        if (Number.isFinite(nextOriginalPrice) && Number.isFinite(nextOfferPrice) && nextOfferPrice > nextOriginalPrice) {
          return new Response(JSON.stringify({ error: "offer_price must be <= original_price" }), {
            status: 400,
            headers: { "Content-Type": "application/json", ...cors }
          });
        }
        const nextStartsAt = patchPayload.starts_at !== undefined ? patchPayload.starts_at : existing.starts_at;
        const nextExpiresAt = patchPayload.expires_at !== undefined ? patchPayload.expires_at : existing.expires_at;
        if (nextStartsAt && nextExpiresAt && nextStartsAt >= nextExpiresAt) {
          return new Response(JSON.stringify({ error: "starts_at must be before expires_at" }), {
            status: 400,
            headers: { "Content-Type": "application/json", ...cors }
          });
        }
        if (Object.keys(patchPayload).length === 0) {
          return new Response(JSON.stringify({ error: "NO_FIELDS_TO_UPDATE" }), {
            status: 400,
            headers: { "Content-Type": "application/json", ...cors }
          });
        }

        const patchRes = await fetch(`${SUPABASE_URL}/rest/v1/offers?id=eq.${offerId}&restaurant_id=eq.${lookup.restaurant.id}`, {
          method: "PATCH",
          headers: {
            "Content-Type": "application/json",
            ...supabaseHeaders,
            "Prefer": "return=representation"
          },
          body: JSON.stringify(patchPayload)
        });
        const patchText = await patchRes.text().catch(() => "");
        return new Response(patchText || "[]", {
          status: patchRes.status,
          headers: { "Content-Type": "application/json", ...cors }
        });
      }

      if (method === "POST" && path === "/restaurant/offers/toggle") {
        const cors = corsHeaders(request);
        let body = {};
        try {
          body = await request.json();
        } catch {
          body = {};
        }
        const offerId = typeof body?.offer_id === "string" ? body.offer_id.trim() : "";
        if (!offerId || typeof body?.is_active !== "boolean") {
          return new Response(JSON.stringify({ error: "offer_id and is_active are required" }), {
            status: 400,
            headers: { "Content-Type": "application/json", ...cors }
          });
        }
        const lookup = await fetchRestaurantByProfile(profile.profile_id, "id");
        if (!lookup.res.ok) {
          return new Response(lookup.text || "Restaurant lookup failed", {
            status: lookup.res.status,
            headers: { "Content-Type": "application/json", ...cors }
          });
        }
        const patchRes = await fetch(`${SUPABASE_URL}/rest/v1/offers?id=eq.${offerId}&restaurant_id=eq.${lookup.restaurant?.id}`, {
          method: "PATCH",
          headers: {
            "Content-Type": "application/json",
            ...supabaseHeaders,
            "Prefer": "return=representation"
          },
          body: JSON.stringify({ is_active: body.is_active })
        });
        const patchText = await patchRes.text().catch(() => "");
        return new Response(patchText || "[]", {
          status: patchRes.status,
          headers: { "Content-Type": "application/json", ...cors }
        });
      }

      if (method === "POST" && path === "/restaurant/offers/delete") {
        const cors = corsHeaders(request);
        let body = {};
        try {
          body = await request.json();
        } catch {
          body = {};
        }
        const offerId = typeof body?.offer_id === "string" ? body.offer_id.trim() : "";
        if (!offerId) {
          return new Response(JSON.stringify({ error: "offer_id is required" }), {
            status: 400,
            headers: { "Content-Type": "application/json", ...cors }
          });
        }
        const lookup = await fetchRestaurantByProfile(profile.profile_id, "id");
        if (!lookup.res.ok) {
          return new Response(lookup.text || "Restaurant lookup failed", {
            status: lookup.res.status,
            headers: { "Content-Type": "application/json", ...cors }
          });
        }
        const delRes = await fetch(`${SUPABASE_URL}/rest/v1/offers?id=eq.${offerId}&restaurant_id=eq.${lookup.restaurant?.id}`, {
          method: "DELETE",
          headers: supabaseHeaders
        });
        const delText = await delRes.text().catch(() => "");
        const statusOut = delRes.status === 204 ? 200 : delRes.status;
        return new Response(delText || "{}", {
          status: statusOut,
          headers: { "Content-Type": "application/json", ...cors }
        });
      }

      // restaurant orders history
      if (method === "GET" && path === "/restaurant/history/orders") {
        const hasParams =
          url.searchParams.has("limit") ||
          url.searchParams.has("offset") ||
          url.searchParams.has("cursor") ||
          url.searchParams.has("time") ||
          url.searchParams.has("from") ||
          url.searchParams.has("to") ||
          url.searchParams.has("status") ||
          url.searchParams.has("tz_offset_minutes");
        if (!hasParams) {
          return callRPC("restaurant_orders_history", { p_profile_id: profile.profile_id }, request);
        }

        const cors = corsHeaders(request);
        const limitRaw = url.searchParams.get("limit");
        const offsetRaw = url.searchParams.get("offset");
        const cursorRaw = url.searchParams.get("cursor");
        const time = (url.searchParams.get("time") || "all").toLowerCase();
        const fromRaw = url.searchParams.get("from");
        const toRaw = url.searchParams.get("to");
        const statusRaw = url.searchParams.get("status");
        const tzOffsetRaw = url.searchParams.get("tz_offset_minutes");

        const limitParsed = limitRaw && limitRaw.trim() !== "" ? Number(limitRaw) : 20;
        const offsetParsed = offsetRaw && offsetRaw.trim() !== "" ? Number(offsetRaw) : 0;
        const limit = Number.isFinite(limitParsed) ? Math.max(1, Math.min(50, Math.trunc(limitParsed))) : 20;
        const offset = Number.isFinite(offsetParsed) ? Math.max(0, Math.trunc(offsetParsed)) : 0;

        const tzOffsetMinutesParsed = tzOffsetRaw && tzOffsetRaw.trim() !== "" ? Number(tzOffsetRaw) : null;
        const tzOffsetMinutes = Number.isFinite(tzOffsetMinutesParsed) ? Math.max(-840, Math.min(840, Math.trunc(tzOffsetMinutesParsed))) : null;

        const parseIso = (v) => {
          if (!v || typeof v !== "string" || !v.trim()) return null;
          const d = new Date(v);
          return Number.isFinite(d.getTime()) ? d.toISOString() : null;
        };

        const now = new Date();
        const computeStartOfDayIso = () => {
          if (tzOffsetMinutes == null) {
            const d = new Date(now);
            d.setUTCHours(0, 0, 0, 0);
            return d.toISOString();
          }
          const localMs = now.getTime() - tzOffsetMinutes * 60_000;
          const local = new Date(localMs);
          local.setUTCHours(0, 0, 0, 0);
          const utcMs = local.getTime() + tzOffsetMinutes * 60_000;
          return new Date(utcMs).toISOString();
        };

        const computeStartOfWeekIso = () => {
          if (tzOffsetMinutes == null) {
            const d = new Date(now);
            const day = d.getUTCDay();
            const diffToMonday = (day + 6) % 7;
            d.setUTCDate(d.getUTCDate() - diffToMonday);
            d.setUTCHours(0, 0, 0, 0);
            return d.toISOString();
          }
          const localMs = now.getTime() - tzOffsetMinutes * 60_000;
          const local = new Date(localMs);
          const day = local.getUTCDay();
          const diffToMonday = (day + 6) % 7;
          local.setUTCDate(local.getUTCDate() - diffToMonday);
          local.setUTCHours(0, 0, 0, 0);
          const utcMs = local.getTime() + tzOffsetMinutes * 60_000;
          return new Date(utcMs).toISOString();
        };

        const fromIso =
          time === "today"
            ? computeStartOfDayIso()
            : (time === "week" || time === "thisweek" || time === "this_week")
              ? computeStartOfWeekIso()
              : parseIso(fromRaw);
        const toIso = parseIso(toRaw);

        const statusList = typeof statusRaw === "string"
          ? statusRaw.split(",").map((s) => s.trim()).filter(Boolean)
          : [];

        const restaurantRes = await fetch(`${SUPABASE_URL}/rest/v1/restaurants?profile_id=eq.${profile.profile_id}&select=id,is_active`, {
          headers: {
            "apikey": SUPABASE_KEY,
            "Authorization": `Bearer ${SUPABASE_KEY}`
          }
        });

        if (!restaurantRes.ok) {
          const t = await restaurantRes.text();
          return new Response(t || "Restaurant lookup failed", {
            status: restaurantRes.status,
            headers: { "Content-Type": "application/json", ...cors }
          });
        }

        const restaurantRows = await restaurantRes.json();
        const restaurant = Array.isArray(restaurantRows) ? restaurantRows[0] : null;
        if (!restaurant || !restaurant.id) {
          return new Response("Restaurant record not found", { status: 400, headers: cors });
        }

        const params = new URLSearchParams();
        params.set("select", "id,created_at,status,address,area,customer_name,customer_phone,order_items(meal_id,offer_id,item_type,quantity,meal_title,unit_price,meal_img_url,category)");
        params.set("restaurant_id", `eq.${restaurant.id}`);
        params.set("order", "created_at.desc,id.desc");
        params.set("limit", String(limit));

        if (fromIso) params.set("created_at", `gte.${fromIso}`);
        if (toIso) params.set("created_at", `${params.get("created_at") ? params.get("created_at") + "," : ""}lte.${toIso}`);

        if (statusList.length === 1) {
          params.set("status", `eq.${statusList[0]}`);
        } else if (statusList.length > 1) {
          params.set("status", `in.(${statusList.join(",")})`);
        }

        if (cursorRaw && cursorRaw.trim() !== "") {
          let decoded = null;
          try {
            decoded = decodeURIComponent(cursorRaw);
          } catch {
            decoded = cursorRaw;
          }
          const parts = typeof decoded === "string" ? decoded.split("|") : [];
          const cursorCreatedAt = parts.length >= 1 && parts[0] ? parts[0] : null;
          const cursorId = parts.length >= 2 && parts[1] ? parts[1] : null;
          if (cursorCreatedAt && cursorId) {
            params.set("and", `(or(created_at.lt.${cursorCreatedAt},and(created_at.eq.${cursorCreatedAt},id.lt.${cursorId})))`);
          } else if (cursorCreatedAt) {
            params.set("created_at", `${params.get("created_at") ? params.get("created_at") + "," : ""}lt.${cursorCreatedAt}`);
          }
        } else {
          params.set("offset", String(offset));
        }

        const ordersRes = await fetch(`${SUPABASE_URL}/rest/v1/orders?${params.toString()}`, {
          headers: {
            "apikey": SUPABASE_KEY,
            "Authorization": `Bearer ${SUPABASE_KEY}`
          }
        });

        const rawText = await ordersRes.text();
        if (!ordersRes.ok) {
          return new Response(rawText, {
            status: ordersRes.status,
            headers: { "Content-Type": "application/json", ...cors }
          });
        }

        let rows = [];
        try {
          rows = JSON.parse(rawText);
        } catch {
          rows = [];
        }

        const mapped = Array.isArray(rows) ? rows.map((r) => {
          const rawItems = Array.isArray(r?.order_items) ? r.order_items : [];
          const items = rawItems.map((it) => ({
            meal_id: it?.meal_id ?? null,
            offer_id: it?.offer_id ?? null,
            item_type: it?.item_type ?? "meal",
            quantity: typeof it?.quantity === "number" ? it.quantity : (typeof it?.quantity === "string" && it.quantity !== "" ? Number(it.quantity) : 1),
            title: typeof it?.meal_title === "string" ? it.meal_title : null,
            price: typeof it?.unit_price === "number" ? it.unit_price : (typeof it?.unit_price === "string" && it.unit_price !== "" ? Number(it.unit_price) : null),
            meal_img_url: typeof it?.meal_img_url === "string" ? it.meal_img_url : null,
            category: typeof it?.category === "string" ? it.category : null
          }));
          return {
            id: r?.id ?? null,
            created_at: r?.created_at ?? null,
            status: r?.status ?? null,
            address: r?.address ?? null,
            area: r?.area ?? null,
            customer_name: r?.customer_name ?? null,
            customer_phone: r?.customer_phone ?? null,
            items
          };
        }) : [];

        let nextCursor = "";
        if (mapped.length > 0) {
          const last = mapped[mapped.length - 1];
          const lastCreatedAt = last && typeof last.created_at === "string" ? last.created_at : null;
          const lastId = last && typeof last.id === "string" ? last.id : null;
          if (lastCreatedAt && lastId) {
            nextCursor = `${lastCreatedAt}|${lastId}`;
          }
        }

        const headers = {
          "Content-Type": "application/json",
          ...cors,
          "X-Next-Offset": String(offset + limit),
          "X-Next-Cursor": nextCursor
        };

        return new Response(JSON.stringify(mapped), { status: 200, headers });
      }

      // update order status (restaurant-only)
      if (method === "POST" && path === "/restaurant/orders/update-status") {
        const cors = corsHeaders(request);
        const body = await request.json();
        const order_id = body?.order_id;
        const status = body?.status;
        if (!order_id || !status) {
          return new Response(JSON.stringify({ error: "MISSING_REQUIRED_FIELDS" }), {
            status: 400,
            headers: { "Content-Type": "application/json", ...cors }
          });
        }
        const tryV2 = await fetch(`${SUPABASE_URL}/rest/v1/rpc/restaurant_update_order_status_v2`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "apikey": SUPABASE_KEY,
            "Authorization": `Bearer ${SUPABASE_KEY}`
          },
          body: JSON.stringify({
            p_profile_id: profile.profile_id,
            p_order_id: order_id,
            p_status: status
          })
        });

        const t = await tryV2.text().catch(() => "");
        return new Response(t, { status: tryV2.status, headers: { "Content-Type": "application/json", ...cors } });
      }

      // get meals
      if (method === "GET" && path === "/restaurant/meals") {
        const cors = corsHeaders(request);
        const includeHidden = (url.searchParams.get("include_hidden") || "").toLowerCase() === "true";
        const restaurantRes = await fetch(`${SUPABASE_URL}/rest/v1/restaurants?profile_id=eq.${profile.profile_id}&select=id,is_active`, {
          headers: {
            "apikey": SUPABASE_KEY,
            "Authorization": `Bearer ${SUPABASE_KEY}`
          }
        });

        if (!restaurantRes.ok) {
          const t = await restaurantRes.text();
          return new Response(t || "Restaurant lookup failed", {
            status: restaurantRes.status,
            headers: { "Content-Type": "application/json", ...cors }
          });
        }

        const restaurantRows = await restaurantRes.json();
        const restaurant = Array.isArray(restaurantRows) ? restaurantRows[0] : null;
        if (!restaurant || !restaurant.id) {
          return new Response("Restaurant record not found", { status: 400, headers: cors });
        }
        if (restaurant.is_active === false) {
          return new Response("Restaurant is inactive", { status: 403, headers: cors });
        }

        const nowIso = new Date().toISOString();
        const params = new URLSearchParams();
        params.set("restaurant_id", `eq.${restaurant.id}`);
        params.set("select", "*");
        params.set("order", "created_at.desc");
        if (!includeHidden) {
          params.set("is_available", "eq.true");
          params.set("or", `(expiry_time.is.null,expiry_time.gt.${nowIso})`);
        }

        const mealsRes = await fetch(`${SUPABASE_URL}/rest/v1/meals?${params.toString()}`, {
          headers: {
            "apikey": SUPABASE_KEY,
            "Authorization": `Bearer ${SUPABASE_KEY}`
          }
        });

        const mealsText = await mealsRes.text();
        let responseText = mealsText;
        if (mealsRes.ok) {
          try {
            const rows = JSON.parse(mealsText || "[]");
            const withOffers = await attachMealOffers(Array.isArray(rows) ? rows : [], { hideMealsWithActiveOffer: false });
            responseText = JSON.stringify(withOffers);
          } catch {
          }
        }
        return new Response(responseText, {
          status: mealsRes.status,
          headers: { "Content-Type": "application/json", ...cors }
        });
      }

      // add meal
      if (method === "POST" && path === "/restaurant/add-meal") {
        const contentType = request.headers.get("Content-Type") || "";
        let title = "";
        let description = "";
        let quantity = null;
        let price = null;
        let expiry_time = null;
        let meal_img_url = "";
        let category = null;
        let cuisine = null;
        let tags = [];

        if (contentType.includes("multipart/form-data")) {
          const form = await request.formData();
          const fileKeys = ["image", "meal_image", "file"];
          const files = fileKeys.flatMap((k) => form.getAll(k)).filter((v) => v && typeof v === "object" && "arrayBuffer" in v);
          if (files.length > 1) {
            return new Response("Only one meal image is allowed", { status: 400 });
          }
          const image = files[0] || null;
          const t = form.get("title");
          const d = form.get("description");
          const q = form.get("quantity");
          const p = form.get("price");
          const e = form.get("expiry_time") || form.get("expiry");
          const c = form.get("category");
          const cu = form.get("cuisine");
          const tg = form.get("tags");

          title = typeof t === "string" ? t : "";
          description = typeof d === "string" ? d : "";
          quantity = typeof q === "string" && q !== "" ? Number(q) : null;
          price = typeof p === "string" && p !== "" ? Number(p) : null;
          expiry_time = typeof e === "string" ? e : null;
          category = normalizeTaxonomyValue(c);
          cuisine = normalizeTaxonomyValue(cu);
          tags = normalizeMealTags(tg);

          if (!(image && typeof image === "object" && "arrayBuffer" in image)) {
            return new Response("Meal image file is mandatory", { status: 400 });
          }
          try {
            const stored = await putMealImageToR2({ file: image, profile_id: profile.profile_id });
            meal_img_url = stored.url;
          } catch (err) {
            return new Response(`Image upload failed`, { status: 500 });
          }
        } else {
          const body = await request.json();
          title = body.title;
          description = body.description;
          quantity = body.quantity;
          price = body.price;
          expiry_time = body.expiry_time;
          category = normalizeTaxonomyValue(body.category);
          cuisine = normalizeTaxonomyValue(body.cuisine);
          tags = normalizeMealTags(body.tags);

          if (body.meal_img_url && body.meal_img_base64) {
            return new Response("Only one meal image is allowed", { status: 400 });
          }

          if (body.meal_img_url && typeof body.meal_img_url === "string") {
            meal_img_url = body.meal_img_url;
          } else if (body.meal_img_base64 && typeof body.meal_img_base64 === "string") {
            const m = body.meal_img_base64.match(/^data:(.+?);base64,(.+)$/);
            if (!m) return new Response("Invalid base64 image", { status: 400 });
            const mime = m[1];
            const b64 = m[2];
            const bin = Uint8Array.from(atob(b64), (c) => c.charCodeAt(0));
            const file = new File([bin], `meal.${mime === "image/jpeg" ? "jpg" : mime === "image/png" ? "png" : mime === "image/webp" ? "webp" : "bin"}`, { type: mime });
            try {
              const stored = await putMealImageToR2({ file, profile_id: profile.profile_id });
              meal_img_url = stored.url;
            } catch {
              return new Response("Image upload failed", { status: 500 });
            }
          }
        }

        if (!meal_img_url || meal_img_url.trim().length === 0) {
          return new Response("Meal image is mandatory", { status: 400 });
        }

        if (!title || typeof title !== "string" || title.trim().length === 0) {
          return new Response("title is required", { status: 400 });
        }
        const priceNum = typeof price === "number" ? price : (typeof price === "string" && price !== "" ? Number(price) : NaN);
        if (!Number.isFinite(priceNum) || priceNum < 0) {
          return new Response("price is required", { status: 400 });
        }
        const quantityNumRaw =
          typeof quantity === "number"
            ? quantity
            : (typeof quantity === "string" && quantity !== "" ? Number(quantity) : null);
        const quantityNum = quantityNumRaw === null ? 1 : quantityNumRaw;
        if (!Number.isFinite(quantityNum) || quantityNum < 0) {
          return new Response("quantity must be a number >= 0", { status: 400 });
        }

        const cors = corsHeaders(request);
        const restaurantRes = await fetch(`${SUPABASE_URL}/rest/v1/restaurants?profile_id=eq.${profile.profile_id}&select=id,is_active`, {
          headers: {
            "apikey": SUPABASE_KEY,
            "Authorization": `Bearer ${SUPABASE_KEY}`
          }
        });

        if (!restaurantRes.ok) {
          const t = await restaurantRes.text();
          return new Response(t || "Restaurant lookup failed", {
            status: restaurantRes.status,
            headers: { "Content-Type": "application/json", ...cors }
          });
        }

        const restaurantRows = await restaurantRes.json();
        const restaurant = Array.isArray(restaurantRows) ? restaurantRows[0] : null;
        if (!restaurant || !restaurant.id) {
          return new Response("Restaurant record not found", { status: 400, headers: cors });
        }
        if (restaurant.is_active === false) {
          return new Response("Restaurant is inactive", { status: 403, headers: cors });
        }

        const insertRes = await fetch(`${SUPABASE_URL}/rest/v1/meals`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "apikey": SUPABASE_KEY,
            "Authorization": `Bearer ${SUPABASE_KEY}`,
            "Prefer": "return=representation"
          },
          body: JSON.stringify({
            restaurant_id: restaurant.id,
            title: title,
            description: description || null,
            expiry_time: expiry_time || null,
            price: Math.trunc(priceNum),
            quantity: Math.trunc(quantityNum),
            meal_img_url: meal_img_url,
            category: category || null,
            cuisine: cuisine || null,
            tags: tags
          })
        });

        const insertText = await insertRes.text();
        return new Response(insertText, {
          status: insertRes.status,
          headers: { "Content-Type": "application/json", ...cors }
        });
      }

      // update meal
      if (method === "POST" && path === "/restaurant/update-meal") {
        const body = await request.json();
        const rpcResp = await callRPC("restaurant_update_meal", {
          p_profile_id: profile.profile_id,
          p_meal_id: body.meal_id,
          p_quantity: body.quantity ?? null,
          p_price: body.price ?? null,
          p_expiry: body.expiry_time ?? null,
          p_meal_img_url: body.meal_img_url ?? null,
          p_title: body.title ?? body.name ?? null,
          p_category: body.category ?? null
        }, request);
        const nextCuisine = normalizeTaxonomyValue(body?.cuisine);
        const nextTags = normalizeMealTags(body?.tags);
        const hasTaxonomyPatch = nextCuisine !== null || Array.isArray(body?.tags) || typeof body?.tags === "string";
        if (!hasTaxonomyPatch || !(rpcResp instanceof Response) || !rpcResp.ok || !body?.meal_id) {
          return rpcResp;
        }

        const cors = corsHeaders(request);
        const patchPayload = {};
        if (nextCuisine !== null) patchPayload.cuisine = nextCuisine;
        if (Array.isArray(body?.tags) || typeof body?.tags === "string") patchPayload.tags = nextTags;
        const patchRes = await fetch(`${SUPABASE_URL}/rest/v1/meals?id=eq.${body.meal_id}`, {
          method: "PATCH",
          headers: {
            "Content-Type": "application/json",
            "apikey": SUPABASE_KEY,
            "Authorization": `Bearer ${SUPABASE_KEY}`,
            "Prefer": "return=representation"
          },
          body: JSON.stringify(patchPayload)
        });
        const patchText = await patchRes.text().catch(() => "");
        if (!patchRes.ok) {
          return new Response(patchText || JSON.stringify({ error: "MEAL_TAXONOMY_PATCH_FAILED" }), {
            status: patchRes.status,
            headers: { "Content-Type": "application/json", ...cors }
          });
        }
        return new Response(patchText || "[]", {
          status: 200,
          headers: { "Content-Type": "application/json", ...cors }
        });
      }

      // delete meal
      if (method === "POST" && path === "/restaurant/delete-meal") {
        const body = await request.json();
        const cors = corsHeaders(request);
        const mealId = body?.meal_id;
        if (!mealId) return new Response("meal_id is required", { status: 400, headers: cors });

        const restaurantRes = await fetch(`${SUPABASE_URL}/rest/v1/restaurants?profile_id=eq.${profile.profile_id}&select=id,is_active`, {
          headers: {
            "apikey": SUPABASE_KEY,
            "Authorization": `Bearer ${SUPABASE_KEY}`
          }
        });

        if (!restaurantRes.ok) {
          const t = await restaurantRes.text();
          return new Response(t || "Restaurant lookup failed", {
            status: restaurantRes.status,
            headers: { "Content-Type": "application/json", ...cors }
          });
        }

        const restaurantRows = await restaurantRes.json();
        const restaurant = Array.isArray(restaurantRows) ? restaurantRows[0] : null;
        if (!restaurant || !restaurant.id) {
          return new Response("Restaurant record not found", { status: 400, headers: cors });
        }
        if (restaurant.is_active === false) {
          return new Response("Restaurant is inactive", { status: 403, headers: cors });
        }

        const mealRes = await fetch(`${SUPABASE_URL}/rest/v1/meals?id=eq.${mealId}&select=id,restaurant_id,meal_img_url`, {
          headers: {
            "apikey": SUPABASE_KEY,
            "Authorization": `Bearer ${SUPABASE_KEY}`
          }
        });

        if (!mealRes.ok) {
          const t = await mealRes.text();
          return new Response(t || "Meal lookup failed", {
            status: mealRes.status,
            headers: { "Content-Type": "application/json", ...cors }
          });
        }

        const mealRows = await mealRes.json();
        const meal = Array.isArray(mealRows) ? mealRows[0] : null;
        if (!meal || !meal.id) {
          return new Response("Meal not found", { status: 404, headers: cors });
        }
        if (meal.restaurant_id !== restaurant.id) {
          return new Response("Not allowed to delete this meal", { status: 403, headers: cors });
        }

        const nowIso = new Date().toISOString();
        const hideRes = await fetch(`${SUPABASE_URL}/rest/v1/meals?id=eq.${mealId}&restaurant_id=eq.${restaurant.id}`, {
          method: "PATCH",
          headers: {
            "Content-Type": "application/json",
            "apikey": SUPABASE_KEY,
            "Authorization": `Bearer ${SUPABASE_KEY}`,
            "Prefer": "return=representation"
          },
          body: JSON.stringify({
            is_available: false,
            quantity: 0,
            expiry_time: nowIso
          })
        });

        const hideText = await hideRes.text();
        if (!hideRes.ok) {
          return new Response(hideText, {
            status: hideRes.status,
            headers: { "Content-Type": "application/json", ...cors }
          });
        }

        let hidden = null;
        try {
          const parsed = JSON.parse(hideText);
          hidden = Array.isArray(parsed) ? (parsed[0] ?? null) : parsed;
        } catch {
          hidden = null;
        }

        return new Response(JSON.stringify({ hidden }), {
          status: 200,
          headers: { "Content-Type": "application/json", ...cors }
        });
      }

      
      // restaurant sold meals history
      if (method === "GET" && path === "/restaurant/history/meals") {
        return callRPC("restaurant_meals_history", { p_profile_id: profile.profile_id }, request);
      }

      // restaurant statistics
      if (method === "GET" && path === "/restaurant/statistics") {
        return callRPC("restaurant_statistics", {
          p_profile_id: profile.profile_id
        }, request);
      }

      // update restaurant description only
      if (method === "POST" && path === "/restaurant/update-description") {
        const body = await request.json();
        if (!body.description) return new Response("Description is required", { status: 400 });
        return callRPC("update_restaurant_description", {
          p_profile_id: profile.profile_id,
          p_description: body.description
        }, request);
      }

      // update restaurant image only
      if (method === "POST" && path === "/restaurant/update-image") {
        const cors = corsHeaders(request);
        let body = null;
        try {
          body = await request.json();
        } catch {
          body = null;
        }
        const imgUrl = body && typeof body.img_url === "string" ? body.img_url.trim() : "";
        if (!imgUrl) {
          return new Response(JSON.stringify({ error: "img_url is required" }), {
            status: 400,
            headers: { "Content-Type": "application/json", ...cors }
          });
        }

        const restaurantRes = await fetch(`${SUPABASE_URL}/rest/v1/restaurants?profile_id=eq.${profile.profile_id}&select=id`, {
          headers: {
            "apikey": SUPABASE_KEY,
            "Authorization": `Bearer ${SUPABASE_KEY}`
          }
        });
        if (!restaurantRes.ok) {
          const t = await restaurantRes.text().catch(() => "");
          return new Response(t || "Restaurant lookup failed", {
            status: restaurantRes.status,
            headers: { "Content-Type": "application/json", ...cors }
          });
        }
        const restaurantRows = await restaurantRes.json();
        const restaurant = Array.isArray(restaurantRows) ? restaurantRows[0] : null;
        if (!restaurant || !restaurant.id) {
          return new Response(JSON.stringify({ error: "RESTAURANT_NOT_FOUND" }), {
            status: 400,
            headers: { "Content-Type": "application/json", ...cors }
          });
        }

        const patchHeaders = {
          "Content-Type": "application/json",
          "apikey": SUPABASE_KEY,
          "Authorization": `Bearer ${SUPABASE_KEY}`,
          "Prefer": "return=representation"
        };

        const tryPatch = async (fieldName) => {
          const resp = await fetch(`${SUPABASE_URL}/rest/v1/restaurants?id=eq.${restaurant.id}`, {
            method: "PATCH",
            headers: patchHeaders,
            body: JSON.stringify({ [fieldName]: imgUrl })
          });
          const text = await resp.text().catch(() => "");
          return { resp, text };
        };

        const first = await tryPatch("img_url");
        if (first.resp.ok) {
          return new Response(first.text || "[]", {
            status: 200,
            headers: { "Content-Type": "application/json", ...cors }
          });
        }

        const errText = (first.text || "").toLowerCase();
        const mightBeMissingColumn =
          errText.includes("column") || errText.includes("img_url") || errText.includes("does not exist");

        if (mightBeMissingColumn) {
          const second = await tryPatch("rest_img_url");
          if (second.resp.ok) {
            return new Response(second.text || "[]", {
              status: 200,
              headers: { "Content-Type": "application/json", ...cors }
            });
          }
          return new Response(second.text || first.text || "Update failed", {
            status: second.resp.status,
            headers: { "Content-Type": "application/json", ...cors }
          });
        }

        return new Response(first.text || "Update failed", {
          status: first.resp.status,
          headers: { "Content-Type": "application/json", ...cors }
        });
      }

      if (method === "POST" && path === "/restaurant/upload-image") {
        const cors = corsHeaders(request);
        const contentType = request.headers.get("Content-Type") || "";

        let imgUrl = "";

        if (contentType.includes("multipart/form-data")) {
          const form = await request.formData();
          const fileKeys = ["image", "restaurant_image", "file"];
          const files = fileKeys.flatMap((k) => form.getAll(k)).filter((v) => v && typeof v === "object" && "arrayBuffer" in v);
          if (files.length > 1) {
            return new Response(JSON.stringify({ error: "Only one restaurant image is allowed" }), {
              status: 400,
              headers: { "Content-Type": "application/json", ...cors }
            });
          }
          const image = files[0] || null;
          if (!(image && typeof image === "object" && "arrayBuffer" in image)) {
            return new Response(JSON.stringify({ error: "Restaurant image file is mandatory" }), {
              status: 400,
              headers: { "Content-Type": "application/json", ...cors }
            });
          }
          try {
            const stored = await putRestaurantImageToR2({ file: image, profile_id: profile.profile_id });
            imgUrl = stored.url;
          } catch {
            return new Response(JSON.stringify({ error: "Image upload failed" }), {
              status: 500,
              headers: { "Content-Type": "application/json", ...cors }
            });
          }
        } else {
          let body = null;
          try { body = await request.json(); } catch { body = null; }
          if (body && typeof body.img_url === "string" && body.img_url.trim() !== "") {
            imgUrl = body.img_url.trim();
          } else if (body && typeof body.img_base64 === "string" && body.img_base64.trim() !== "") {
            const m = body.img_base64.match(/^data:(.+?);base64,(.+)$/);
            if (!m) {
              return new Response(JSON.stringify({ error: "Invalid base64 image" }), {
                status: 400,
                headers: { "Content-Type": "application/json", ...cors }
              });
            }
            const mime = m[1];
            const b64 = m[2];
            const bin = Uint8Array.from(atob(b64), (c) => c.charCodeAt(0));
            const file = new File([bin], `restaurant.${mime === "image/jpeg" ? "jpg" : mime === "image/png" ? "png" : mime === "image/webp" ? "webp" : "bin"}`, { type: mime });
            try {
              const stored = await putRestaurantImageToR2({ file, profile_id: profile.profile_id });
              imgUrl = stored.url;
            } catch {
              return new Response(JSON.stringify({ error: "Image upload failed" }), {
                status: 500,
                headers: { "Content-Type": "application/json", ...cors }
              });
            }
          }
        }

        if (!imgUrl) {
          return new Response(JSON.stringify({ error: "img_url is required" }), {
            status: 400,
            headers: { "Content-Type": "application/json", ...cors }
          });
        }

        const restaurantRes = await fetch(`${SUPABASE_URL}/rest/v1/restaurants?profile_id=eq.${profile.profile_id}&select=id`, {
          headers: {
            "apikey": SUPABASE_KEY,
            "Authorization": `Bearer ${SUPABASE_KEY}`
          }
        });
        if (!restaurantRes.ok) {
          const t = await restaurantRes.text().catch(() => "");
          return new Response(t || "Restaurant lookup failed", {
            status: restaurantRes.status,
            headers: { "Content-Type": "application/json", ...cors }
          });
        }
        const restaurantRows = await restaurantRes.json();
        const restaurant = Array.isArray(restaurantRows) ? restaurantRows[0] : null;
        if (!restaurant || !restaurant.id) {
          return new Response(JSON.stringify({ error: "RESTAURANT_NOT_FOUND" }), {
            status: 400,
            headers: { "Content-Type": "application/json", ...cors }
          });
        }

        const patchHeaders = {
          "Content-Type": "application/json",
          "apikey": SUPABASE_KEY,
          "Authorization": `Bearer ${SUPABASE_KEY}`,
          "Prefer": "return=representation"
        };

        const tryPatch = async (fieldName) => {
          const resp = await fetch(`${SUPABASE_URL}/rest/v1/restaurants?id=eq.${restaurant.id}`, {
            method: "PATCH",
            headers: patchHeaders,
            body: JSON.stringify({ [fieldName]: imgUrl })
          });
          const text = await resp.text().catch(() => "");
          return { resp, text };
        };

        const first = await tryPatch("img_url");
        if (first.resp.ok) {
          return new Response(JSON.stringify({ img_url: imgUrl, restaurant: JSON.parse(first.text)[0] }), {
            status: 200,
            headers: { "Content-Type": "application/json", ...cors }
          });
        }

        const errText = (first.text || "").toLowerCase();
        const mightBeMissingColumn =
          errText.includes("column") || errText.includes("img_url") || errText.includes("does not exist");

        if (mightBeMissingColumn) {
          const second = await tryPatch("rest_img_url");
          if (second.resp.ok) {
            return new Response(JSON.stringify({ img_url: imgUrl, restaurant: JSON.parse(second.text)[0] }), {
              status: 200,
              headers: { "Content-Type": "application/json", ...cors }
            });
          }
          return new Response(second.text || first.text || "Update failed", {
            status: second.resp.status,
            headers: { "Content-Type": "application/json", ...cors }
          });
        }

        return new Response(first.text || "Update failed", {
          status: first.resp.status,
          headers: { "Content-Type": "application/json", ...cors }
        });
      }

// GET MY DONATIONS (with cursor pagination)
      if (method === "GET" && path === "/restaurant/donations") {
        const cors = corsHeaders(request);

        const limitRaw = url.searchParams.get("limit");
        const offsetRaw = url.searchParams.get("offset");
        const cursorRaw = url.searchParams.get("cursor");
        const statusRaw = url.searchParams.get("status");

        const limitParsed = limitRaw && limitRaw.trim() !== "" ? Number(limitRaw) : 20;
        const offsetParsed = offsetRaw && offsetRaw.trim() !== "" ? Number(offsetRaw) : 0;
        const limit = Number.isFinite(limitParsed) ? Math.max(1, Math.min(50, Math.trunc(limitParsed))) : 20;
        const offset = Number.isFinite(offsetParsed) ? Math.max(0, Math.trunc(offsetParsed)) : 0;

        const restaurantRes = await fetch(
          `${SUPABASE_URL}/rest/v1/restaurants?profile_id=eq.${profile.profile_id}&select=id,is_active`,
          { headers: { "apikey": SUPABASE_KEY, "Authorization": `Bearer ${SUPABASE_KEY}` } }
        );
        if (!restaurantRes.ok) {
          const t = await restaurantRes.text();
          return new Response(t || "Restaurant lookup failed", {
            status: restaurantRes.status,
            headers: { "Content-Type": "application/json", ...cors }
          });
        }
        const restaurantRows = await restaurantRes.json();
        const restaurant = Array.isArray(restaurantRows) ? restaurantRows[0] : null;
        if (!restaurant || !restaurant.id) {
          return new Response(JSON.stringify({ error: "RESTAURANT_NOT_FOUND" }), {
            status: 400,
            headers: { "Content-Type": "application/json", ...cors }
          });
        }
        if (restaurant.is_active === false) {
          return new Response(JSON.stringify({ error: "RESTAURANT_INACTIVE" }), {
            status: 403,
            headers: { "Content-Type": "application/json", ...cors }
          });
        }

        const params = new URLSearchParams();
        params.set("select", "id,donation_img_url,picked_up,is_available,created_at,description,pickup_location");
        params.set("restaurant_id", `eq.${restaurant.id}`);
        params.set("order", "created_at.desc,id.desc");
        params.set("limit", String(limit));

        const allowedStatuses = new Set(["pending", "approved", "rejected"]);
        if (statusRaw && statusRaw.trim() !== "" && allowedStatuses.has(statusRaw.trim())) {
          params.set("picked_up", `eq.${statusRaw.trim()}`);
        }

        if (cursorRaw && cursorRaw.trim() !== "") {
          let decoded = null;
          try { decoded = decodeURIComponent(cursorRaw); } catch { decoded = cursorRaw; }
          const parts = typeof decoded === "string" ? decoded.split("|") : [];
          const cursorCreatedAt = parts.length >= 1 && parts[0] ? parts[0] : null;
          const cursorId = parts.length >= 2 && parts[1] ? parts[1] : null;
          if (cursorCreatedAt && cursorId) {
            params.set("and", `(or(created_at.lt.${cursorCreatedAt},and(created_at.eq.${cursorCreatedAt},id.lt.${cursorId})))`);
          } else if (cursorCreatedAt) {
            params.set("created_at", `lt.${cursorCreatedAt}`);
          }
        } else {
          params.set("offset", String(offset));
        }

        const donationsRes = await fetch(`${SUPABASE_URL}/rest/v1/donations?${params.toString()}`, {
          headers: { "apikey": SUPABASE_KEY, "Authorization": `Bearer ${SUPABASE_KEY}` }
        });
        const text = await donationsRes.text();

        let nextCursor = "";
        if (donationsRes.ok) {
          try {
            const rows = JSON.parse(text);
            if (Array.isArray(rows) && rows.length > 0) {
              const last = rows[rows.length - 1];
              const lastCreatedAt = last && typeof last.created_at === "string" ? last.created_at : null;
              const lastId = last && typeof last.id === "string" ? last.id : null;
              if (lastCreatedAt && lastId) nextCursor = `${lastCreatedAt}|${lastId}`;
            }
          } catch { nextCursor = ""; }
        }

        return new Response(text, {
          status: donationsRes.status,
          headers: {
            "Content-Type": "application/json",
            ...cors,
            "X-Next-Offset": String(offset + limit),
            "X-Next-Cursor": nextCursor
          }
        });
      }


// ADD DONATION (with optional items)
      if (method === "POST" && path === "/restaurant/add-donation") {
        const cors = corsHeaders(request);
        const contentType = request.headers.get("Content-Type") || "";

        let donationImgUrl = "";
        let description    = "";
        let pickupLocation = "";
        let rawItems       = [];

        // ── Restaurant lookup + active check (before any upload work) ──
        const restaurantRes = await fetch(
          `${SUPABASE_URL}/rest/v1/restaurants?profile_id=eq.${profile.profile_id}&select=id,is_active`,
          { headers: { "apikey": SUPABASE_KEY, "Authorization": `Bearer ${SUPABASE_KEY}` } }
        );
        if (!restaurantRes.ok) {
          const t = await restaurantRes.text();
          return new Response(t || "Restaurant lookup failed", {
            status: restaurantRes.status,
            headers: { "Content-Type": "application/json", ...cors }
          });
        }
        const restaurantRows = await restaurantRes.json();
        const restaurant = Array.isArray(restaurantRows) ? restaurantRows[0] : null;
        if (!restaurant || !restaurant.id) {
          return new Response(JSON.stringify({ error: "RESTAURANT_NOT_FOUND" }), {
            status: 400,
            headers: { "Content-Type": "application/json", ...cors }
          });
        }
        if (restaurant.is_active === false) {
          return new Response(JSON.stringify({ error: "RESTAURANT_INACTIVE" }), {
            status: 403,
            headers: { "Content-Type": "application/json", ...cors }
          });
        }

        // ── multipart/form-data ──
        if (contentType.includes("multipart/form-data")) {
          const form = await request.formData();

          const fileKeys = ["image", "donation_image", "file"];
          const files = fileKeys.flatMap((k) => form.getAll(k)).filter((v) => v && typeof v === "object" && "arrayBuffer" in v);
          if (files.length > 1) {
            return new Response(JSON.stringify({ error: "Only one donation image is allowed" }), {
              status: 400,
              headers: { "Content-Type": "application/json", ...cors }
            });
          }

          const image = files[0] || null;
          const d = form.get("description");
          const p = form.get("pickup_location");
          const i = form.get("items");
          description    = typeof d === "string" ? d.trim() : "";
          pickupLocation = typeof p === "string" ? p.trim() : "";

          if (typeof i === "string" && i.trim()) {
            try { rawItems = JSON.parse(i); } catch { rawItems = []; }
          }

          if (!(image && typeof image === "object" && "arrayBuffer" in image)) {
            return new Response(JSON.stringify({ error: "Donation image file is mandatory" }), {
              status: 400,
              headers: { "Content-Type": "application/json", ...cors }
            });
          }

          try {
            const stored = await putMealImageToR2({ file: image, profile_id: profile.profile_id });
            donationImgUrl = stored.url;
          } catch {
            return new Response(JSON.stringify({ error: "Image upload failed" }), {
              status: 500,
              headers: { "Content-Type": "application/json", ...cors }
            });
          }

        // ── JSON body ──
        } else {
          let body = null;
          try { body = await request.json(); } catch { body = null; }

          description    = body && typeof body.description     === "string" ? body.description.trim()     : "";
          pickupLocation = body && typeof body.pickup_location  === "string" ? body.pickup_location.trim()  : "";
          rawItems       = body && Array.isArray(body.items)                 ? body.items                   : [];

          if (body && body.donation_img_url && body.donation_img_base64) {
            return new Response(JSON.stringify({ error: "Only one donation image is allowed" }), {
              status: 400,
              headers: { "Content-Type": "application/json", ...cors }
            });
          }

          if (body && typeof body.donation_img_url === "string" && body.donation_img_url.trim()) {
            donationImgUrl = body.donation_img_url.trim();

          } else if (body && typeof body.donation_img_base64 === "string" && body.donation_img_base64.trim()) {
            const m = body.donation_img_base64.match(/^data:(.+?);base64,(.+)$/);
            if (!m) {
              return new Response(JSON.stringify({ error: "Invalid base64 image" }), {
                status: 400,
                headers: { "Content-Type": "application/json", ...cors }
              });
            }
            const mime = m[1];
            const b64  = m[2];
            const bin  = Uint8Array.from(atob(b64), (c) => c.charCodeAt(0));
            const file = new File(
              [bin],
              `donation.${mime === "image/jpeg" ? "jpg" : mime === "image/png" ? "png" : mime === "image/webp" ? "webp" : "bin"}`,
              { type: mime }
            );
            try {
              const stored = await putMealImageToR2({ file, profile_id: profile.profile_id });
              donationImgUrl = stored.url;
            } catch {
              return new Response(JSON.stringify({ error: "Image upload failed" }), {
                status: 500,
                headers: { "Content-Type": "application/json", ...cors }
              });
            }
          }
        }

        // ── Validate donation image ──
        if (!donationImgUrl || donationImgUrl.trim().length === 0) {
          return new Response(JSON.stringify({ error: "Donation image is mandatory" }), {
            status: 400,
            headers: { "Content-Type": "application/json", ...cors }
          });
        }

        // ── Validate items array if provided ──
        const items = Array.isArray(rawItems) ? rawItems : [];
        for (let idx = 0; idx < items.length; idx++) {
          const it = items[idx];
          if (!it || typeof it.item_name !== "string" || !it.item_name.trim()) {
            return new Response(JSON.stringify({ error: `items[${idx}]: item_name is required` }), {
              status: 400,
              headers: { "Content-Type": "application/json", ...cors }
            });
          }
          const qty = Number(it.quantity);
          if (!Number.isFinite(qty) || qty <= 0) {
            return new Response(JSON.stringify({ error: `items[${idx}]: quantity must be a number greater than 0` }), {
              status: 400,
              headers: { "Content-Type": "application/json", ...cors }
            });
          }
          if (!it.donation_item_img || typeof it.donation_item_img !== "string" || !it.donation_item_img.trim()) {
            return new Response(JSON.stringify({ error: `items[${idx}]: donation_item_img is required` }), {
              status: 400,
              headers: { "Content-Type": "application/json", ...cors }
            });
          }
        }

        // ── Insert donation ──
        const insertRes = await fetch(`${SUPABASE_URL}/rest/v1/donations`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "apikey": SUPABASE_KEY,
            "Authorization": `Bearer ${SUPABASE_KEY}`,
            "Prefer": "return=representation"
          },
          body: JSON.stringify({
            restaurant_id:    restaurant.id,
            donation_img_url: donationImgUrl,
            description:      description    || null,
            pickup_location:  pickupLocation || null,
            picked_up:        "pending",
            is_available:     true
          })
        });

        if (!insertRes.ok) {
          const t = await insertRes.text();
          return new Response(t || "Donation insert failed", {
            status: insertRes.status,
            headers: { "Content-Type": "application/json", ...cors }
          });
        }

        const insertText = await insertRes.text();
        let donation = null;
        try {
          const parsed = JSON.parse(insertText);
          donation = Array.isArray(parsed) ? (parsed[0] ?? null) : parsed;
        } catch {
          donation = null;
        }

        if (!donation || !donation.id) {
          return new Response(JSON.stringify({ error: "Donation insert did not return an id" }), {
            status: 500,
            headers: { "Content-Type": "application/json", ...cors }
          });
        }

        // ── Insert items (if any) ──
        if (items.length > 0) {
          const itemRows = items.map((it) => ({
            donation_id:       donation.id,
            item_name:         it.item_name.trim(),
            quantity:          Math.trunc(Number(it.quantity)),
            donation_item_img: it.donation_item_img.trim(),
            description:       typeof it.description === "string" && it.description.trim() ? it.description.trim() : null
          }));

          const itemsInsertRes = await fetch(`${SUPABASE_URL}/rest/v1/donation_items`, {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              "apikey": SUPABASE_KEY,
              "Authorization": `Bearer ${SUPABASE_KEY}`,
              "Prefer": "return=representation"
            },
            body: JSON.stringify(itemRows)
          });

          if (!itemsInsertRes.ok) {
            const t = await itemsInsertRes.text();
            return new Response(t || "Donation items insert failed", {
              status: itemsInsertRes.status,
              headers: { "Content-Type": "application/json", ...cors }
            });
          }

          const itemsText = await itemsInsertRes.text();
          let insertedItems = [];
          try { insertedItems = JSON.parse(itemsText); } catch { insertedItems = []; }

          return new Response(JSON.stringify({ ...donation, items: Array.isArray(insertedItems) ? insertedItems : [] }), {
            status: 201,
            headers: { "Content-Type": "application/json", ...cors }
          });
        }

        return new Response(JSON.stringify({ ...donation, items: [] }), {
          status: 201,
          headers: { "Content-Type": "application/json", ...cors }
        });
      }

// REMOVE DONATION

      if (method === "POST" && path === "/restaurant/remove-donation") {
        const cors = corsHeaders(request);

        let body = null;
        try { body = await request.json(); } catch { body = null; }

        const donationId = body && typeof body.donation_id === "string" ? body.donation_id.trim() : "";
        if (!donationId) {
          return new Response(JSON.stringify({ error: "donation_id is required" }), {
            status: 400,
            headers: { "Content-Type": "application/json", ...cors }
          });
        }

        const restaurantRes = await fetch(
          `${SUPABASE_URL}/rest/v1/restaurants?profile_id=eq.${profile.profile_id}&select=id,is_active`,
          { headers: { "apikey": SUPABASE_KEY, "Authorization": `Bearer ${SUPABASE_KEY}` } }
        );
        if (!restaurantRes.ok) {
          const t = await restaurantRes.text();
          return new Response(t || "Restaurant lookup failed", {
            status: restaurantRes.status,
            headers: { "Content-Type": "application/json", ...cors }
          });
        }
        const restaurantRows = await restaurantRes.json();
        const restaurant = Array.isArray(restaurantRows) ? restaurantRows[0] : null;
        if (!restaurant || !restaurant.id) {
          return new Response(JSON.stringify({ error: "RESTAURANT_NOT_FOUND" }), {
            status: 400,
            headers: { "Content-Type": "application/json", ...cors }
          });
        }
        if (restaurant.is_active === false) {
          return new Response(JSON.stringify({ error: "RESTAURANT_INACTIVE" }), {
            status: 403,
            headers: { "Content-Type": "application/json", ...cors }
          });
        }

        const donationCheckRes = await fetch(
          `${SUPABASE_URL}/rest/v1/donations?id=eq.${donationId}&restaurant_id=eq.${restaurant.id}&select=id,picked_up`,
          { headers: { "apikey": SUPABASE_KEY, "Authorization": `Bearer ${SUPABASE_KEY}` } }
        );
        if (!donationCheckRes.ok) {
          const t = await donationCheckRes.text();
          return new Response(t || "Donation lookup failed", {
            status: donationCheckRes.status,
            headers: { "Content-Type": "application/json", ...cors }
          });
        }
        const donationRows = await donationCheckRes.json();
        const donation = Array.isArray(donationRows) ? donationRows[0] : null;
        if (!donation || !donation.id) {
          return new Response(JSON.stringify({ error: "DONATION_NOT_FOUND" }), {
            status: 404,
            headers: { "Content-Type": "application/json", ...cors }
          });
        }
        if (donation.picked_up === "picked_up") {
          return new Response(JSON.stringify({ error: "DONATION_ALREADY_PICKED_UP" }), {
            status: 409,
            headers: { "Content-Type": "application/json", ...cors }
          });
        }

        return callRPC("remove_donation", {
          p_profile_id:  profile.profile_id,
          p_donation_id: donationId
        }, request);
      }

      // APPROVE PICKUP  POST /restaurant/pickup/approve

      if (method === "POST" && path === "/restaurant/pickup/approve") {
        const cors = corsHeaders(request);
        let body = null;
        try { body = await request.json(); } catch { body = null; }
      
        const pickupId = body && typeof body.pickup_id === "string" ? body.pickup_id.trim() : "";
        if (!pickupId) {
          return new Response(JSON.stringify({ error: "pickup_id is required" }), {
            status: 400, headers: { "Content-Type": "application/json", ...cors }
          });
        }
      
        const restaurantRes = await fetch(
          `${SUPABASE_URL}/rest/v1/restaurants?profile_id=eq.${profile.profile_id}&select=id,is_active,name`,
          { headers: { "apikey": SUPABASE_KEY, "Authorization": `Bearer ${SUPABASE_KEY}` } }
        );
        if (!restaurantRes.ok) {
          const t = await restaurantRes.text();
          return new Response(t || "Restaurant lookup failed", {
            status: restaurantRes.status, headers: { "Content-Type": "application/json", ...cors }
          });
        }
        const restaurantRows = await restaurantRes.json();
        const restaurant = Array.isArray(restaurantRows) ? restaurantRows[0] : null;
        if (!restaurant || !restaurant.id) {
          return new Response(JSON.stringify({ error: "RESTAURANT_NOT_FOUND" }), {
            status: 400, headers: { "Content-Type": "application/json", ...cors }
          });
        }
        if (restaurant.is_active === false) {
          return new Response(JSON.stringify({ error: "RESTAURANT_INACTIVE" }), {
            status: 403, headers: { "Content-Type": "application/json", ...cors }
          });
        }
      
        const pickupCheckRes = await fetch(
          `${SUPABASE_URL}/rest/v1/pickup_requests?id=eq.${pickupId}&select=id,status,charity_id,donation_id,donations!inner(restaurant_id,description)`,
          { headers: { "apikey": SUPABASE_KEY, "Authorization": `Bearer ${SUPABASE_KEY}` } }
        );
        if (!pickupCheckRes.ok) {
          const t = await pickupCheckRes.text();
          return new Response(t || "Pickup lookup failed", {
            status: pickupCheckRes.status, headers: { "Content-Type": "application/json", ...cors }
          });
        }
        const pickupRows = await pickupCheckRes.json();
        const pickup = Array.isArray(pickupRows) ? pickupRows[0] : null;
        if (!pickup || !pickup.id) {
          return new Response(JSON.stringify({ error: "PICKUP_REQUEST_NOT_FOUND" }), {
            status: 404, headers: { "Content-Type": "application/json", ...cors }
          });
        }
        if (pickup?.donations?.restaurant_id !== restaurant.id) {
          return new Response(JSON.stringify({ error: "UNAUTHORIZED" }), {
            status: 403, headers: { "Content-Type": "application/json", ...cors }
          });
        }
        if (pickup.status !== "pending") {
          return new Response(JSON.stringify({ error: "PICKUP_NOT_PENDING", current_status: pickup.status }), {
            status: 409, headers: { "Content-Type": "application/json", ...cors }
          });
        }
      
        const rpcRes = await callRPC("restaurant_approve_pickup", {
          p_pickup_id:  pickupId,
          p_profile_id: profile.profile_id
        }, request);
      
        // ── Notify charity: request approved ──
        if (rpcRes.status === 200 || rpcRes.status === 201) {
          const donationDesc   = pickup.donations?.description || "a donation";
          const restaurantName = restaurant.name || "The restaurant";
          await notify(
            pickup.charity_id,
            "pickup_approved",
            "Pickup request approved ✓",
            `${restaurantName} approved your pickup request for ${donationDesc}.`,
            "/charity/pickups",
            { title: "Pickup approved ✓", body: `${restaurantName} approved your request.` }
          );
        }
      
        return rpcRes;
      }

      // REJECT PICKUP  POST /restaurant/pickup/reject
  
      if (method === "POST" && path === "/restaurant/pickup/reject") {
        const cors = corsHeaders(request);
        let body = null;
        try { body = await request.json(); } catch { body = null; }
      
        const pickupId = body && typeof body.pickup_id === "string" ? body.pickup_id.trim() : "";
        if (!pickupId) {
          return new Response(JSON.stringify({ error: "pickup_id is required" }), {
            status: 400, headers: { "Content-Type": "application/json", ...cors }
          });
        }
      
        const restaurantRes = await fetch(
          `${SUPABASE_URL}/rest/v1/restaurants?profile_id=eq.${profile.profile_id}&select=id,is_active,name`,
          { headers: { "apikey": SUPABASE_KEY, "Authorization": `Bearer ${SUPABASE_KEY}` } }
        );
        if (!restaurantRes.ok) {
          const t = await restaurantRes.text();
          return new Response(t || "Restaurant lookup failed", {
            status: restaurantRes.status, headers: { "Content-Type": "application/json", ...cors }
          });
        }
        const restaurantRows = await restaurantRes.json();
        const restaurant = Array.isArray(restaurantRows) ? restaurantRows[0] : null;
        if (!restaurant || !restaurant.id) {
          return new Response(JSON.stringify({ error: "RESTAURANT_NOT_FOUND" }), {
            status: 400, headers: { "Content-Type": "application/json", ...cors }
          });
        }
        if (restaurant.is_active === false) {
          return new Response(JSON.stringify({ error: "RESTAURANT_INACTIVE" }), {
            status: 403, headers: { "Content-Type": "application/json", ...cors }
          });
        }
      
        const pickupCheckRes = await fetch(
          `${SUPABASE_URL}/rest/v1/pickup_requests?id=eq.${pickupId}&select=id,status,charity_id,donation_id,donations!inner(restaurant_id,description)`,
          { headers: { "apikey": SUPABASE_KEY, "Authorization": `Bearer ${SUPABASE_KEY}` } }
        );
        if (!pickupCheckRes.ok) {
          const t = await pickupCheckRes.text();
          return new Response(t || "Pickup lookup failed", {
            status: pickupCheckRes.status, headers: { "Content-Type": "application/json", ...cors }
          });
        }
        const pickupRows = await pickupCheckRes.json();
        const pickup = Array.isArray(pickupRows) ? pickupRows[0] : null;
        if (!pickup || !pickup.id) {
          return new Response(JSON.stringify({ error: "PICKUP_REQUEST_NOT_FOUND" }), {
            status: 404, headers: { "Content-Type": "application/json", ...cors }
          });
        }
        if (pickup?.donations?.restaurant_id !== restaurant.id) {
          return new Response(JSON.stringify({ error: "UNAUTHORIZED" }), {
            status: 403, headers: { "Content-Type": "application/json", ...cors }
          });
        }
        if (pickup.status !== "pending") {
          return new Response(JSON.stringify({ error: "PICKUP_NOT_PENDING", current_status: pickup.status }), {
            status: 409, headers: { "Content-Type": "application/json", ...cors }
          });
        }
      
        const rpcRes = await callRPC("restaurant_reject_pickup", {
          p_pickup_id:  pickupId,
          p_profile_id: profile.profile_id
        }, request);
      
        // ── Notify charity: request rejected ──  (fixed: was "pickup_approved")
        if (rpcRes.status === 200 || rpcRes.status === 201) {
          const donationDesc   = pickup.donations?.description || "a donation";
          const restaurantName = restaurant.name || "The restaurant";
          await notify(
            pickup.charity_id,
            "pickup_rejected",                                                   // ← FIXED
            "Pickup request declined",
            `${restaurantName} declined your pickup request for ${donationDesc}.`,
            "/charity/pickups",
            { title: "Pickup request declined", body: `${restaurantName} declined your request.` }
          );
        }
      
        return rpcRes;
      }

// GET PICKUP REQUESTS FOR MY DONATIONS
      if (method === "GET" && path === "/restaurant/pickup-requests") {
        const cors = corsHeaders(request);

        const limitRaw = url.searchParams.get("limit");
        const offsetRaw = url.searchParams.get("offset");
        const cursorRaw = url.searchParams.get("cursor");
        const statusRaw = url.searchParams.get("status");

        const limitParsed = limitRaw && limitRaw.trim() !== "" ? Number(limitRaw) : 20;
        const offsetParsed = offsetRaw && offsetRaw.trim() !== "" ? Number(offsetRaw) : 0;
        const limit = Number.isFinite(limitParsed) ? Math.max(1, Math.min(50, Math.trunc(limitParsed))) : 20;
        const offset = Number.isFinite(offsetParsed) ? Math.max(0, Math.trunc(offsetParsed)) : 0;

        const restaurantRes = await fetch(
          `${SUPABASE_URL}/rest/v1/restaurants?profile_id=eq.${profile.profile_id}&select=id,is_active`,
          { headers: { "apikey": SUPABASE_KEY, "Authorization": `Bearer ${SUPABASE_KEY}` } }
        );
        if (!restaurantRes.ok) {
          const t = await restaurantRes.text();
          return new Response(t || "Restaurant lookup failed", {
            status: restaurantRes.status,
            headers: { "Content-Type": "application/json", ...cors }
          });
        }
        const restaurantRows = await restaurantRes.json();
        const restaurant = Array.isArray(restaurantRows) ? restaurantRows[0] : null;
        if (!restaurant || !restaurant.id) {
          return new Response(JSON.stringify({ error: "RESTAURANT_NOT_FOUND" }), {
            status: 400,
            headers: { "Content-Type": "application/json", ...cors }
          });
        }
        if (restaurant.is_active === false) {
          return new Response(JSON.stringify({ error: "RESTAURANT_INACTIVE" }), {
            status: 403,
            headers: { "Content-Type": "application/json", ...cors }
          });
        }

        const donationIdsRes = await fetch(
          `${SUPABASE_URL}/rest/v1/donations?restaurant_id=eq.${restaurant.id}&select=id`,
          { headers: { "apikey": SUPABASE_KEY, "Authorization": `Bearer ${SUPABASE_KEY}` } }
        );
        if (!donationIdsRes.ok) {
          const t = await donationIdsRes.text();
          return new Response(t || "Donation lookup failed", {
            status: donationIdsRes.status,
            headers: { "Content-Type": "application/json", ...cors }
          });
        }
        const donationIdRows = await donationIdsRes.json();
        const donationIds = Array.isArray(donationIdRows) ? donationIdRows.map((d) => d.id).filter(Boolean) : [];

        if (donationIds.length === 0) {
          return new Response(JSON.stringify([]), {
            status: 200,
            headers: {
              "Content-Type": "application/json",
              ...cors,
              "X-Next-Offset": "0",
              "X-Next-Cursor": ""
            }
          });
        }

        const params = new URLSearchParams();
        // ── Join profiles to get charity_name ──
        params.set("select", "id,status,created_at,updated_at,charity_id,donation_id,profiles!pickup_requests_charity_id_fkey(full_name)");
        params.set("donation_id", `in.(${donationIds.join(",")})`);
        params.set("order", "created_at.desc,id.desc");
        params.set("limit", String(limit));

        const allowedStatuses = new Set(["pending", "approved", "rejected"]);
        if (statusRaw && statusRaw.trim() !== "" && allowedStatuses.has(statusRaw.trim())) {
          params.set("status", `eq.${statusRaw.trim()}`);
        }

        if (cursorRaw && cursorRaw.trim() !== "") {
          let decoded = null;
          try { decoded = decodeURIComponent(cursorRaw); } catch { decoded = cursorRaw; }
          const parts = typeof decoded === "string" ? decoded.split("|") : [];
          const cursorCreatedAt = parts.length >= 1 && parts[0] ? parts[0] : null;
          const cursorId = parts.length >= 2 && parts[1] ? parts[1] : null;
          if (cursorCreatedAt && cursorId) {
            params.set("and", `(or(created_at.lt.${cursorCreatedAt},and(created_at.eq.${cursorCreatedAt},id.lt.${cursorId})))`);
          } else if (cursorCreatedAt) {
            params.set("created_at", `lt.${cursorCreatedAt}`);
          }
        } else {
          params.set("offset", String(offset));
        }

        const pickupRes = await fetch(`${SUPABASE_URL}/rest/v1/pickup_requests?${params.toString()}`, {
          headers: { "apikey": SUPABASE_KEY, "Authorization": `Bearer ${SUPABASE_KEY}` }
        });
        const rawText = await pickupRes.text();

        if (!pickupRes.ok) {
          return new Response(rawText || "Pickup requests lookup failed", {
            status: pickupRes.status,
            headers: { "Content-Type": "application/json", ...cors }
          });
        }

        let rows = [];
        try { rows = JSON.parse(rawText); } catch { rows = []; }
        if (!Array.isArray(rows)) rows = [];

        // ── Fetch donation details (img/desc/location/status) for the donation_ids in this page ──
        const pageDonationIds = [...new Set(rows.map((r) => r.donation_id).filter(Boolean))];
        let donationMap = {};
        if (pageDonationIds.length > 0) {
          const donRes = await fetch(
            `${SUPABASE_URL}/rest/v1/donations?id=in.(${pageDonationIds.join(",")})&select=id,donation_img_url,description,pickup_location,picked_up,is_available`,
            { headers: { "apikey": SUPABASE_KEY, "Authorization": `Bearer ${SUPABASE_KEY}` } }
          );
          if (donRes.ok) {
            const donRows = await donRes.json();
            if (Array.isArray(donRows)) {
              for (const d of donRows) {
                donationMap[d.id] = d;
              }
            }
          }
        }

        // ── Flatten profiles join + merge donation fields ──
        const mapped = rows.map((r) => {
          const { profiles, ...rest } = r;
          const don = donationMap[r.donation_id] || {};
          return {
            ...rest,
            charity_name:     profiles?.full_name ?? null,
            donation_img_url: don.donation_img_url ?? null,
            description:      don.description ?? null,
            pickup_location:  don.pickup_location ?? null,
            picked_up:        don.picked_up ?? null,
            is_available:     don.is_available ?? null
          };
        });

        let nextCursor = "";
        if (mapped.length > 0) {
          const last = mapped[mapped.length - 1];
          const lastCreatedAt = last && typeof last.created_at === "string" ? last.created_at : null;
          const lastId = last && typeof last.id === "string" ? last.id : null;
          if (lastCreatedAt && lastId) nextCursor = `${lastCreatedAt}|${lastId}`;
        }

        return new Response(JSON.stringify(mapped), {
          status: 200,
          headers: {
            "Content-Type": "application/json",
            ...cors,
            "X-Next-Offset": String(offset + limit),
            "X-Next-Cursor": nextCursor
          }
        });
      }
      // DONATION HISTORY (completed pickups)
      if (method === "GET" && path === "/restaurant/history/donations") {
        const cors = corsHeaders(request);

        const hasParams =
          url.searchParams.has("limit") ||
          url.searchParams.has("offset") ||
          url.searchParams.has("cursor") ||
          url.searchParams.has("time") ||
          url.searchParams.has("from") ||
          url.searchParams.has("to") ||
          url.searchParams.has("tz_offset_minutes");

        if (!hasParams) {
          return callRPC("restaurant_donations_history", { p_profile_id: profile.profile_id }, request);
        }

        const limitRaw = url.searchParams.get("limit");
        const offsetRaw = url.searchParams.get("offset");
        const cursorRaw = url.searchParams.get("cursor");
        const time = (url.searchParams.get("time") || "all").toLowerCase();
        const fromRaw = url.searchParams.get("from");
        const toRaw = url.searchParams.get("to");
        const tzOffsetRaw = url.searchParams.get("tz_offset_minutes");

        const limitParsed = limitRaw && limitRaw.trim() !== "" ? Number(limitRaw) : 20;
        const offsetParsed = offsetRaw && offsetRaw.trim() !== "" ? Number(offsetRaw) : 0;
        const limit = Number.isFinite(limitParsed) ? Math.max(1, Math.min(50, Math.trunc(limitParsed))) : 20;
        const offset = Number.isFinite(offsetParsed) ? Math.max(0, Math.trunc(offsetParsed)) : 0;

        const tzOffsetMinutesParsed = tzOffsetRaw && tzOffsetRaw.trim() !== "" ? Number(tzOffsetRaw) : null;
        const tzOffsetMinutes = Number.isFinite(tzOffsetMinutesParsed)
          ? Math.max(-840, Math.min(840, Math.trunc(tzOffsetMinutesParsed)))
          : null;

        const parseIso = (v) => {
          if (!v || typeof v !== "string" || !v.trim()) return null;
          const d = new Date(v);
          return Number.isFinite(d.getTime()) ? d.toISOString() : null;
        };

        const now = new Date();

        const computeStartOfDayIso = () => {
          if (tzOffsetMinutes == null) {
            const d = new Date(now); d.setUTCHours(0, 0, 0, 0); return d.toISOString();
          }
          const localMs = now.getTime() - tzOffsetMinutes * 60_000;
          const local = new Date(localMs); local.setUTCHours(0, 0, 0, 0);
          return new Date(local.getTime() + tzOffsetMinutes * 60_000).toISOString();
        };

        const computeStartOfWeekIso = () => {
          if (tzOffsetMinutes == null) {
            const d = new Date(now);
            d.setUTCDate(d.getUTCDate() - (d.getUTCDay() + 6) % 7);
            d.setUTCHours(0, 0, 0, 0); return d.toISOString();
          }
          const localMs = now.getTime() - tzOffsetMinutes * 60_000;
          const local = new Date(localMs);
          local.setUTCDate(local.getUTCDate() - (local.getUTCDay() + 6) % 7);
          local.setUTCHours(0, 0, 0, 0);
          return new Date(local.getTime() + tzOffsetMinutes * 60_000).toISOString();
        };

        const fromIso = time === "today" ? computeStartOfDayIso()
          : (time === "week" || time === "thisweek" || time === "this_week") ? computeStartOfWeekIso()
          : parseIso(fromRaw);
        const toIso = parseIso(toRaw);

        const restaurantRes = await fetch(
          `${SUPABASE_URL}/rest/v1/restaurants?profile_id=eq.${profile.profile_id}&select=id,is_active`,
          { headers: { "apikey": SUPABASE_KEY, "Authorization": `Bearer ${SUPABASE_KEY}` } }
        );
        if (!restaurantRes.ok) {
          const t = await restaurantRes.text();
          return new Response(t || "Restaurant lookup failed", {
            status: restaurantRes.status,
            headers: { "Content-Type": "application/json", ...cors }
          });
        }
        const restaurantRows = await restaurantRes.json();
        const restaurant = Array.isArray(restaurantRows) ? restaurantRows[0] : null;
        if (!restaurant || !restaurant.id) {
          return new Response(JSON.stringify({ error: "RESTAURANT_NOT_FOUND" }), {
            status: 400,
            headers: { "Content-Type": "application/json", ...cors }
          });
        }
        if (restaurant.is_active === false) {
          return new Response(JSON.stringify({ error: "RESTAURANT_INACTIVE" }), {
            status: 403,
            headers: { "Content-Type": "application/json", ...cors }
          });
        }

        const params = new URLSearchParams();
        params.set("select", "id,donation_img_url,picked_up,created_at,description,pickup_location,pickup_requests!left(charity_id,status)");
        params.set("restaurant_id", `eq.${restaurant.id}`);
        params.set("picked_up", "in.(approved,rejected,picked_up)");
        params.set("order", "created_at.desc,id.desc");
        params.set("limit", String(limit));

        if (fromIso) params.set("created_at", `gte.${fromIso}`);
        if (toIso) {
          const existing = params.get("created_at");
          params.set("created_at", existing ? `${existing},lte.${toIso}` : `lte.${toIso}`);
        }

        if (cursorRaw && cursorRaw.trim() !== "") {
          let decoded = null;
          try { decoded = decodeURIComponent(cursorRaw); } catch { decoded = cursorRaw; }
          const parts = typeof decoded === "string" ? decoded.split("|") : [];
          const cursorCreatedAt = parts.length >= 1 && parts[0] ? parts[0] : null;
          const cursorId = parts.length >= 2 && parts[1] ? parts[1] : null;
          if (cursorCreatedAt && cursorId) {
            params.set("and", `(or(created_at.lt.${cursorCreatedAt},and(created_at.eq.${cursorCreatedAt},id.lt.${cursorId})))`);
          } else if (cursorCreatedAt) {
            const existing = params.get("created_at");
            params.set("created_at", existing ? `${existing},lt.${cursorCreatedAt}` : `lt.${cursorCreatedAt}`);
          }
        } else {
          params.set("offset", String(offset));
        }

        const historyRes = await fetch(`${SUPABASE_URL}/rest/v1/donations?${params.toString()}`, {
          headers: { "apikey": SUPABASE_KEY, "Authorization": `Bearer ${SUPABASE_KEY}` }
        });
        const rawText = await historyRes.text();

        let nextCursor = "";
        let payloadText = rawText;

        if (historyRes.ok) {
          try {
            const rows = JSON.parse(rawText);
            if (Array.isArray(rows)) {
              const mapped = rows.map((d) => {
                const requests = Array.isArray(d.pickup_requests) ? d.pickup_requests : [];
                const approved = requests.find((r) => r.status === "approved") ?? null;
                return {
                  donation_id:     d.id ?? null,
                  donation_img_url: d.donation_img_url ?? null,
                  picked_up:       d.picked_up ?? null,
                  created_at:      d.created_at ?? null,
                  description:     d.description ?? null,
                  pickup_location: d.pickup_location ?? null,
                  approved_charity: approved?.charity_id ?? null,
                  request_status:  approved?.status ?? null
                };
              });

              payloadText = JSON.stringify(mapped);

              if (mapped.length > 0) {
                const last = mapped[mapped.length - 1];
                const lastCreatedAt = last && typeof last.created_at === "string" ? last.created_at : null;
                const lastDonationId = last && typeof last.donation_id === "string" ? last.donation_id : null;
                if (lastCreatedAt && lastDonationId) nextCursor = `${lastCreatedAt}|${lastDonationId}`;
              }
            }
          } catch { nextCursor = ""; payloadText = rawText; }
        }

        return new Response(payloadText, {
          status: historyRes.status,
          headers: {
            "Content-Type": "application/json",
            ...cors,
            "X-Next-Offset": String(offset + limit),
            "X-Next-Cursor": nextCursor
          }
        });
      }


      // GET MY DONATION ITEMS
      if (method === "GET" && path === "/restaurant/donation-items") {
            const cors = corsHeaders(request);

            const donationId = (url.searchParams.get("donation_id") || "").trim();
            if (!donationId) {
                  return new Response(JSON.stringify({ error: "donation_id is required" }), {
                        status: 400,
                        headers: { "Content-Type": "application/json", ...cors }
                  });
            }

            // Verify the donation belongs to this restaurant
            const restaurantRes = await fetch(
                  `${SUPABASE_URL}/rest/v1/restaurants?profile_id=eq.${profile.profile_id}&select=id`,
                  { headers: { "apikey": SUPABASE_KEY, "Authorization": `Bearer ${SUPABASE_KEY}` } }
            );
            const restaurantRows = await restaurantRes.json();
            const restaurant = Array.isArray(restaurantRows) ? restaurantRows[0] : null;
            if (!restaurant?.id) {
                  return new Response(JSON.stringify({ error: "RESTAURANT_NOT_FOUND" }), {
                        status: 400, headers: { "Content-Type": "application/json", ...cors }
                  });
            }

            // Verify the donation belongs to this restaurant
            const donationCheckRes = await fetch(
                  `${SUPABASE_URL}/rest/v1/donations?id=eq.${donationId}&restaurant_id=eq.${restaurant.id}&select=id`,
                  { headers: { "apikey": SUPABASE_KEY, "Authorization": `Bearer ${SUPABASE_KEY}` } }
            );
            const donationRows = await donationCheckRes.json();
            if (!Array.isArray(donationRows) || donationRows.length === 0) {
                  return new Response(JSON.stringify({ error: "UNAUTHORIZED" }), {
                        status: 403, headers: { "Content-Type": "application/json", ...cors }
                  });
            }

            // Fetch items directly
            const itemsRes = await fetch(
                  `${SUPABASE_URL}/rest/v1/donation_items?donation_id=eq.${donationId}&select=id,donation_id,item_name,quantity,donation_item_img,description,created_at&order=created_at.desc`,
                  { headers: { "apikey": SUPABASE_KEY, "Authorization": `Bearer ${SUPABASE_KEY}` } }
            );
            const text = await itemsRes.text();
            return new Response(text, {
                  status: itemsRes.status,
                  headers: { "Content-Type": "application/json", ...cors }
            });
      }

      // ADD DONATION ITEM
      if (method === "POST" && path === "/restaurant/donation-items/add") {
        const cors = corsHeaders(request);
        const contentType = request.headers.get("Content-Type") || "";

        let donationId      = "";
        let itemName        = "";
        let quantity        = null;
        let donationItemImg = "";
        let itemDescription = "";

        // ── multipart/form-data ──
        if (contentType.includes("multipart/form-data")) {
          const form = await request.formData();

          const fileKeys = ["image", "item_image", "donation_item_image", "file"];
          const files = fileKeys.flatMap((k) => form.getAll(k)).filter((v) => v && typeof v === "object" && "arrayBuffer" in v);
          if (files.length > 1) {
            return new Response(JSON.stringify({ error: "Only one item image is allowed" }), {
              status: 400,
              headers: { "Content-Type": "application/json", ...cors }
            });
          }

          const image = files[0] || null;
          const did  = form.get("donation_id");
          const name = form.get("item_name");
          const qty  = form.get("quantity");
          const desc = form.get("description");

          donationId      = typeof did  === "string" ? did.trim()  : "";
          itemName        = typeof name === "string" ? name.trim() : "";
          quantity        = typeof qty  === "string" && qty !== "" ? Number(qty) : null;
          itemDescription = typeof desc === "string" ? desc.trim() : "";

          // ── Validate required fields before upload ──
          if (!donationId) {
            return new Response(JSON.stringify({ error: "donation_id is required" }), {
              status: 400,
              headers: { "Content-Type": "application/json", ...cors }
            });
          }
          if (!itemName) {
            return new Response(JSON.stringify({ error: "item_name is required" }), {
              status: 400,
              headers: { "Content-Type": "application/json", ...cors }
            });
          }
          const quantityNumEarly = quantity === null ? NaN : quantity;
          if (!Number.isFinite(quantityNumEarly) || quantityNumEarly <= 0) {
            return new Response(JSON.stringify({ error: "quantity must be a number greater than 0" }), {
              status: 400,
              headers: { "Content-Type": "application/json", ...cors }
            });
          }

          if (!(image && typeof image === "object" && "arrayBuffer" in image)) {
            return new Response(JSON.stringify({ error: "Item image file is mandatory" }), {
              status: 400,
              headers: { "Content-Type": "application/json", ...cors }
            });
          }

          try {
            const stored = await putMealImageToR2({ file: image, profile_id: profile.profile_id });
            donationItemImg = stored.url;
          } catch {
            return new Response(JSON.stringify({ error: "Image upload failed" }), {
              status: 500,
              headers: { "Content-Type": "application/json", ...cors }
            });
          }

        // ── JSON body ──
        } else {
          let body = null;
          try { body = await request.json(); } catch { body = null; }

          donationId      = body && typeof body.donation_id  === "string" ? body.donation_id.trim()  : "";
          itemName        = body && typeof body.item_name    === "string" ? body.item_name.trim()    : "";
          quantity        = body && body.quantity !== undefined             ? Number(body.quantity)    : null;
          itemDescription = body && typeof body.description  === "string" ? body.description.trim()  : "";

          if (body && body.donation_item_img && body.donation_item_img_base64) {
            return new Response(JSON.stringify({ error: "Only one item image is allowed" }), {
              status: 400,
              headers: { "Content-Type": "application/json", ...cors }
            });
          }

          if (body && typeof body.donation_item_img === "string" && body.donation_item_img.trim()) {
            donationItemImg = body.donation_item_img.trim();

          } else if (body && typeof body.donation_item_img_base64 === "string" && body.donation_item_img_base64.trim()) {
            const m = body.donation_item_img_base64.match(/^data:(.+?);base64,(.+)$/);
            if (!m) {
              return new Response(JSON.stringify({ error: "Invalid base64 image" }), {
                status: 400,
                headers: { "Content-Type": "application/json", ...cors }
              });
            }
            const mime = m[1];
            const b64  = m[2];
            const bin  = Uint8Array.from(atob(b64), (c) => c.charCodeAt(0));
            const file = new File(
              [bin],
              `item.${mime === "image/jpeg" ? "jpg" : mime === "image/png" ? "png" : mime === "image/webp" ? "webp" : "bin"}`,
              { type: mime }
            );
            try {
              const stored = await putMealImageToR2({ file, profile_id: profile.profile_id });
              donationItemImg = stored.url;
            } catch {
              return new Response(JSON.stringify({ error: "Image upload failed" }), {
                status: 500,
                headers: { "Content-Type": "application/json", ...cors }
              });
            }
          }
        }

        // ── Validation (covers JSON path; multipart already validated above) ──
        if (!donationId) {
          return new Response(JSON.stringify({ error: "donation_id is required" }), {
            status: 400,
            headers: { "Content-Type": "application/json", ...cors }
          });
        }
        if (!itemName) {
          return new Response(JSON.stringify({ error: "item_name is required" }), {
            status: 400,
            headers: { "Content-Type": "application/json", ...cors }
          });
        }
        const quantityNum = quantity === null ? NaN : quantity;
        if (!Number.isFinite(quantityNum) || quantityNum <= 0) {
          return new Response(JSON.stringify({ error: "quantity must be a number greater than 0" }), {
            status: 400,
            headers: { "Content-Type": "application/json", ...cors }
          });
        }
        if (!donationItemImg) {
          return new Response(JSON.stringify({ error: "Item image is mandatory" }), {
            status: 400,
            headers: { "Content-Type": "application/json", ...cors }
          });
        }

        return callRPC("add_donation_item", {
          p_profile_id:        profile.profile_id,
          p_donation_id:       donationId,
          p_item_name:         itemName,
          p_quantity:          Math.trunc(quantityNum),
          p_donation_item_img: donationItemImg,
          p_description:       itemDescription || null
        }, request);
      }

      // REMOVE DONATION ITEM
      if (method === "DELETE" && path === "/restaurant/donation-items/remove") {
        const cors = corsHeaders(request);

        let body = null;
        try { body = await request.json(); } catch { body = null; }

        const itemId = body && typeof body.item_id === "string" ? body.item_id.trim() : "";
        if (!itemId) {
          return new Response(JSON.stringify({ error: "item_id is required" }), {
            status: 400,
            headers: { "Content-Type": "application/json", ...cors }
          });
        }

        return callRPC("remove_donation_item", {
          p_profile_id: profile.profile_id,
          p_item_id:    itemId
        }, request);
      }

      // SCHEDULE PICKUP  POST /restaurant/pickup/schedule
    
      if (method === "POST" && path === "/restaurant/pickup/schedule") {
        const cors = corsHeaders(request);
        let body = null;
        try { body = await request.json(); } catch { body = null; }
      
        const pickupId    = body && typeof body.pickup_id    === "string" ? body.pickup_id.trim()    : "";
        const scheduledAt = body && typeof body.scheduled_at === "string" ? body.scheduled_at.trim() : "";
        const notes       = body && typeof body.notes        === "string" ? body.notes.trim()        : null;
      
        if (!pickupId) {
          return new Response(JSON.stringify({ error: "pickup_id is required" }), {
            status: 400, headers: { "Content-Type": "application/json", ...cors }
          });
        }
        if (!scheduledAt || !Date.parse(scheduledAt)) {
          return new Response(JSON.stringify({ error: "scheduled_at must be a valid ISO timestamp" }), {
            status: 400, headers: { "Content-Type": "application/json", ...cors }
          });
        }
        if (new Date(scheduledAt) <= new Date()) {
          return new Response(JSON.stringify({ error: "scheduled_at must be in the future" }), {
            status: 400, headers: { "Content-Type": "application/json", ...cors }
          });
        }
      
        // Fetch pickup + charity_id + restaurant name before calling RPC
        const pickupCheckRes = await fetch(
          `${SUPABASE_URL}/rest/v1/pickup_requests?id=eq.${pickupId}&select=id,charity_id,donation_id,donations!inner(description,restaurants!inner(name))`,
          { headers: { "apikey": SUPABASE_KEY, "Authorization": `Bearer ${SUPABASE_KEY}` } }
        );
        const pickupRows = await pickupCheckRes.json();
        const pickup = Array.isArray(pickupRows) ? pickupRows[0] : null;
      
        const rpcRes = await callRPC("schedule_pickup", {
          p_profile_id:        profile.profile_id,
          p_pickup_request_id: pickupId,
          p_scheduled_at:      scheduledAt,
          p_notes:             notes
        }, request);
      
        // ── Notify charity: pickup time proposed ──
        if ((rpcRes.status === 200 || rpcRes.status === 201) && pickup?.charity_id) {
          const restaurantName = pickup.donations?.restaurants?.name || "The restaurant";
          const formattedTime  = new Date(scheduledAt).toLocaleString("en-GB", {
            dateStyle: "medium", timeStyle: "short"
          });
          await notify(
            pickup.charity_id,
            "pickup_reminder",
            "Pickup time proposed",
            `${restaurantName} proposed a pickup time: ${formattedTime}.${notes ? " Note: " + notes : ""}`,
            "/charity/schedules",
            { title: "Pickup time proposed", body: `${restaurantName}: ${formattedTime}` }
          );
        }
      
        return rpcRes;
      }

      // GET /restaurant/search/charities — search charities by name
          // GET /restaurant/search/charities — search charities by name
      if (method === "GET" && path.startsWith("/restaurant/search/charities")) {
            const cors = corsHeaders(request);
            const q = url.searchParams.get("q")?.trim() ?? "";

            let filter = `is_active=eq.true`;
            if (q) filter += `&name=ilike.*${encodeURIComponent(q)}*`;

            const res = await fetch(
                  `${SUPABASE_URL}/rest/v1/charity?${filter}&select=id,profile_id,name,description,address,charity_img_url,email,phone,website&order=name.asc&limit=30`,
                  { headers: { "apikey": SUPABASE_KEY, "Authorization": `Bearer ${SUPABASE_KEY}` } }
            );

            const rows = await res.json();

            return new Response(JSON.stringify(Array.isArray(rows) ? rows : []), {
                  status: 200,
                  headers: { "Content-Type": "application/json", ...cors }
            });
      }
      
      
      

      // RESCHEDULE PICKUP  POST /restaurant/pickup/reschedule
      if (method === "POST" && path === "/restaurant/pickup/reschedule") {
        const cors = corsHeaders(request);
        let body = null;
        try { body = await request.json(); } catch { body = null; }

        const scheduleId  = body && typeof body.schedule_id  === "string" ? body.schedule_id.trim()  : "";
        const scheduledAt = body && typeof body.scheduled_at === "string" ? body.scheduled_at.trim() : "";
        const notes       = body && typeof body.notes        === "string" ? body.notes.trim()        : null;

        if (!scheduleId) {
          return new Response(JSON.stringify({ error: "schedule_id is required" }), {
            status: 400, headers: { "Content-Type": "application/json", ...cors }
          });
        }
        if (!scheduledAt || !Date.parse(scheduledAt)) {
          return new Response(JSON.stringify({ error: "scheduled_at must be a valid ISO timestamp" }), {
            status: 400, headers: { "Content-Type": "application/json", ...cors }
          });
        }
        if (new Date(scheduledAt) <= new Date()) {
          return new Response(JSON.stringify({ error: "scheduled_at must be in the future" }), {
            status: 400, headers: { "Content-Type": "application/json", ...cors }
          });
        }

        // verify ownership then update directly
        const restaurantRes = await fetch(
          `${SUPABASE_URL}/rest/v1/restaurants?profile_id=eq.${profile.profile_id}&select=id`,
          { headers: { "apikey": SUPABASE_KEY, "Authorization": `Bearer ${SUPABASE_KEY}` } }
        );
        const restaurantRows = await restaurantRes.json();
        const restaurant = Array.isArray(restaurantRows) ? restaurantRows[0] : null;
        if (!restaurant?.id) {
          return new Response(JSON.stringify({ error: "RESTAURANT_NOT_FOUND" }), {
            status: 400, headers: { "Content-Type": "application/json", ...cors }
          });
        }

        // confirm schedule belongs to this restaurant and is still cancellable
        const checkRes = await fetch(
          `${SUPABASE_URL}/rest/v1/pickup_schedules` +
          `?id=eq.${scheduleId}` +
          `&select=id,status,pickup_request_id,pickup_requests!inner(donation_id,donations!inner(restaurant_id))`,
          { headers: { "apikey": SUPABASE_KEY, "Authorization": `Bearer ${SUPABASE_KEY}` } }
        );
        const checkRows = await checkRes.json();
        const sched = Array.isArray(checkRows) ? checkRows[0] : null;
        const restaurantIdOnSched = sched?.pickup_requests?.donations?.restaurant_id;
        if (!sched || restaurantIdOnSched !== restaurant.id) {
          return new Response(JSON.stringify({ error: "SCHEDULE_NOT_FOUND_OR_UNAUTHORIZED" }), {
            status: 404, headers: { "Content-Type": "application/json", ...cors }
          });
        }
        if (!["pending","confirmed"].includes(sched.status)) {
          return new Response(JSON.stringify({ error: "SCHEDULE_CANNOT_BE_CHANGED", current_status: sched.status }), {
            status: 409, headers: { "Content-Type": "application/json", ...cors }
          });
        }

        const patchRes = await fetch(
          `${SUPABASE_URL}/rest/v1/pickup_schedules?id=eq.${scheduleId}`,
          {
            method: "PATCH",
            headers: {
              "Content-Type": "application/json",
              "apikey": SUPABASE_KEY,
              "Authorization": `Bearer ${SUPABASE_KEY}`,
              "Prefer": "return=representation"
            },
            body: JSON.stringify({
              scheduled_at: scheduledAt,
              notes:        notes,
              status:       "pending",
              confirmed_at: null,
              updated_at:   new Date().toISOString()
            })
          }
        );
        const patchText = await patchRes.text();
        return new Response(patchText, {
          status: patchRes.ok ? 200 : patchRes.status,
          headers: { "Content-Type": "application/json", ...cors }
        });
      }

      // GET SCHEDULES  GET /restaurant/schedules
      if (method === "GET" && path === "/restaurant/schedules") {
        const cors = corsHeaders(request);
        const restaurantRes = await fetch(
          `${SUPABASE_URL}/rest/v1/restaurants?profile_id=eq.${profile.profile_id}&select=id`,
          { headers: { "apikey": SUPABASE_KEY, "Authorization": `Bearer ${SUPABASE_KEY}` } }
        );
        const restaurantRows = await restaurantRes.json();
        const restaurant = Array.isArray(restaurantRows) ? restaurantRows[0] : null;
        if (!restaurant?.id) {
          return new Response(JSON.stringify({ error: "RESTAURANT_NOT_FOUND" }), {
            status: 400, headers: { "Content-Type": "application/json", ...cors }
          });
        }

        const params = new URLSearchParams();
        params.set("select",
          "id,scheduled_at,notes,status,confirmed_at,created_at,updated_at," +
          "pickup_requests!inner(id,charity_id,donation_id," +
          "donations!inner(id,donation_img_url,description,pickup_location,restaurant_id))"
        );
        params.set("pickup_requests.donations.restaurant_id", `eq.${restaurant.id}`);
        params.set("status", "in.(pending,confirmed)");
        params.set("order", "scheduled_at.asc");

        const schedRes = await fetch(`${SUPABASE_URL}/rest/v1/pickup_schedules?${params}`, {
          headers: { "apikey": SUPABASE_KEY, "Authorization": `Bearer ${SUPABASE_KEY}` }
        });
        const text = await schedRes.text();
        return new Response(text, {
          status: schedRes.status,
          headers: { "Content-Type": "application/json", ...cors }
        });
      }
      // GET /restaurant/charity/:id  — single charity public profile

      // GET /restaurant/charity/:id — single charity public profile
// GET /restaurant/charity/:id — single charity public profile
      if (method === "GET" && path.startsWith("/restaurant/charity/")) {
            const cors = corsHeaders(request);
            const charityId = path.split("/restaurant/charity/")[1]?.trim();

            if (!charityId) {
                  return new Response(JSON.stringify({ error: "charity_id is required" }), {
                        status: 400,
                        headers: { "Content-Type": "application/json", ...cors }
                  });
            }

            const selectFields = "id,profile_id,name,description,address,charity_img_url,email,phone,website";

            // Try by charity table's own id first (no is_active filter — don't block inactive)
            const byIdRes = await fetch(
                  `${SUPABASE_URL}/rest/v1/charity?id=eq.${charityId}&select=${selectFields}&limit=1`,
                  { headers: { "apikey": SUPABASE_KEY, "Authorization": `Bearer ${SUPABASE_KEY}` } }
            );
            const byIdRows = await byIdRes.json();
            const byIdMatch = Array.isArray(byIdRows) ? byIdRows[0] : null;

            if (byIdMatch) {
                  return new Response(JSON.stringify(byIdMatch), {
                        status: 200,
                        headers: { "Content-Type": "application/json", ...cors }
                  });
            }

            // Fall back: the charityId passed is actually a profiles.id → match charity.profile_id
            const byProfileIdRes = await fetch(
                  `${SUPABASE_URL}/rest/v1/charity?profile_id=eq.${charityId}&select=${selectFields}&limit=1`,
                  { headers: { "apikey": SUPABASE_KEY, "Authorization": `Bearer ${SUPABASE_KEY}` } }
            );
            const byProfileIdRows = await byProfileIdRes.json();
            const byProfileIdMatch = Array.isArray(byProfileIdRows) ? byProfileIdRows[0] : null;

            if (byProfileIdMatch) {
                  return new Response(JSON.stringify(byProfileIdMatch), {
                        status: 200,
                        headers: { "Content-Type": "application/json", ...cors }
                  });
            }

            return new Response(JSON.stringify({ error: "CHARITY_NOT_FOUND" }), {
                  status: 404,
                  headers: { "Content-Type": "application/json", ...cors }
            });
      }
      }

    // Charity routes (charity-only)

    if (path.startsWith("/charity")) {
      const cors = corsHeaders(request);

      if (!profile || profile.role !== "charity") {
        return new Response(
          JSON.stringify({ error: "Only charities can access this route" }),
          { status: 403, headers: { "Content-Type": "application/json", ...cors } }
        );
      }

      const jsonBody = async () => {
        try { return await request.json(); } catch { return null; }
      };


// GET AVAILABLE DONATIONS
      if (method === "GET" && path === "/charity/donations/available") {
        const limitRaw = url.searchParams.get("limit");
        const offsetRaw = url.searchParams.get("offset");
        const cursorRaw = url.searchParams.get("cursor");

        const limitParsed = limitRaw && limitRaw.trim() !== "" ? Number(limitRaw) : 20;
        const offsetParsed = offsetRaw && offsetRaw.trim() !== "" ? Number(offsetRaw) : 0;
        const limit = Number.isFinite(limitParsed) ? Math.max(1, Math.min(50, Math.trunc(limitParsed))) : 20;
        const offset = Number.isFinite(offsetParsed) ? Math.max(0, Math.trunc(offsetParsed)) : 0;

        const params = new URLSearchParams();
        // ── Join restaurants to get restaurant_name ──
        params.set("select", "id,restaurant_id,created_at,donation_img_url,picked_up,is_available,description,pickup_location,restaurants!inner(name)");
        params.set("is_available", "eq.true");
        params.set("picked_up", "eq.pending");
        params.set("order", "created_at.desc,id.desc");
        params.set("limit", String(limit));

        if (cursorRaw && cursorRaw.trim() !== "") {
          let decoded = null;
          try { decoded = decodeURIComponent(cursorRaw); } catch { decoded = cursorRaw; }
          const parts = typeof decoded === "string" ? decoded.split("|") : [];
          const cursorCreatedAt = parts.length >= 1 && parts[0] ? parts[0] : null;
          const cursorId = parts.length >= 2 && parts[1] ? parts[1] : null;
          if (cursorCreatedAt && cursorId) {
            params.set("and", `(or(created_at.lt.${cursorCreatedAt},and(created_at.eq.${cursorCreatedAt},id.lt.${cursorId})))`);
          } else if (cursorCreatedAt) {
            params.set("created_at", `lt.${cursorCreatedAt}`);
          }
        } else {
          params.set("offset", String(offset));
        }

        const donationsRes = await fetch(`${SUPABASE_URL}/rest/v1/donations?${params.toString()}`, {
          headers: { "apikey": SUPABASE_KEY, "Authorization": `Bearer ${SUPABASE_KEY}` }
        });
        const rawText = await donationsRes.text();

        let nextCursor = "";
        let payloadText = rawText;

        if (donationsRes.ok) {
          try {
            const rows = JSON.parse(rawText);
            if (Array.isArray(rows)) {
              // Flatten restaurants join into restaurant_name field
              const mapped = rows.map((d) => {
                const { restaurants, ...rest } = d;
                return {
                  ...rest,
                  restaurant_name: restaurants?.name ?? null
                };
              });
              payloadText = JSON.stringify(mapped);
              if (mapped.length > 0) {
                const last = mapped[mapped.length - 1];
                const lastCreatedAt = last && typeof last.created_at === "string" ? last.created_at : null;
                const lastId = last && typeof last.id === "string" ? last.id : null;
                if (lastCreatedAt && lastId) nextCursor = `${lastCreatedAt}|${lastId}`;
              }
            }
          } catch { nextCursor = ""; payloadText = rawText; }
        }

        return new Response(payloadText, {
          status: donationsRes.status,
          headers: {
            "Content-Type": "application/json",
            ...cors,
            "X-Next-Offset": String(offset + limit),
            "X-Next-Cursor": nextCursor
          }
        });
      }
      
// GET DONATION ITEMS
      if (method === "GET" && path === "/charity/donation-items") {
        const donationId = (url.searchParams.get("donation_id") || "").trim();
        if (!donationId) {
          return new Response(JSON.stringify({ error: "donation_id is required" }), {
            status: 400,
            headers: { "Content-Type": "application/json", ...cors }
          });
        }

        const donationCheckRes = await fetch(
          `${SUPABASE_URL}/rest/v1/donations?id=eq.${donationId}&select=id,is_available,picked_up`,
          { headers: { "apikey": SUPABASE_KEY, "Authorization": `Bearer ${SUPABASE_KEY}` } }
        );
        if (!donationCheckRes.ok) {
          const t = await donationCheckRes.text();
          return new Response(t || "Donation lookup failed", {
            status: donationCheckRes.status,
            headers: { "Content-Type": "application/json", ...cors }
          });
        }
        const donationRows = await donationCheckRes.json();
        const donation = Array.isArray(donationRows) ? donationRows[0] : null;
        if (!donation || !donation.id) {
          return new Response(JSON.stringify({ error: "DONATION_NOT_FOUND" }), {
            status: 404,
            headers: { "Content-Type": "application/json", ...cors }
          });
        }
      const itemsRes = await fetch(
            `${SUPABASE_URL}/rest/v1/donation_items?donation_id=eq.${donationId}&select=id,item_name,description,donation_item_img,quantity,created_at`,
            {
                  headers: {
                        "apikey": SUPABASE_KEY,
                        "Authorization": `Bearer ${SUPABASE_KEY}`
                  }
            }
      );

        const itemsText = await itemsRes.text();
        return new Response(itemsText, {
              status: itemsRes.status,
              headers: { "Content-Type": "application/json", ...cors }
        });
      } 

      // REQUEST PICKUP  POST /charity/pickup/request

      if (method === "POST" && path === "/charity/pickup/request") {
        const body = await jsonBody();
      
        if (!body?.donation_id || typeof body.donation_id !== "string" || !body.donation_id.trim()) {
          return new Response(
            JSON.stringify({ error: "donation_id is required" }),
            { status: 400, headers: { "Content-Type": "application/json", ...cors } }
          );
        }
      
        const donationId = body.donation_id.trim();
      
        const donationCheckRes = await fetch(
          `${SUPABASE_URL}/rest/v1/donations?id=eq.${donationId}&select=id,is_available,picked_up,description,restaurant_id,restaurants!inner(profile_id,name)`,
          { headers: { "apikey": SUPABASE_KEY, "Authorization": `Bearer ${SUPABASE_KEY}` } }
        );
        if (!donationCheckRes.ok) {
          const t = await donationCheckRes.text();
          return new Response(t || "Donation lookup failed", {
            status: donationCheckRes.status, headers: { "Content-Type": "application/json", ...cors }
          });
        }
        const donationRows = await donationCheckRes.json();
        const donation = Array.isArray(donationRows) ? donationRows[0] : null;
        if (!donation || !donation.id) {
          return new Response(
            JSON.stringify({ error: "DONATION_NOT_FOUND" }),
            { status: 404, headers: { "Content-Type": "application/json", ...cors } }
          );
        }
        if (donation.is_available === false) {
          return new Response(
            JSON.stringify({ error: "DONATION_NOT_AVAILABLE" }),
            { status: 409, headers: { "Content-Type": "application/json", ...cors } }
          );
        }
        if (donation.picked_up !== "pending") {
          return new Response(
            JSON.stringify({ error: "DONATION_ALREADY_CLAIMED", picked_up: donation.picked_up }),
            { status: 409, headers: { "Content-Type": "application/json", ...cors } }
          );
        }
      
        const duplicateCheckRes = await fetch(
          `${SUPABASE_URL}/rest/v1/pickup_requests?donation_id=eq.${donationId}&charity_id=eq.${profile.profile_id}&status=eq.pending&select=id`,
          { headers: { "apikey": SUPABASE_KEY, "Authorization": `Bearer ${SUPABASE_KEY}` } }
        );
        if (!duplicateCheckRes.ok) {
          const t = await duplicateCheckRes.text();
          return new Response(t || "Duplicate check failed", {
            status: duplicateCheckRes.status, headers: { "Content-Type": "application/json", ...cors }
          });
        }
        const duplicateRows = await duplicateCheckRes.json();
        if (Array.isArray(duplicateRows) && duplicateRows.length > 0) {
          return new Response(
            JSON.stringify({ error: "PICKUP_REQUEST_ALREADY_PENDING" }),
            { status: 409, headers: { "Content-Type": "application/json", ...cors } }
          );
        }
      
        const insertRes = await fetch(`${SUPABASE_URL}/rest/v1/pickup_requests`, {
          method: "POST",
          headers: {
            "Content-Type":  "application/json",
            "apikey":        SUPABASE_KEY,
            "Authorization": `Bearer ${SUPABASE_KEY}`,
            "Prefer":        "return=representation"
          },
          body: JSON.stringify({
            donation_id: donationId,
            charity_id:  profile.profile_id,
            status:      "pending"
          })
        });
      
        const insertText = await insertRes.text();
      
        // ── Notify restaurant: new pickup request ──
        if (insertRes.ok && donation.restaurants?.profile_id) {
          const charityName  = profile.full_name || "A charity";
          const donationDesc = donation.description || "your donation";
          await notify(
            donation.restaurants.profile_id,
            "new_pickup_request",
            "New pickup request",
            `${charityName} has requested to pick up ${donationDesc}.`,
            "/admin/donations",
            { title: "New pickup request", body: `${charityName} wants to pick up ${donationDesc}.` }
          );
        }
      
        return new Response(insertText, {
          status: insertRes.status,
          headers: { "Content-Type": "application/json", ...cors }
        });
      }
      // CANCEL PICKUP REQUEST

      if (method === "POST" && path === "/charity/pickup/cancel") {
        const body = await jsonBody();

        if (!body?.pickup_id || typeof body.pickup_id !== "string" || !body.pickup_id.trim()) {
          return new Response(
            JSON.stringify({ error: "pickup_id is required" }),
            { status: 400, headers: { "Content-Type": "application/json", ...cors } }
          );
        }

        const pickupId = body.pickup_id.trim();

        const pickupCheckRes = await fetch(
          `${SUPABASE_URL}/rest/v1/pickup_requests?id=eq.${pickupId}&charity_id=eq.${profile.profile_id}&select=id,status,donation_id`,
          { headers: { "apikey": SUPABASE_KEY, "Authorization": `Bearer ${SUPABASE_KEY}` } }
        );
        if (!pickupCheckRes.ok) {
          const t = await pickupCheckRes.text();
          return new Response(t || "Pickup lookup failed", {
            status: pickupCheckRes.status,
            headers: { "Content-Type": "application/json", ...cors }
          });
        }
        const pickupRows = await pickupCheckRes.json();
        const pickup = Array.isArray(pickupRows) ? pickupRows[0] : null;
        if (!pickup || !pickup.id) {
          return new Response(
            JSON.stringify({ error: "PICKUP_REQUEST_NOT_FOUND" }),
            { status: 404, headers: { "Content-Type": "application/json", ...cors } }
          );
        }
        if (pickup.status !== "pending") {
          return new Response(
            JSON.stringify({ error: "PICKUP_NOT_PENDING", current_status: pickup.status }),
            { status: 409, headers: { "Content-Type": "application/json", ...cors } }
          );
        }

        const patchRes = await fetch(
          `${SUPABASE_URL}/rest/v1/pickup_requests?id=eq.${pickupId}&charity_id=eq.${profile.profile_id}`,
          {
            method: "PATCH",
            headers: {
              "Content-Type": "application/json",
              "apikey": SUPABASE_KEY,
              "Authorization": `Bearer ${SUPABASE_KEY}`,
              "Prefer": "return=representation"
            },
            body: JSON.stringify({ status: "rejected", updated_at: new Date().toISOString() })
          }
        );

        const donationRestoreRes = await fetch(
          `${SUPABASE_URL}/rest/v1/donations?id=eq.${pickup.donation_id}`,
          {
            method: "PATCH",
            headers: {
              "Content-Type": "application/json",
              "apikey": SUPABASE_KEY,
              "Authorization": `Bearer ${SUPABASE_KEY}`,
            },
            body: JSON.stringify({ is_available: true, picked_up: "pending" })
          }
        );
        if (!donationRestoreRes.ok) {
          console.error("Failed to restore donation availability", await donationRestoreRes.text());
        }

        const patchText = await patchRes.text();
        const patchStatus = patchRes.status === 204 ? 200 : patchRes.status;
        const patchBody = patchText && patchText.trim().length > 0 ? patchText : JSON.stringify({ cancelled: pickupId });
        return new Response(patchBody, {
          status: patchStatus,
          headers: { "Content-Type": "application/json", ...cors }
        });
      }

      // CONFIRM PICKUP  POST /charity/pickup/confirm
  
if (method === "POST" && path === "/charity/pickup/confirm") {
        const body = await jsonBody();
      
        if (!body?.pickup_id || typeof body.pickup_id !== "string" || !body.pickup_id.trim()) {
          return new Response(
            JSON.stringify({ error: "pickup_id is required" }),
            { status: 400, headers: { "Content-Type": "application/json", ...cors } }
          );
        }
      
        const pickupId = body.pickup_id.trim();
      
        const pickupCheckRes = await fetch(
          `${SUPABASE_URL}/rest/v1/pickup_requests?id=eq.${pickupId}&charity_id=eq.${profile.profile_id}&select=id,status,donation_id,donations!inner(restaurant_id,description,restaurants!inner(profile_id,name))`,
          { headers: { "apikey": SUPABASE_KEY, "Authorization": `Bearer ${SUPABASE_KEY}` } }
        );
        if (!pickupCheckRes.ok) {
          const t = await pickupCheckRes.text();
          return new Response(t || "Pickup lookup failed", {
            status: pickupCheckRes.status, headers: { "Content-Type": "application/json", ...cors }
          });
        }
        const pickupRows = await pickupCheckRes.json();
        const pickup = Array.isArray(pickupRows) ? pickupRows[0] : null;
        if (!pickup || !pickup.id) {
          return new Response(
            JSON.stringify({ error: "PICKUP_REQUEST_NOT_FOUND" }),
            { status: 404, headers: { "Content-Type": "application/json", ...cors } }
          );
        }
        if (pickup.status !== "approved") {
          return new Response(
            JSON.stringify({ error: "PICKUP_NOT_APPROVED", current_status: pickup.status }),
            { status: 409, headers: { "Content-Type": "application/json", ...cors } }
          );
        }
      
        const donationPatchRes = await fetch(
          `${SUPABASE_URL}/rest/v1/donations?id=eq.${pickup.donation_id}`,
          {
            method: "PATCH",
            headers: {
              "Content-Type":  "application/json",
              "apikey":        SUPABASE_KEY,
              "Authorization": `Bearer ${SUPABASE_KEY}`,
              "Prefer":        "return=representation"
            },
            body: JSON.stringify({ picked_up: "picked_up", is_available: false })
          }
        );
        if (!donationPatchRes.ok) {
          const t = await donationPatchRes.text();
          return new Response(t || "Failed to update donation", {
            status: donationPatchRes.status, headers: { "Content-Type": "application/json", ...cors }
          });
        }
      
        const pickupPatchRes = await fetch(
          `${SUPABASE_URL}/rest/v1/pickup_requests?id=eq.${pickupId}&charity_id=eq.${profile.profile_id}`,
          {
            method: "PATCH",
            headers: {
              "Content-Type":  "application/json",
              "apikey":        SUPABASE_KEY,
              "Authorization": `Bearer ${SUPABASE_KEY}`,
              "Prefer":        "return=representation"
            },
            body: JSON.stringify({ status: "picked_up", updated_at: new Date().toISOString() })
          }
        );
        if (!pickupPatchRes.ok) {
          const t = await pickupPatchRes.text();
          return new Response(t || "Failed to update pickup request", {
            status: pickupPatchRes.status, headers: { "Content-Type": "application/json", ...cors }
          });
        }
      
        // ── Notify restaurant: donation was picked up ──
        const restaurantProfileId = pickup.donations?.restaurants?.profile_id;
        if (restaurantProfileId) {
          const charityName  = profile.full_name || "A charity";
          const donationDesc = pickup.donations?.description || "your donation";
          await notify(
            restaurantProfileId,
            "pickup_confirmed",
            "Donation picked up ✓",
            `${charityName} has confirmed they picked up ${donationDesc}.`,
            "/admin/donations",
            { title: "Donation picked up ✓", body: `${charityName} confirmed the pickup.` }
          );
        }
      
        const pickupPatchText = await pickupPatchRes.text();
        const responseBody = pickupPatchText && pickupPatchText.trim().length > 0
          ? pickupPatchText
          : JSON.stringify({ confirmed: pickupId });
      
        return new Response(responseBody, {
          status:  200,
          headers: { "Content-Type": "application/json", ...cors }
        });
      }


      // CHARITY HISTORY
      if (method === "GET" && path === "/charity/history") {
        const limitRaw = url.searchParams.get("limit");
        const offsetRaw = url.searchParams.get("offset");
        const cursorRaw = url.searchParams.get("cursor");
        const time = (url.searchParams.get("time") || "all").toLowerCase();
        const fromRaw = url.searchParams.get("from");
        const toRaw = url.searchParams.get("to");
        const statusRaw = url.searchParams.get("status");
        const tzOffsetRaw = url.searchParams.get("tz_offset_minutes");

        const limitParsed = limitRaw && limitRaw.trim() !== "" ? Number(limitRaw) : 20;
        const offsetParsed = offsetRaw && offsetRaw.trim() !== "" ? Number(offsetRaw) : 0;
        const limit = Number.isFinite(limitParsed) ? Math.max(1, Math.min(50, Math.trunc(limitParsed))) : 20;
        const offset = Number.isFinite(offsetParsed) ? Math.max(0, Math.trunc(offsetParsed)) : 0;

        const tzOffsetMinutesParsed = tzOffsetRaw && tzOffsetRaw.trim() !== "" ? Number(tzOffsetRaw) : null;
        const tzOffsetMinutes = Number.isFinite(tzOffsetMinutesParsed)
          ? Math.max(-840, Math.min(840, Math.trunc(tzOffsetMinutesParsed)))
          : null;

        const parseIso = (v) => {
          if (!v || typeof v !== "string" || !v.trim()) return null;
          const d = new Date(v);
          return Number.isFinite(d.getTime()) ? d.toISOString() : null;
        };

        const now = new Date();

        const computeStartOfDayIso = () => {
          if (tzOffsetMinutes == null) {
            const d = new Date(now); d.setUTCHours(0, 0, 0, 0); return d.toISOString();
          }
          const localMs = now.getTime() - tzOffsetMinutes * 60_000;
          const local = new Date(localMs); local.setUTCHours(0, 0, 0, 0);
          return new Date(local.getTime() + tzOffsetMinutes * 60_000).toISOString();
        };

        const computeStartOfWeekIso = () => {
          if (tzOffsetMinutes == null) {
            const d = new Date(now);
            d.setUTCDate(d.getUTCDate() - (d.getUTCDay() + 6) % 7);
            d.setUTCHours(0, 0, 0, 0); return d.toISOString();
          }
          const localMs = now.getTime() - tzOffsetMinutes * 60_000;
          const local = new Date(localMs);
          local.setUTCDate(local.getUTCDate() - (local.getUTCDay() + 6) % 7);
          local.setUTCHours(0, 0, 0, 0);
          return new Date(local.getTime() + tzOffsetMinutes * 60_000).toISOString();
        };

        const fromIso = time === "today" ? computeStartOfDayIso()
          : (time === "week" || time === "thisweek" || time === "this_week") ? computeStartOfWeekIso()
          : parseIso(fromRaw);
        const toIso = parseIso(toRaw);

        const params = new URLSearchParams();
        params.set("select", "id,status,created_at,updated_at,donation_id,donations(id,restaurant_id,donation_img_url,picked_up,is_available,description,pickup_location)");
        params.set("charity_id", `eq.${profile.profile_id}`);
        params.set("order", "created_at.desc,id.desc");
        params.set("limit", String(limit));

        const allowedStatuses = new Set(["pending", "approved", "rejected"]);
        if (statusRaw && statusRaw.trim() !== "" && allowedStatuses.has(statusRaw.trim())) {
          params.set("status", `eq.${statusRaw.trim()}`);
        }

        if (fromIso) params.set("created_at", `gte.${fromIso}`);
        if (toIso) {
          const existing = params.get("created_at");
          params.set("created_at", existing ? `${existing},lte.${toIso}` : `lte.${toIso}`);
        }

        if (cursorRaw && cursorRaw.trim() !== "") {
          let decoded = null;
          try { decoded = decodeURIComponent(cursorRaw); } catch { decoded = cursorRaw; }
          const parts = typeof decoded === "string" ? decoded.split("|") : [];
          const cursorCreatedAt = parts.length >= 1 && parts[0] ? parts[0] : null;
          const cursorId = parts.length >= 2 && parts[1] ? parts[1] : null;
          if (cursorCreatedAt && cursorId) {
            params.set("and", `(or(created_at.lt.${cursorCreatedAt},and(created_at.eq.${cursorCreatedAt},id.lt.${cursorId})))`);
          } else if (cursorCreatedAt) {
            const existing = params.get("created_at");
            params.set("created_at", existing ? `${existing},lt.${cursorCreatedAt}` : `lt.${cursorCreatedAt}`);
          }
        } else {
          params.set("offset", String(offset));
        }

        const historyRes = await fetch(`${SUPABASE_URL}/rest/v1/pickup_requests?${params.toString()}`, {
          headers: { "apikey": SUPABASE_KEY, "Authorization": `Bearer ${SUPABASE_KEY}` }
        });
        const rawText = await historyRes.text();

        let nextCursor = "";
        let payloadText = rawText;

        if (historyRes.ok) {
          try {
            const rows = JSON.parse(rawText);
            if (Array.isArray(rows)) {
              const mapped = rows.map((r) => {
                const d = r.donations ?? null;
                const { donations, ...rest } = r;
                return {
                  ...rest,
                  donation_id:      r.donation_id ?? null,
                  donation_img_url: d?.donation_img_url ?? null,
                  restaurant_id:    d?.restaurant_id ?? null,
                  picked_up:        d?.picked_up ?? null,
                  is_available:     d?.is_available ?? null,
                  description:      d?.description ?? null,
                  pickup_location:  d?.pickup_location ?? null
                };
              });
              payloadText = JSON.stringify(mapped);
              if (mapped.length > 0) {
                const last = mapped[mapped.length - 1];
                const lastCreatedAt = last && typeof last.created_at === "string" ? last.created_at : null;
                const lastId = last && typeof last.id === "string" ? last.id : null;
                if (lastCreatedAt && lastId) nextCursor = `${lastCreatedAt}|${lastId}`;
              }
            }
          } catch { nextCursor = ""; payloadText = rawText; }
        }

        return new Response(payloadText, {
          status: historyRes.status,
          headers: {
            "Content-Type": "application/json",
            ...cors,
            "X-Next-Offset": String(offset + limit),
            "X-Next-Cursor": nextCursor
          }
        });
      }

// CONFIRM SCHEDULE  POST /charity/pickup/schedule/confirm
      if (method === "POST" && path === "/charity/pickup/schedule/confirm") {
        const cors = corsHeaders(request);
        const body = await jsonBody();
        const scheduleId = body && typeof body.schedule_id === "string" ? body.schedule_id.trim() : "";
        if (!scheduleId) {
          return new Response(JSON.stringify({ error: "schedule_id is required" }), {
            status: 400, headers: { "Content-Type": "application/json", ...cors }
          });
        }
        return callRPC("confirm_schedule", {
          p_profile_id:  profile.profile_id,
          p_schedule_id: scheduleId
        }, request);
      }

      // CANCEL SCHEDULE  POST /charity/pickup/schedule/cancel
      if (method === "POST" && path === "/charity/pickup/schedule/cancel") {
        const cors = corsHeaders(request);
        const body = await jsonBody();
        const scheduleId = body && typeof body.schedule_id === "string" ? body.schedule_id.trim() : "";
        if (!scheduleId) {
          return new Response(JSON.stringify({ error: "schedule_id is required" }), {
            status: 400, headers: { "Content-Type": "application/json", ...cors }
          });
        }
        return callRPC("cancel_schedule", {
          p_profile_id:  profile.profile_id,
          p_schedule_id: scheduleId
        }, request);
      }

      // GET SCHEDULES  GET /charity/schedules
      if (method === "GET" && path === "/charity/schedules") {
        const cors = corsHeaders(request);
        const params = new URLSearchParams();
        params.set("select",
          "id,scheduled_at,notes,status,confirmed_at,created_at,updated_at," +
          "pickup_requests!inner(id,donation_id," +
          "donations!inner(id,donation_img_url,description,pickup_location," +
          "restaurants!inner(name)))"
        );
        params.set("pickup_requests.charity_id", `eq.${profile.profile_id}`);
        params.set("status", "in.(pending,confirmed)");
        params.set("order", "scheduled_at.asc");

        const schedRes = await fetch(`${SUPABASE_URL}/rest/v1/pickup_schedules?${params}`, {
          headers: { "apikey": SUPABASE_KEY, "Authorization": `Bearer ${SUPABASE_KEY}` }
        });
        const text = await schedRes.text();
        return new Response(text, {
          status: schedRes.status,
          headers: { "Content-Type": "application/json", ...cors }
        });
      }

// GET APPROVED PICKUPS  GET /charity/pickups/approved
      if (method === "GET" && path === "/charity/pickups/approved") {
        const limitRaw  = url.searchParams.get("limit");
        const offsetRaw = url.searchParams.get("offset");
        const cursorRaw = url.searchParams.get("cursor");

        const limitParsed  = limitRaw  && limitRaw.trim()  !== "" ? Number(limitRaw)  : 20;
        const offsetParsed = offsetRaw && offsetRaw.trim() !== "" ? Number(offsetRaw) : 0;
        const limit  = Number.isFinite(limitParsed)  ? Math.max(1, Math.min(50, Math.trunc(limitParsed)))  : 20;
        const offset = Number.isFinite(offsetParsed) ? Math.max(0, Math.trunc(offsetParsed)) : 0;

        const params = new URLSearchParams();
        params.set("select", "id,status,created_at,updated_at,donation_id,donations(id,restaurant_id,donation_img_url,picked_up,is_available,description,pickup_location,restaurants!inner(name))");
        params.set("charity_id", `eq.${profile.profile_id}`);
        params.set("status", "eq.approved");
        params.set("order", "created_at.desc,id.desc");
        params.set("limit", String(limit));

        if (cursorRaw && cursorRaw.trim() !== "") {
          let decoded = null;
          try { decoded = decodeURIComponent(cursorRaw); } catch { decoded = cursorRaw; }
          const parts = typeof decoded === "string" ? decoded.split("|") : [];
          const cursorCreatedAt = parts.length >= 1 && parts[0] ? parts[0] : null;
          const cursorId        = parts.length >= 2 && parts[1] ? parts[1] : null;
          if (cursorCreatedAt && cursorId) {
            params.set("and", `(or(created_at.lt.${cursorCreatedAt},and(created_at.eq.${cursorCreatedAt},id.lt.${cursorId})))`);
          } else if (cursorCreatedAt) {
            params.set("created_at", `lt.${cursorCreatedAt}`);
          }
        } else {
          params.set("offset", String(offset));
        }

        const res     = await fetch(`${SUPABASE_URL}/rest/v1/pickup_requests?${params.toString()}`, {
          headers: { "apikey": SUPABASE_KEY, "Authorization": `Bearer ${SUPABASE_KEY}` }
        });
        const rawText = await res.text();

        let nextCursor  = "";
        let payloadText = rawText;

        if (res.ok) {
          try {
            const rows = JSON.parse(rawText);
            if (Array.isArray(rows)) {
              const mapped = rows.map((r) => {
                const d = r.donations ?? null;
                const { donations, ...rest } = r;
                return {
                  ...rest,
                  donation_id:      r.donation_id      ?? null,
                  donation_img_url: d?.donation_img_url ?? null,
                  restaurant_id:    d?.restaurant_id    ?? null,
                  restaurant_name:  d?.restaurants?.name ?? null,
                  picked_up:        d?.picked_up        ?? null,
                  is_available:     d?.is_available     ?? null,
                  description:      d?.description      ?? null,
                  pickup_location:  d?.pickup_location  ?? null
                };
              });
              payloadText = JSON.stringify(mapped);
              if (mapped.length > 0) {
                const last = mapped[mapped.length - 1];
                const lastCreatedAt = last && typeof last.created_at === "string" ? last.created_at : null;
                const lastId        = last && typeof last.id          === "string" ? last.id          : null;
                if (lastCreatedAt && lastId) nextCursor = `${lastCreatedAt}|${lastId}`;
              }
            }
          } catch { nextCursor = ""; payloadText = rawText; }
        }

        return new Response(payloadText, {
          status: res.status,
          headers: {
            "Content-Type":   "application/json",
            ...cors,
            "X-Next-Offset":  String(offset + limit),
            "X-Next-Cursor":  nextCursor
          }
        });
      }

      // GET PICKED-UP DONATIONS  GET /charity/pickups/picked-up
      if (method === "GET" && path === "/charity/pickups/picked-up") {
        const limitRaw  = url.searchParams.get("limit");
        const offsetRaw = url.searchParams.get("offset");
        const cursorRaw = url.searchParams.get("cursor");

        const limitParsed  = limitRaw  && limitRaw.trim()  !== "" ? Number(limitRaw)  : 20;
        const offsetParsed = offsetRaw && offsetRaw.trim() !== "" ? Number(offsetRaw) : 0;
        const limit  = Number.isFinite(limitParsed)  ? Math.max(1, Math.min(50, Math.trunc(limitParsed)))  : 20;
        const offset = Number.isFinite(offsetParsed) ? Math.max(0, Math.trunc(offsetParsed)) : 0;

        // We join donations and filter on picked_up = 'picked_up' via the embedded resource
        const params = new URLSearchParams();
        params.set("select", "id,status,created_at,updated_at,donation_id,donations!inner(id,restaurant_id,donation_img_url,picked_up,is_available,description,pickup_location,restaurants!inner(name))");
        params.set("charity_id",         `eq.${profile.profile_id}`);
        params.set("donations.picked_up", "eq.picked_up");
        params.set("order", "created_at.desc,id.desc");
        params.set("limit", String(limit));

        if (cursorRaw && cursorRaw.trim() !== "") {
          let decoded = null;
          try { decoded = decodeURIComponent(cursorRaw); } catch { decoded = cursorRaw; }
          const parts = typeof decoded === "string" ? decoded.split("|") : [];
          const cursorCreatedAt = parts.length >= 1 && parts[0] ? parts[0] : null;
          const cursorId        = parts.length >= 2 && parts[1] ? parts[1] : null;
          if (cursorCreatedAt && cursorId) {
            params.set("and", `(or(created_at.lt.${cursorCreatedAt},and(created_at.eq.${cursorCreatedAt},id.lt.${cursorId})))`);
          } else if (cursorCreatedAt) {
            params.set("created_at", `lt.${cursorCreatedAt}`);
          }
        } else {
          params.set("offset", String(offset));
        }

        const res     = await fetch(`${SUPABASE_URL}/rest/v1/pickup_requests?${params.toString()}`, {
          headers: { "apikey": SUPABASE_KEY, "Authorization": `Bearer ${SUPABASE_KEY}` }
        });
        const rawText = await res.text();

        let nextCursor  = "";
        let payloadText = rawText;

        if (res.ok) {
          try {
            const rows = JSON.parse(rawText);
            if (Array.isArray(rows)) {
              const mapped = rows.map((r) => {
                const d = r.donations ?? null;
                const { donations, ...rest } = r;
                return {
                  ...rest,
                  donation_id:      r.donation_id      ?? null,
                  donation_img_url: d?.donation_img_url ?? null,
                  restaurant_id:    d?.restaurant_id    ?? null,
                  restaurant_name:  d?.restaurants?.name ?? null,
                  picked_up:        d?.picked_up        ?? null,
                  is_available:     d?.is_available     ?? null,
                  description:      d?.description      ?? null,
                  pickup_location:  d?.pickup_location  ?? null
                };
              });
              payloadText = JSON.stringify(mapped);
              if (mapped.length > 0) {
                const last = mapped[mapped.length - 1];
                const lastCreatedAt = last && typeof last.created_at === "string" ? last.created_at : null;
                const lastId        = last && typeof last.id          === "string" ? last.id          : null;
                if (lastCreatedAt && lastId) nextCursor = `${lastCreatedAt}|${lastId}`;
              }
            }
          } catch { nextCursor = ""; payloadText = rawText; }
        }

        return new Response(payloadText, {
          status: res.status,
          headers: {
            "Content-Type":   "application/json",
            ...cors,
            "X-Next-Offset":  String(offset + limit),
            "X-Next-Cursor":  nextCursor
          }
        });
      }

      // GET REJECTED PICKUPS  GET /charity/pickups/rejected
      if (method === "GET" && path === "/charity/pickups/rejected") {
        const limitRaw  = url.searchParams.get("limit");
        const offsetRaw = url.searchParams.get("offset");
        const cursorRaw = url.searchParams.get("cursor");

        const limitParsed  = limitRaw  && limitRaw.trim()  !== "" ? Number(limitRaw)  : 20;
        const offsetParsed = offsetRaw && offsetRaw.trim() !== "" ? Number(offsetRaw) : 0;
        const limit  = Number.isFinite(limitParsed)  ? Math.max(1, Math.min(50, Math.trunc(limitParsed)))  : 20;
        const offset = Number.isFinite(offsetParsed) ? Math.max(0, Math.trunc(offsetParsed)) : 0;

        const params = new URLSearchParams();
        params.set("select", "id,status,created_at,updated_at,donation_id,donations(id,restaurant_id,donation_img_url,picked_up,is_available,description,pickup_location,restaurants!inner(name))");
        params.set("charity_id", `eq.${profile.profile_id}`);
        params.set("status", "eq.rejected");
        params.set("order", "created_at.desc,id.desc");
        params.set("limit", String(limit));

        if (cursorRaw && cursorRaw.trim() !== "") {
          let decoded = null;
          try { decoded = decodeURIComponent(cursorRaw); } catch { decoded = cursorRaw; }
          const parts = typeof decoded === "string" ? decoded.split("|") : [];
          const cursorCreatedAt = parts.length >= 1 && parts[0] ? parts[0] : null;
          const cursorId        = parts.length >= 2 && parts[1] ? parts[1] : null;
          if (cursorCreatedAt && cursorId) {
            params.set("and", `(or(created_at.lt.${cursorCreatedAt},and(created_at.eq.${cursorCreatedAt},id.lt.${cursorId})))`);
          } else if (cursorCreatedAt) {
            params.set("created_at", `lt.${cursorCreatedAt}`);
          }
        } else {
          params.set("offset", String(offset));
        }

        const res     = await fetch(`${SUPABASE_URL}/rest/v1/pickup_requests?${params.toString()}`, {
          headers: { "apikey": SUPABASE_KEY, "Authorization": `Bearer ${SUPABASE_KEY}` }
        });
        const rawText = await res.text();

        let nextCursor  = "";
        let payloadText = rawText;

        if (res.ok) {
          try {
            const rows = JSON.parse(rawText);
            if (Array.isArray(rows)) {
              const mapped = rows.map((r) => {
                const d = r.donations ?? null;
                const { donations, ...rest } = r;
                return {
                  ...rest,
                  donation_id:      r.donation_id      ?? null,
                  donation_img_url: d?.donation_img_url ?? null,
                  restaurant_id:    d?.restaurant_id    ?? null,
                  restaurant_name:  d?.restaurants?.name ?? null,
                  picked_up:        d?.picked_up        ?? null,
                  is_available:     d?.is_available     ?? null,
                  description:      d?.description      ?? null,
                  pickup_location:  d?.pickup_location  ?? null
                };
              });
              payloadText = JSON.stringify(mapped);
              if (mapped.length > 0) {
                const last = mapped[mapped.length - 1];
                const lastCreatedAt = last && typeof last.created_at === "string" ? last.created_at : null;
                const lastId        = last && typeof last.id          === "string" ? last.id          : null;
                if (lastCreatedAt && lastId) nextCursor = `${lastCreatedAt}|${lastId}`;
              }
            }
          } catch { nextCursor = ""; payloadText = rawText; }
        }

        return new Response(payloadText, {
          status: res.status,
          headers: {
            "Content-Type":   "application/json",
            ...cors,
            "X-Next-Offset":  String(offset + limit),
            "X-Next-Cursor":  nextCursor
          }
        });
      }
// GET ALL PICKUP REQUESTS  GET /charity/pickups/all
      if (method === "GET" && path === "/charity/pickups/all") {
            const limitRaw  = url.searchParams.get("limit");
            const offsetRaw = url.searchParams.get("offset");
            const cursorRaw = url.searchParams.get("cursor");

            const limitParsed  = limitRaw  && limitRaw.trim()  !== "" ? Number(limitRaw)  : 20;
            const offsetParsed = offsetRaw && offsetRaw.trim() !== "" ? Number(offsetRaw) : 0;
            const limit  = Number.isFinite(limitParsed)  ? Math.max(1, Math.min(50, Math.trunc(limitParsed)))  : 20;
            const offset = Number.isFinite(offsetParsed) ? Math.max(0, Math.trunc(offsetParsed)) : 0;

            const params = new URLSearchParams();
            params.set("select", "id,status,created_at,updated_at,donation_id,donations(id,restaurant_id,donation_img_url,picked_up,is_available,description,pickup_location,restaurants!inner(name))");
            params.set("charity_id", `eq.${profile.profile_id}`);
            params.set("order", "created_at.desc,id.desc");
            params.set("limit", String(limit));

            if (cursorRaw && cursorRaw.trim() !== "") {
                  let decoded = null;
                  try { decoded = decodeURIComponent(cursorRaw); } catch { decoded = cursorRaw; }
                  const parts = typeof decoded === "string" ? decoded.split("|") : [];
                  const cursorCreatedAt = parts.length >= 1 && parts[0] ? parts[0] : null;
                  const cursorId        = parts.length >= 2 && parts[1] ? parts[1] : null;
                  if (cursorCreatedAt && cursorId) {
                        params.set("and", `(or(created_at.lt.${cursorCreatedAt},and(created_at.eq.${cursorCreatedAt},id.lt.${cursorId})))`);
                  } else if (cursorCreatedAt) {
                        params.set("created_at", `lt.${cursorCreatedAt}`);
                  }
            } else {
                  params.set("offset", String(offset));
            }

            const res     = await fetch(`${SUPABASE_URL}/rest/v1/pickup_requests?${params.toString()}`, {
                  headers: { "apikey": SUPABASE_KEY, "Authorization": `Bearer ${SUPABASE_KEY}` }
            });
            const rawText = await res.text();

            let nextCursor  = "";
            let payloadText = rawText;

            if (res.ok) {
                  try {
                        const rows = JSON.parse(rawText);
                        if (Array.isArray(rows)) {
                              const mapped = rows.map((r) => {
                                    const d = r.donations ?? null;
                                    const { donations, ...rest } = r;
                                    return {
                                          ...rest,
                                          donation_id:      r.donation_id       ?? null,
                                          donation_img_url: d?.donation_img_url  ?? null,
                                          restaurant_id:    d?.restaurant_id     ?? null,
                                          restaurant_name:  d?.restaurants?.name ?? null,
                                          picked_up:        d?.picked_up         ?? null,
                                          is_available:     d?.is_available      ?? null,
                                          description:      d?.description       ?? null,
                                          pickup_location:  d?.pickup_location   ?? null
                                    };
                              });
                              payloadText = JSON.stringify(mapped);
                              if (mapped.length > 0) {
                                    const last = mapped[mapped.length - 1];
                                    const lastCreatedAt = last && typeof last.created_at === "string" ? last.created_at : null;
                                    const lastId        = last && typeof last.id          === "string" ? last.id          : null;
                                    if (lastCreatedAt && lastId) nextCursor = `${lastCreatedAt}|${lastId}`;
                              }
                        }
                  } catch { nextCursor = ""; payloadText = rawText; }
            }

            return new Response(payloadText, {
                  status: res.status,
                  headers: {
                        "Content-Type":  "application/json",
                        ...cors,
                        "X-Next-Offset": String(offset + limit),
                        "X-Next-Cursor": nextCursor
                  }
            });
      }

      // GET /charity/profile
      if (method === "GET" && path === "/charity/profile") {
            const res = await fetch(
                  `${SUPABASE_URL}/rest/v1/charity?profile_id=eq.${profile.profile_id}&select=*`,
                  { headers: { "apikey": SUPABASE_KEY, "Authorization": `Bearer ${SUPABASE_KEY}` } }
            );
            const rows = await res.json();
            const charityRow = Array.isArray(rows) ? rows[0] : null;

            return new Response(JSON.stringify({
                  id:          profile.profile_id,
                  name:        charityRow?.name             ?? profile.full_name ?? null,
                  email:       charityRow?.email            ?? profile.email     ?? null,
                  phone:       charityRow?.phone            ?? null,
                  website:     charityRow?.website          ?? null,
                  address:     charityRow?.address          ?? null,
                  description: charityRow?.description      ?? null,
                  logo_url:    charityRow?.charity_img_url  ?? null,
                  created_at:  charityRow?.created_at       ?? null,
                  updated_at:  charityRow?.updated_at       ?? null,
            }), {
                  status: 200,
                  headers: { "Content-Type": "application/json", ...cors }
            });
      }


      // POST /charity/profile/update
      if (method === "POST" && path === "/charity/profile/update") {
            const body = await jsonBody();

            if (!body || typeof body !== "object") {
                  return new Response(JSON.stringify({ error: "Invalid or missing JSON body" }), {
                        status: 400,
                        headers: { "Content-Type": "application/json", ...cors }
                  });
            }

            // Update profiles table (full_name, email)
            if (body?.full_name || body?.email) {
                  const profilePatchRes = await fetch(
                        `${SUPABASE_URL}/rest/v1/profiles?id=eq.${profile.profile_id}`,
                        {
                              method: "PATCH",
                              headers: {
                                    "Content-Type": "application/json",
                                    "apikey": SUPABASE_KEY,
                                    "Authorization": `Bearer ${SUPABASE_KEY}`,
                                    "Prefer": "return=minimal"
                              },
                              body: JSON.stringify({
                                    ...(body.full_name ? { full_name: body.full_name } : {}),
                                    ...(body.email     ? { email: body.email }         : {})
                              })
                        }
                  );

                  if (!profilePatchRes.ok) {
                        const errText = await profilePatchRes.text();
                        return new Response(JSON.stringify({ error: "Profile update failed", detail: errText }), {
                              status: profilePatchRes.status,
                              headers: { "Content-Type": "application/json", ...cors }
                        });
                  }
            }

            // Update charity table
            const charityUpdate = {};
            if (body?.email)            charityUpdate.email            = body.email;
            if (body?.name)             charityUpdate.name             = body.name;
            if (body?.description)      charityUpdate.description      = body.description;
            if (body?.address)          charityUpdate.address          = body.address;
            if (body?.phone)            charityUpdate.phone            = body.phone;
            if (body?.website)          charityUpdate.website          = body.website;
            if (body?.charity_img_url)  charityUpdate.charity_img_url  = body.charity_img_url;

            if (Object.keys(charityUpdate).length > 0) {
                  const charityPatchRes = await fetch(
                        `${SUPABASE_URL}/rest/v1/charity?profile_id=eq.${profile.profile_id}`,
                        {
                              method: "PATCH",
                              headers: {
                                    "Content-Type": "application/json",
                                    "apikey": SUPABASE_KEY,
                                    "Authorization": `Bearer ${SUPABASE_KEY}`,
                                    "Prefer": "return=minimal"
                              },
                              body: JSON.stringify(charityUpdate)
                        }
                  );

                  if (!charityPatchRes.ok) {
                        const errText = await charityPatchRes.text();
                        return new Response(JSON.stringify({ error: "Charity update failed", detail: errText }), {
                              status: charityPatchRes.status,
                              headers: { "Content-Type": "application/json", ...cors }
                        });
                  }
            }

            return new Response(JSON.stringify({ ok: true }), {
                  status: 200,
                  headers: { "Content-Type": "application/json", ...cors }
            });
      }
      
      // ── CHARITY: GET /charity/search/restaurants ───────────────────
      // Query params: ?q=name&available_only=true
      if (method === "GET" && path === "/charity/search/restaurants") {
            if (profile.role !== "charity") {
                  return new Response(JSON.stringify({ error: "Forbidden" }), {
                        status: 403,
                        headers: { "Content-Type": "application/json", ...cors }
                  });
            }

            const url       = new URL(request.url);
            const q         = url.searchParams.get("q") || "";
            const availOnly = url.searchParams.get("available_only") === "true";

            let restFilter = `is_active=eq.true`;
            if (q) restFilter += `&name=ilike.*${encodeURIComponent(q)}*`;

            const restRes = await fetch(
                  `${SUPABASE_URL}/rest/v1/restaurants?${restFilter}&select=id,name,description,address,rest_img_url,img_url,accepting_orders`,
                  { headers: { "apikey": SUPABASE_KEY, "Authorization": `Bearer ${SUPABASE_KEY}` } }
            );
            const restaurants = await restRes.json();

            if (!Array.isArray(restaurants) || restaurants.length === 0) {
                  return new Response(JSON.stringify([]), {
                        status: 200,
                        headers: { "Content-Type": "application/json", ...cors }
                  });
            }

            const ids = restaurants.map(r => r.id);
            let donationFilter = `restaurant_id=in.(${ids.join(",")})&is_available=eq.true`;
            if (availOnly) donationFilter += `&picked_up=eq.pending`;

            const donRes = await fetch(
                  `${SUPABASE_URL}/rest/v1/donations?${donationFilter}&select=id,restaurant_id,description,donation_img_url,pickup_location,picked_up`,
                  { headers: { "apikey": SUPABASE_KEY, "Authorization": `Bearer ${SUPABASE_KEY}` } }
            );
            const donations = await donRes.json();

            const donMap = {};
            if (Array.isArray(donations)) {
                  for (const d of donations) {
                        if (!donMap[d.restaurant_id]) donMap[d.restaurant_id] = [];
                        donMap[d.restaurant_id].push(d);
                  }
            }

            const result = restaurants.map(r => ({
                  ...r,
                  donations: donMap[r.id] || []
            }));

            return new Response(JSON.stringify(result), {
                  status: 200,
                  headers: { "Content-Type": "application/json", ...cors }
            });
      }
            // GET /charity/restaurants/:id  — single restaurant profile + available donations
      if (method === "GET" && path.startsWith("/charity/restaurants/")) {
            const restaurantId = path.split("/charity/restaurants/")[1]?.trim();

            if (!restaurantId) {
                  return new Response(JSON.stringify({ error: "restaurant_id is required" }), {
                        status: 400,
                        headers: { "Content-Type": "application/json", ...cors }
                  });
            }

            // Fetch restaurant
            const restRes = await fetch(
                  `${SUPABASE_URL}/rest/v1/restaurants?id=eq.${restaurantId}&is_active=eq.true&select=id,name,description,address,rest_img_url,img_url,accepting_orders`,
                  { headers: { "apikey": SUPABASE_KEY, "Authorization": `Bearer ${SUPABASE_KEY}` } }
            );
            const restRows = await restRes.json();
            const restaurant = Array.isArray(restRows) ? restRows[0] : null;

            if (!restaurant) {
                  return new Response(JSON.stringify({ error: "RESTAURANT_NOT_FOUND" }), {
                        status: 404,
                        headers: { "Content-Type": "application/json", ...cors }
                  });
            }

            // Fetch its available donations
            const donRes = await fetch(
                  `${SUPABASE_URL}/rest/v1/donations?restaurant_id=eq.${restaurantId}&is_available=eq.true&picked_up=eq.pending&select=id,description,donation_img_url,pickup_location,picked_up,created_at&order=created_at.desc`,
                  { headers: { "apikey": SUPABASE_KEY, "Authorization": `Bearer ${SUPABASE_KEY}` } }
            );
            const donations = await donRes.json();

            return new Response(JSON.stringify({
                  ...restaurant,
                  donations: Array.isArray(donations) ? donations : []
            }), {
                  status: 200,
                  headers: { "Content-Type": "application/json", ...cors }
            });
      }
      
      // GET /charity/stats
      if (method === "GET" && path === "/charity/stats") {
        const res = await fetch(
          `${SUPABASE_URL}/rest/v1/pickup_requests?charity_id=eq.${profile.profile_id}&select=id,status,donations(picked_up)`,
          { headers: { "apikey": SUPABASE_KEY, "Authorization": `Bearer ${SUPABASE_KEY}` } }
        );
        if (!res.ok) {
          const t = await res.text();
          return new Response(JSON.stringify({ error: "Failed to load stats", detail: t }), {
            status: 500,
            headers: { "Content-Type": "application/json", ...cors }
          });
        }
        const rows = await res.json();
        const stats = {
          total_requests:  rows.length,
          total_approved:  rows.filter(r => r.status === "approved").length,
          total_rejected:  rows.filter(r => r.status === "rejected").length,
          total_pending:   rows.filter(r => r.status === "pending").length,
          total_confirmed: rows.filter(r => r.donations?.picked_up === "picked_up").length,
        };
        return new Response(JSON.stringify(stats), {
          status: 200,
          headers: { "Content-Type": "application/json", ...cors }
        });
      }

      // ROUTE NOT FOUND
      return new Response(
        JSON.stringify({ error: "CHARITY_ROUTE_NOT_FOUND" }),
        { status: 404, headers: { "Content-Type": "application/json", ...cors } }
      );
    }


    // User routes (user-only)
    if (path.startsWith("/user")) {
      if (!profile || profile.role !== "user") {
        return new Response("Only regular users can access this route", { status: 403 });
      }

      const cors = corsHeaders(request);
      const supabaseJsonHeaders = {
        "Content-Type": "application/json",
        "apikey": SUPABASE_KEY,
        "Authorization": `Bearer ${SUPABASE_KEY}`
      };
      const jsonBody = async () => {
        try { return await request.json(); } catch { return null; }
      };
      const isMealVisibleForSignals = (meal) => {
        if (!meal || meal.is_available !== true) return false;
        if (meal.restaurants && meal.restaurants.is_active !== true) return false;
        if (meal.quantity !== null && meal.quantity !== undefined) {
          const qtyNum = Number(meal.quantity);
          if (Number.isFinite(qtyNum) && qtyNum <= 0) return false;
        }
        if (meal.expiry_time) {
          const expMs = Date.parse(meal.expiry_time);
          if (Number.isFinite(expMs) && expMs <= Date.now()) return false;
        }
        return true;
      };
      async function fetchSignalMeal(mealId) {
        const mealRes = await fetch(
          `${SUPABASE_URL}/rest/v1/meals?id=eq.${mealId}&select=id,title,restaurant_id,is_available,quantity,expiry_time,restaurants!inner(id,is_active,is_accepting_orders,pause_reason,accepting_orders_updated_at)&limit=1`,
          { headers: { "apikey": SUPABASE_KEY, "Authorization": `Bearer ${SUPABASE_KEY}` } }
        );
        const mealText = await mealRes.text().catch(() => "");
        let rows = [];
        try { rows = JSON.parse(mealText || "[]"); } catch { rows = []; }
        const meal = Array.isArray(rows) ? rows[0] : null;
        return { mealRes, meal, detail: mealText };
      }
      async function fetchUserOfferDetails(offerId) {
        const offerRes = await fetch(
          `${SUPABASE_URL}/rest/v1/offers?id=eq.${offerId}&select=id,restaurant_id,meal_id,title,description,offer_img_url,original_price,offer_price,quantity,is_active,category,cuisine,tags,starts_at,expires_at,created_at,updated_at,meals(id,title,description,price,meal_img_url,category,cuisine,tags,is_available,quantity,expiry_time),restaurants!inner(id,name,img_url,rest_img_url,is_active,is_accepting_orders,pause_reason,accepting_orders_updated_at)&limit=1`,
          { headers: { "apikey": SUPABASE_KEY, "Authorization": `Bearer ${SUPABASE_KEY}` } }
        );
        const offerText = await offerRes.text().catch(() => "");
        let rows = [];
        try { rows = JSON.parse(offerText || "[]"); } catch { rows = []; }
        const annotatedRows = await annotateOffersWithOrderability(Array.isArray(rows) ? rows : [], { requireOrderable: false });
        const offer = Array.isArray(annotatedRows) ? (annotatedRows[0] ?? null) : null;
        return { offerRes, offer, detail: offerText };
      }
      async function fetchCheckoutMealDetails(mealId) {
        const mealRes = await fetch(
          `${SUPABASE_URL}/rest/v1/meals?id=eq.${mealId}&select=id,restaurant_id,title,price,quantity,meal_img_url,category,cuisine,tags,is_available,expiry_time,restaurants!inner(id,name,img_url,rest_img_url,is_active,is_accepting_orders,pause_reason,accepting_orders_updated_at)&limit=1`,
          {
            headers: {
              "apikey": SUPABASE_KEY,
              "Authorization": `Bearer ${SUPABASE_KEY}`
            }
          }
        );
        const mealText = await mealRes.text().catch(() => "");
        let rows = [];
        try { rows = JSON.parse(mealText || "[]"); } catch { rows = []; }
        const annotatedRows = await annotateMealsWithOrderability(Array.isArray(rows) ? rows : [], { requireOrderable: false });
        const meal = Array.isArray(annotatedRows) ? (annotatedRows[0] ?? null) : null;
        return { mealRes, meal, detail: mealText };
      }
      async function resolveCartRestaurantId(cartRow) {
        if (!cartRow || typeof cartRow !== "object") return null;
        const mealId = typeof cartRow.meal_id === "string" ? cartRow.meal_id.trim() : "";
        const offerId = typeof cartRow.offer_id === "string" ? cartRow.offer_id.trim() : "";
        if (mealId) {
          const mealRes = await fetch(
            `${SUPABASE_URL}/rest/v1/meals?id=eq.${mealId}&select=restaurant_id&limit=1`,
            { headers: { "apikey": SUPABASE_KEY, "Authorization": `Bearer ${SUPABASE_KEY}` } }
          );
          const mealText = await mealRes.text().catch(() => "[]");
          let rows = [];
          try { rows = JSON.parse(mealText || "[]"); } catch { rows = []; }
          const meal = Array.isArray(rows) ? rows[0] : null;
          return typeof meal?.restaurant_id === "string" ? meal.restaurant_id : null;
        }
        if (offerId) {
          const offerRes = await fetch(
            `${SUPABASE_URL}/rest/v1/offers?id=eq.${offerId}&select=restaurant_id&limit=1`,
            { headers: { "apikey": SUPABASE_KEY, "Authorization": `Bearer ${SUPABASE_KEY}` } }
          );
          const offerText = await offerRes.text().catch(() => "[]");
          let rows = [];
          try { rows = JSON.parse(offerText || "[]"); } catch { rows = []; }
          const offer = Array.isArray(rows) ? rows[0] : null;
          return typeof offer?.restaurant_id === "string" ? offer.restaurant_id : null;
        }
        return null;
      }
      async function refreshMealRatingAggregate(mealId) {
        const ratingsRes = await fetch(
          `${SUPABASE_URL}/rest/v1/meal_ratings?meal_id=eq.${mealId}&select=rating`,
          { headers: { "apikey": SUPABASE_KEY, "Authorization": `Bearer ${SUPABASE_KEY}` } }
        );
        const ratingsText = await ratingsRes.text().catch(() => "");
        let ratings = [];
        try { ratings = JSON.parse(ratingsText || "[]"); } catch { ratings = []; }
        if (!ratingsRes.ok) {
          return { ok: false, status: ratingsRes.status, detail: ratingsText };
        }

        const validRatings = Array.isArray(ratings)
          ? ratings
            .map((r) => Number(r && r.rating))
            .filter((v) => Number.isFinite(v) && v >= 1 && v <= 5)
          : [];

        const ratingCount = validRatings.length;
        const avgRating = ratingCount > 0
          ? Math.round((validRatings.reduce((sum, v) => sum + v, 0) / ratingCount) * 100) / 100
          : 0;

        const patchRes = await fetch(
          `${SUPABASE_URL}/rest/v1/meals?id=eq.${mealId}`,
          {
            method: "PATCH",
            headers: {
              ...supabaseJsonHeaders,
              "Prefer": "return=representation"
            },
            body: JSON.stringify({
              avg_rating: avgRating,
              rating_count: ratingCount
            })
          }
        );
        const patchText = await patchRes.text().catch(() => "");
        return {
          ok: patchRes.ok,
          status: patchRes.status,
          avg_rating: avgRating,
          rating_count: ratingCount,
          detail: patchText
        };
      }
      async function invalidateRecommendationCache(reason = "signal_update") {
        if (!RECOMMEND_BASE_URL || !RECOMMEND_API_KEY || !firebase_uid) {
          return { ok: false, skipped: true, reason: "recommender_not_configured" };
        }
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), 2500);
        try {
          const res = await fetch(
            `${RECOMMEND_BASE_URL}/recommend/cache/invalidate/${encodeURIComponent(firebase_uid)}`,
            {
              method: "POST",
              headers: {
                "Content-Type": "application/json",
                "x-api-key": RECOMMEND_API_KEY
              },
              body: JSON.stringify({ reason }),
              signal: controller.signal
            }
          );
          const text = await res.text().catch(() => "");
          return { ok: res.ok, status: res.status, detail: text };
        } catch (e) {
          return { ok: false, error: e instanceof Error ? e.message : String(e || "invalidate_failed") };
        } finally {
          clearTimeout(timeout);
        }
      }

      if (method === "GET" && path === "/user/offers") {
        const nowIso = new Date().toISOString();
        const params = new URLSearchParams();
        params.set(
          "select",
          "id,restaurant_id,meal_id,title,description,offer_img_url,original_price,offer_price,quantity,is_active,category,cuisine,tags,starts_at,expires_at,created_at,updated_at,meals(id,title,description,price,meal_img_url),restaurants!inner(id,name,img_url,rest_img_url,is_active,is_accepting_orders,pause_reason,accepting_orders_updated_at)"
        );
        params.set("is_active", "eq.true");
        params.set("order", "created_at.desc");
        params.set("and", `(or(starts_at.is.null,starts_at.lte.${nowIso}),or(expires_at.is.null,expires_at.gt.${nowIso}))`);
        const offersRes = await fetch(`${SUPABASE_URL}/rest/v1/offers?${params.toString()}`, {
          headers: supabaseHeaders
        });
        const offersText = await offersRes.text().catch(() => "[]");
        if (!offersRes.ok) {
          return new Response(offersText || JSON.stringify({ error: "OFFERS_FETCH_FAILED" }), {
            status: offersRes.status,
            headers: { "Content-Type": "application/json", ...cors }
          });
        }
        let rows = [];
        try { rows = JSON.parse(offersText || "[]"); } catch { rows = []; }
        const annotated = await annotateOffersWithOrderability(rows, { requireOrderable: true });
        const visibleOffers = annotated.filter((offer) => {
          if (offer?.quantity === null || offer?.quantity === undefined) return true;
          const qty = Number(offer.quantity);
          return !Number.isFinite(qty) || qty > 0;
        });
        return new Response(JSON.stringify(visibleOffers), {
          status: 200,
          headers: { "Content-Type": "application/json", ...cors }
        });
      }

      if (method === "GET" && path === "/user/restaurant-offers") {
        const restaurantId = (url.searchParams.get("restaurant_id") || "").trim();
        if (!restaurantId) {
          return new Response(JSON.stringify({ error: "restaurant_id is required" }), {
            status: 400,
            headers: { "Content-Type": "application/json", ...cors }
          });
        }
        const nowIso = new Date().toISOString();
        const params = new URLSearchParams();
        params.set("restaurant_id", `eq.${restaurantId}`);
        params.set(
          "select",
          "id,restaurant_id,meal_id,title,description,offer_img_url,original_price,offer_price,quantity,is_active,category,cuisine,tags,starts_at,expires_at,created_at,updated_at,meals(id,title,description,price,meal_img_url),restaurants!inner(id,name,img_url,rest_img_url,is_active,is_accepting_orders,pause_reason,accepting_orders_updated_at)"
        );
        params.set("is_active", "eq.true");
        params.set("order", "created_at.desc");
        params.set("and", `(or(starts_at.is.null,starts_at.lte.${nowIso}),or(expires_at.is.null,expires_at.gt.${nowIso}))`);
        const offersRes = await fetch(`${SUPABASE_URL}/rest/v1/offers?${params.toString()}`, {
          headers: supabaseHeaders
        });
        const offersText = await offersRes.text().catch(() => "[]");
        if (!offersRes.ok) {
          return new Response(offersText || JSON.stringify({ error: "OFFERS_FETCH_FAILED" }), {
            status: offersRes.status,
            headers: { "Content-Type": "application/json", ...cors }
          });
        }
        let rows = [];
        try { rows = JSON.parse(offersText || "[]"); } catch { rows = []; }
        const annotated = await annotateOffersWithOrderability(rows, { requireOrderable: true });
        const visibleOffers = annotated.filter((offer) => {
          if (offer?.quantity === null || offer?.quantity === undefined) return true;
          const qty = Number(offer.quantity);
          return !Number.isFinite(qty) || qty > 0;
        });
        return new Response(JSON.stringify(visibleOffers), {
          status: 200,
          headers: { "Content-Type": "application/json", ...cors }
        });
      }

      if (method === "GET" && path === "/user/offers/details") {
        const offerId = (url.searchParams.get("offer_id") || "").trim();
        if (!offerId) {
          return new Response(JSON.stringify({ error: "offer_id is required" }), {
            status: 400,
            headers: { "Content-Type": "application/json", ...cors }
          });
        }
        const params = new URLSearchParams();
        params.set("id", `eq.${offerId}`);
        params.set(
          "select",
          "id,restaurant_id,meal_id,title,description,offer_img_url,original_price,offer_price,quantity,is_active,category,cuisine,tags,starts_at,expires_at,created_at,updated_at,meals(id,title,description,price,meal_img_url),restaurants!inner(id,name,img_url,rest_img_url,is_active,is_accepting_orders,pause_reason,accepting_orders_updated_at)"
        );
        params.set("limit", "1");
        const offerRes = await fetch(`${SUPABASE_URL}/rest/v1/offers?${params.toString()}`, {
          headers: supabaseHeaders
        });
        const offerText = await offerRes.text().catch(() => "[]");
        if (!offerRes.ok) {
          return new Response(offerText || JSON.stringify({ error: "OFFER_FETCH_FAILED" }), {
            status: offerRes.status,
            headers: { "Content-Type": "application/json", ...cors }
          });
        }
        let rows = [];
        try { rows = JSON.parse(offerText || "[]"); } catch { rows = []; }
        const annotated = await annotateOffersWithOrderability(rows, { requireOrderable: false });
        const offer = Array.isArray(annotated) ? (annotated[0] ?? null) : null;
        if (!offer || !offer.id) {
          return new Response(JSON.stringify({ error: "OFFER_NOT_FOUND" }), {
            status: 404,
            headers: { "Content-Type": "application/json", ...cors }
          });
        }
        const quantityNum = Number(offer?.quantity);
        const hasAvailableQuantity =
          offer?.quantity === null ||
          offer?.quantity === undefined ||
          !Number.isFinite(quantityNum) ||
          quantityNum > 0;
        if (offer.is_active === false || !hasAvailableQuantity) {
          return new Response(JSON.stringify({ error: "OFFER_NOT_AVAILABLE" }), {
            status: 409,
            headers: { "Content-Type": "application/json", ...cors }
          });
        }
        return new Response(JSON.stringify(offer), {
          status: 200,
          headers: { "Content-Type": "application/json", ...cors }
        });
      }

      if (method === "POST" && path === "/user/meals/view") {
        const body = await jsonBody();
        const mealId = body && typeof body.meal_id === "string" ? body.meal_id.trim() : "";
        if (!mealId) {
          return new Response(JSON.stringify({ error: "meal_id is required" }), {
            status: 400,
            headers: { "Content-Type": "application/json", ...cors }
          });
        }

        const { mealRes, meal, detail } = await fetchSignalMeal(mealId);
        if (!mealRes.ok) {
          return new Response(JSON.stringify({ error: "MEAL_LOOKUP_FAILED", detail }), {
            status: mealRes.status,
            headers: { "Content-Type": "application/json", ...cors }
          });
        }
        if (!meal || !meal.id || !isMealVisibleForSignals(meal)) {
          return new Response(JSON.stringify({ error: "MEAL_NOT_FOUND_OR_UNAVAILABLE" }), {
            status: 404,
            headers: { "Content-Type": "application/json", ...cors }
          });
        }

        const existingRes = await fetch(
          `${SUPABASE_URL}/rest/v1/meal_views?user_id=eq.${profile.profile_id}&meal_id=eq.${mealId}&select=id,view_count&limit=1`,
          { headers: { "apikey": SUPABASE_KEY, "Authorization": `Bearer ${SUPABASE_KEY}` } }
        );
        const existingRows = await existingRes.json().catch(() => []);
        const existing = Array.isArray(existingRows) ? existingRows[0] : null;

        let writeRes;
        if (existing && existing.id) {
          const nextCount = Math.max(1, Number(existing.view_count) || 0) + 1;
          writeRes = await fetch(
            `${SUPABASE_URL}/rest/v1/meal_views?id=eq.${existing.id}`,
            {
              method: "PATCH",
              headers: {
                ...supabaseJsonHeaders,
                "Prefer": "return=representation"
              },
              body: JSON.stringify({
                view_count: nextCount,
                last_viewed_at: new Date().toISOString()
              })
            }
          );
        } else {
          writeRes = await fetch(
            `${SUPABASE_URL}/rest/v1/meal_views`,
            {
              method: "POST",
              headers: {
                ...supabaseJsonHeaders,
                "Prefer": "return=representation"
              },
              body: JSON.stringify({
                user_id: profile.profile_id,
                meal_id: mealId,
                view_count: 1,
                first_viewed_at: new Date().toISOString(),
                last_viewed_at: new Date().toISOString()
              })
            }
          );
        }

        const text = await writeRes.text().catch(() => "");
        return new Response(text || JSON.stringify({ ok: writeRes.ok, meal_id: mealId }), {
          status: writeRes.status,
          headers: { "Content-Type": "application/json", ...cors }
        });
      }

      if (method === "POST" && path === "/user/meals/favorite") {
        const body = await jsonBody();
        const mealId = body && typeof body.meal_id === "string" ? body.meal_id.trim() : "";
        if (!mealId) {
          return new Response(JSON.stringify({ error: "meal_id is required" }), {
            status: 400,
            headers: { "Content-Type": "application/json", ...cors }
          });
        }

        const { mealRes, meal, detail } = await fetchSignalMeal(mealId);
        if (!mealRes.ok) {
          return new Response(JSON.stringify({ error: "MEAL_LOOKUP_FAILED", detail }), {
            status: mealRes.status,
            headers: { "Content-Type": "application/json", ...cors }
          });
        }
        if (!meal || !meal.id || !isMealVisibleForSignals(meal)) {
          return new Response(JSON.stringify({ error: "MEAL_NOT_FOUND_OR_UNAVAILABLE" }), {
            status: 404,
            headers: { "Content-Type": "application/json", ...cors }
          });
        }

        const likeRes = await fetch(
          `${SUPABASE_URL}/rest/v1/meal_likes`,
          {
            method: "POST",
            headers: {
              ...supabaseJsonHeaders,
              "Prefer": "resolution=merge-duplicates,return=representation"
            },
            body: JSON.stringify({
              user_id: profile.profile_id,
              meal_id: mealId
            })
          }
        );
        const text = await likeRes.text().catch(() => "");
        if (likeRes.ok) {
          await invalidateRecommendationCache("meal_favorited");
        }
        return new Response(text || JSON.stringify({ ok: likeRes.ok, meal_id: mealId, favorited: true }), {
          status: likeRes.status,
          headers: { "Content-Type": "application/json", ...cors }
        });
      }

      if (method === "POST" && path === "/user/meals/unfavorite") {
        const body = await jsonBody();
        const mealId = body && typeof body.meal_id === "string" ? body.meal_id.trim() : "";
        if (!mealId) {
          return new Response(JSON.stringify({ error: "meal_id is required" }), {
            status: 400,
            headers: { "Content-Type": "application/json", ...cors }
          });
        }

        const unlikeRes = await fetch(
          `${SUPABASE_URL}/rest/v1/meal_likes?user_id=eq.${profile.profile_id}&meal_id=eq.${mealId}`,
          {
            method: "DELETE",
            headers: {
              "apikey": SUPABASE_KEY,
              "Authorization": `Bearer ${SUPABASE_KEY}`
            }
          }
        );
        const text = await unlikeRes.text().catch(() => "");
        if (unlikeRes.ok || unlikeRes.status === 204) {
          await invalidateRecommendationCache("meal_unfavorited");
        }
        return new Response(text || JSON.stringify({ ok: unlikeRes.ok, meal_id: mealId, favorited: false }), {
          status: unlikeRes.status === 204 ? 200 : unlikeRes.status,
          headers: { "Content-Type": "application/json", ...cors }
        });
      }

      if (method === "GET" && path === "/user/meals/favorites") {
        const favRes = await fetch(
          `${SUPABASE_URL}/rest/v1/meal_likes?user_id=eq.${profile.profile_id}&select=meal_id,created_at&order=created_at.desc`,
          { headers: { "apikey": SUPABASE_KEY, "Authorization": `Bearer ${SUPABASE_KEY}` } }
        );
        const text = await favRes.text().catch(() => "");
        return new Response(text || "[]", {
          status: favRes.status,
          headers: { "Content-Type": "application/json", ...cors }
        });
      }

      if (method === "GET" && path === "/user/meals/favorites/list") {
        const likesRes = await fetch(
          `${SUPABASE_URL}/rest/v1/meal_likes?user_id=eq.${profile.profile_id}&select=meal_id,created_at&order=created_at.desc`,
          { headers: { "apikey": SUPABASE_KEY, "Authorization": `Bearer ${SUPABASE_KEY}` } }
        );
        const likesText = await likesRes.text().catch(() => "");
        if (!likesRes.ok) {
          return new Response(JSON.stringify({ error: "FAVORITES_LOOKUP_FAILED", detail: likesText }), {
            status: likesRes.status,
            headers: { "Content-Type": "application/json", ...cors }
          });
        }

        let likeRows = [];
        try { likeRows = JSON.parse(likesText || "[]"); } catch { likeRows = []; }
        const likedIds = [];
        const likedAtByMealId = {};
        for (const row of (Array.isArray(likeRows) ? likeRows : [])) {
          const mealId = typeof row?.meal_id === "string" ? row.meal_id.trim() : "";
          if (!mealId) continue;
          likedIds.push(mealId);
          likedAtByMealId[mealId] = row?.created_at ?? null;
        }

        if (likedIds.length === 0) {
          return new Response("[]", {
            status: 200,
            headers: { "Content-Type": "application/json", ...cors }
          });
        }

        const mealsRes = await fetch(
          `${SUPABASE_URL}/rest/v1/meals?select=id,title,description,price,meal_img_url,category,cuisine,tags,restaurant_id,is_available,quantity,expiry_time,created_at,avg_rating,rating_count,restaurants!inner(id,name,img_url,rest_img_url,is_active,is_accepting_orders,pause_reason,accepting_orders_updated_at)&id=in.(${likedIds.join(",")})`,
          { headers: { "apikey": SUPABASE_KEY, "Authorization": `Bearer ${SUPABASE_KEY}` } }
        );
        const mealsText = await mealsRes.text().catch(() => "");
        if (!mealsRes.ok) {
          return new Response(JSON.stringify({ error: "FAVORITE_MEALS_LOOKUP_FAILED", detail: mealsText }), {
            status: mealsRes.status,
            headers: { "Content-Type": "application/json", ...cors }
          });
        }

        let mealRows = [];
        try { mealRows = JSON.parse(mealsText || "[]"); } catch { mealRows = []; }
        mealRows = await annotateMealsWithOrderability(mealRows, { requireOrderable: false });
        const byId = {};
        for (const meal of (Array.isArray(mealRows) ? mealRows : [])) {
          const mealId = typeof meal?.id === "string" ? meal.id.trim() : "";
          if (!mealId || !isMealVisibleForSignals(meal)) continue;
          byId[mealId] = {
            ...meal,
            liked_at: likedAtByMealId[mealId] ?? null,
            favorited: true
          };
        }

        const ordered = likedIds
          .map((mealId) => byId[mealId])
          .filter(Boolean);

        return new Response(JSON.stringify(ordered), {
          status: 200,
          headers: { "Content-Type": "application/json", ...cors }
        });
      }

      if (method === "POST" && path === "/user/meals/rating") {
        const body = await jsonBody();
        const mealId = body && typeof body.meal_id === "string" ? body.meal_id.trim() : "";
        const reviewText = body && typeof body.review_text === "string" ? body.review_text.trim() : null;
        const ratingNum = body && body.rating !== undefined ? Number(body.rating) : NaN;

        if (!mealId) {
          return new Response(JSON.stringify({ error: "meal_id is required" }), {
            status: 400,
            headers: { "Content-Type": "application/json", ...cors }
          });
        }
        if (!Number.isFinite(ratingNum) || ratingNum < 1 || ratingNum > 5) {
          return new Response(JSON.stringify({ error: "rating must be a number between 1 and 5" }), {
            status: 400,
            headers: { "Content-Type": "application/json", ...cors }
          });
        }

        const { mealRes, meal, detail } = await fetchSignalMeal(mealId);
        if (!mealRes.ok) {
          return new Response(JSON.stringify({ error: "MEAL_LOOKUP_FAILED", detail }), {
            status: mealRes.status,
            headers: { "Content-Type": "application/json", ...cors }
          });
        }
        if (!meal || !meal.id || !isMealVisibleForSignals(meal)) {
          return new Response(JSON.stringify({ error: "MEAL_NOT_FOUND_OR_UNAVAILABLE" }), {
            status: 404,
            headers: { "Content-Type": "application/json", ...cors }
          });
        }

        const ratingRes = await fetch(
          `${SUPABASE_URL}/rest/v1/meal_ratings?on_conflict=user_id,meal_id`,
          {
            method: "POST",
            headers: {
              ...supabaseJsonHeaders,
              "Prefer": "resolution=merge-duplicates,return=representation"
            },
            body: JSON.stringify({
              user_id: profile.profile_id,
              meal_id: mealId,
              rating: Math.round(ratingNum * 10) / 10,
              review_text: reviewText || null
            })
          }
        );
        const ratingText = await ratingRes.text().catch(() => "");
        if (!ratingRes.ok) {
          return new Response(ratingText || JSON.stringify({ error: "RATING_SAVE_FAILED" }), {
            status: ratingRes.status,
            headers: { "Content-Type": "application/json", ...cors }
          });
        }

        const aggregate = await refreshMealRatingAggregate(mealId);
        if (!aggregate.ok) {
          return new Response(JSON.stringify({
            ok: true,
            meal_id: mealId,
            warning: "RATING_SAVED_BUT_AGGREGATE_REFRESH_FAILED",
            aggregate_status: aggregate.status
          }), {
            status: 200,
            headers: { "Content-Type": "application/json", ...cors }
          });
        }

        await invalidateRecommendationCache("meal_rated");
        return new Response(JSON.stringify({
          ok: true,
          meal_id: mealId,
          avg_rating: aggregate.avg_rating,
          rating_count: aggregate.rating_count
        }), {
          status: 200,
          headers: { "Content-Type": "application/json", ...cors }
        });
      }

      if (method === "GET" && path === "/user/meals/reviews") {
        const mealId = (url.searchParams.get("meal_id") || "").trim();
        if (!mealId) {
          return new Response(JSON.stringify({ error: "meal_id is required" }), {
            status: 400,
            headers: { "Content-Type": "application/json", ...cors }
          });
        }

        const { mealRes, meal, detail } = await fetchSignalMeal(mealId);
        if (!mealRes.ok) {
          return new Response(JSON.stringify({ error: "MEAL_LOOKUP_FAILED", detail }), {
            status: mealRes.status,
            headers: { "Content-Type": "application/json", ...cors }
          });
        }
        if (!meal || !meal.id || !isMealVisibleForSignals(meal)) {
          return new Response(JSON.stringify({ error: "MEAL_NOT_FOUND_OR_UNAVAILABLE" }), {
            status: 404,
            headers: { "Content-Type": "application/json", ...cors }
          });
        }

        const reviewsRes = await fetch(
          `${SUPABASE_URL}/rest/v1/meal_ratings?meal_id=eq.${mealId}&select=rating,review_text,created_at,updated_at,profiles(full_name)&order=updated_at.desc,created_at.desc`,
          { headers: { "apikey": SUPABASE_KEY, "Authorization": `Bearer ${SUPABASE_KEY}` } }
        );
        const reviewsText = await reviewsRes.text().catch(() => "");
        if (!reviewsRes.ok) {
          return new Response(JSON.stringify({ error: "REVIEWS_LOOKUP_FAILED", detail: reviewsText }), {
            status: reviewsRes.status,
            headers: { "Content-Type": "application/json", ...cors }
          });
        }

        let rows = [];
        try { rows = JSON.parse(reviewsText || "[]"); } catch { rows = []; }

        const maskName = (name) => {
          if (typeof name !== "string") return "Anonymous";
          const trimmed = name.trim();
          if (!trimmed) return "Anonymous";
          const parts = trimmed.split(/\s+/).filter(Boolean);
          const first = parts[0] || trimmed;
          if (first.length <= 1) return first;
          return `${first[0]}${"*".repeat(Math.max(1, Math.min(5, first.length - 1)))}`;
        };

        const reviews = (Array.isArray(rows) ? rows : []).map((row) => ({
          user_name: maskName(row?.profiles?.full_name),
          rating: typeof row?.rating === "number" ? row.rating : Number(row?.rating) || 0,
          review_text: typeof row?.review_text === "string" && row.review_text.trim() ? row.review_text.trim() : null,
          created_at: row?.created_at ?? null,
          updated_at: row?.updated_at ?? null
        }));

        return new Response(JSON.stringify({
          meal_id: mealId,
          avg_rating: meal.avg_rating ?? 0,
          rating_count: meal.rating_count ?? 0,
          reviews
        }), {
          status: 200,
          headers: { "Content-Type": "application/json", ...cors }
        });
      }

      if (method === "GET" && path === "/user/meals/my-rating") {
        const mealId = (url.searchParams.get("meal_id") || "").trim();
        if (!mealId) {
          return new Response(JSON.stringify({ error: "meal_id is required" }), {
            status: 400,
            headers: { "Content-Type": "application/json", ...cors }
          });
        }

        const ratingRes = await fetch(
          `${SUPABASE_URL}/rest/v1/meal_ratings?meal_id=eq.${mealId}&user_id=eq.${profile.profile_id}&select=rating,review_text,created_at,updated_at&limit=1`,
          { headers: { "apikey": SUPABASE_KEY, "Authorization": `Bearer ${SUPABASE_KEY}` } }
        );
        const ratingText = await ratingRes.text().catch(() => "");
        if (!ratingRes.ok) {
          return new Response(JSON.stringify({ error: "MY_RATING_LOOKUP_FAILED", detail: ratingText }), {
            status: ratingRes.status,
            headers: { "Content-Type": "application/json", ...cors }
          });
        }

        let rows = [];
        try { rows = JSON.parse(ratingText || "[]"); } catch { rows = []; }
        const row = Array.isArray(rows) ? rows[0] : null;

        return new Response(JSON.stringify({
          meal_id: mealId,
          rating: row ? (typeof row.rating === "number" ? row.rating : Number(row.rating) || 0) : null,
          review_text: row && typeof row.review_text === "string" ? row.review_text : null,
          created_at: row?.created_at ?? null,
          updated_at: row?.updated_at ?? null
        }), {
          status: 200,
          headers: { "Content-Type": "application/json", ...cors }
        });
      }

      // view all available meals from all restaurants
      if (method === "GET" && path === "/user/meals") {
        const hideOfferMeals = (url.searchParams.get("hide_offer_meals") || "true").toLowerCase() !== "false";
        const hasPaginationParams =
          url.searchParams.has("limit") ||
          url.searchParams.has("offset") ||
          url.searchParams.has("cursor");
        if (!hasPaginationParams) {
          return callRPC("get_all_available_meals", {}, request);
        }

        const cors = corsHeaders(request);
        const limitRaw = url.searchParams.get("limit");
        const offsetRaw = url.searchParams.get("offset");
        const cursorRaw = url.searchParams.get("cursor");

        const limitParsed = limitRaw && limitRaw.trim() !== "" ? Number(limitRaw) : 6;
        const offsetParsed = offsetRaw && offsetRaw.trim() !== "" ? Number(offsetRaw) : 0;

        const limit = Number.isFinite(limitParsed) ? Math.max(1, Math.min(50, Math.trunc(limitParsed))) : 6;
        const offset = Number.isFinite(offsetParsed) ? Math.max(0, Math.trunc(offsetParsed)) : 0;

        const isFirstPage = !(cursorRaw && cursorRaw.trim() !== "") && offset === 0;
        const requestOrigin = request.headers.get("Origin") || "*";
        const cacheTtlSeconds = 15;
        let cacheKey = null;
        if (isFirstPage && typeof caches !== "undefined" && caches.default) {
          const cacheUrl = new URL(request.url);
          cacheUrl.searchParams.set("limit", String(limit));
          cacheUrl.searchParams.delete("offset");
          cacheUrl.searchParams.delete("cursor");
          cacheUrl.searchParams.set("__o", requestOrigin);
          cacheKey = new Request(cacheUrl.toString(), { method: "GET" });
          const cached = await caches.default.match(cacheKey);
          if (cached) {
            return cached;
          }
        }

        const nowIso = new Date().toISOString();
        const params = new URLSearchParams();
        params.set("select", "id,title,description,price,meal_img_url,category,cuisine,tags,created_at,restaurant_id,restaurants!inner(id,name,img_url,rest_img_url,is_active,is_accepting_orders,pause_reason,accepting_orders_updated_at)");
        params.set("restaurants.is_active", "eq.true");
        params.set("is_available", "eq.true");
        params.set("or", `(expiry_time.is.null,expiry_time.gt.${nowIso})`);
        params.set("order", "created_at.desc,id.desc");
        params.set("limit", String(limit));

        if (cursorRaw && cursorRaw.trim() !== "") {
          let decoded = null;
          try {
            decoded = decodeURIComponent(cursorRaw);
          } catch {
            decoded = cursorRaw;
          }
          const parts = typeof decoded === "string" ? decoded.split("|") : [];
          const cursorCreatedAt = parts.length >= 1 && parts[0] ? parts[0] : null;
          const cursorId = parts.length >= 2 && parts[1] ? parts[1] : null;
          if (cursorCreatedAt && cursorId) {
            params.set("and", `(or(created_at.lt.${cursorCreatedAt},and(created_at.eq.${cursorCreatedAt},id.lt.${cursorId})))`);
          } else if (cursorCreatedAt) {
            params.set("created_at", `lt.${cursorCreatedAt}`);
          }
        } else {
          params.set("offset", String(offset));
        }

        const mealsRes = await fetch(`${SUPABASE_URL}/rest/v1/meals?${params.toString()}`, {
          headers: {
            "apikey": SUPABASE_KEY,
            "Authorization": `Bearer ${SUPABASE_KEY}`
          }
        });

        const text = await mealsRes.text();
        let responseText = text;

        let nextCursor = "";
        if (mealsRes.ok) {
          try {
            const rows = JSON.parse(text);
            const mealsWithOffers = await attachMealOffers(rows, { hideMealsWithActiveOffer: hideOfferMeals });
            const annotatedRows = await annotateMealsWithOrderability(mealsWithOffers, { requireOrderable: true });
            responseText = JSON.stringify(annotatedRows);
            if (Array.isArray(annotatedRows) && annotatedRows.length > 0) {
              const last = annotatedRows[annotatedRows.length - 1];
              const lastCreatedAt = last && typeof last.created_at === "string" ? last.created_at : null;
              const lastId = last && typeof last.id === "string" ? last.id : null;
              if (lastCreatedAt && lastId) {
                nextCursor = `${lastCreatedAt}|${lastId}`;
              }
            }
          } catch {
            nextCursor = "";
          }
        }

        const headers = {
          "Content-Type": "application/json",
          ...cors,
          "X-Next-Offset": String(offset + limit),
          "X-Next-Cursor": nextCursor,
          ...(isFirstPage ? { "Cache-Control": `public, max-age=${cacheTtlSeconds}` } : {})
        };

        const resp = new Response(responseText, { status: mealsRes.status, headers });
        if (cacheKey && mealsRes.ok && typeof caches !== "undefined" && caches.default) {
          try {
            await caches.default.put(cacheKey, resp.clone());
          } catch {
          }
        }
        return resp;
      }

      // list active restaurants (Talabat-style: restaurants first)
      if (method === "GET" && path === "/user/restaurants") {
        const cors = corsHeaders(request);

        const limitRaw = url.searchParams.get("limit");
        const offsetRaw = url.searchParams.get("offset");
        const cursorRaw = url.searchParams.get("cursor");

        const limitParsed = limitRaw && limitRaw.trim() !== "" ? Number(limitRaw) : 20;
        const offsetParsed = offsetRaw && offsetRaw.trim() !== "" ? Number(offsetRaw) : 0;

        const limit = Number.isFinite(limitParsed) ? Math.max(1, Math.min(50, Math.trunc(limitParsed))) : 20;
        const offset = Number.isFinite(offsetParsed) ? Math.max(0, Math.trunc(offsetParsed)) : 0;

        const params = new URLSearchParams();
        params.set("select", "id,profile_id,name,address,description,created_at,rest_img_url,img_url,is_active,is_accepting_orders,pause_reason,accepting_orders_updated_at");
        params.set("is_active", "eq.true");
        params.set("order", "created_at.desc,id.desc");
        params.set("limit", String(limit));

        if (cursorRaw && cursorRaw.trim() !== "") {
          let decoded = null;
          try {
            decoded = decodeURIComponent(cursorRaw);
          } catch {
            decoded = cursorRaw;
          }
          const parts = typeof decoded === "string" ? decoded.split("|") : [];
          const cursorCreatedAt = parts.length >= 1 && parts[0] ? parts[0] : null;
          const cursorId = parts.length >= 2 && parts[1] ? parts[1] : null;
          if (cursorCreatedAt && cursorId) {
            params.set("and", `(or(created_at.lt.${cursorCreatedAt},and(created_at.eq.${cursorCreatedAt},id.lt.${cursorId})))`);
          } else if (cursorCreatedAt) {
            params.set("created_at", `lt.${cursorCreatedAt}`);
          }
        } else {
          params.set("offset", String(offset));
        }

        const restaurantsRes = await fetch(`${SUPABASE_URL}/rest/v1/restaurants?${params.toString()}`, {
          headers: {
            "apikey": SUPABASE_KEY,
            "Authorization": `Bearer ${SUPABASE_KEY}`
          }
        });

        const text = await restaurantsRes.text();
        let responseText = text;

        let nextCursor = "";
        if (restaurantsRes.ok) {
          try {
            const rows = JSON.parse(text);
            const annotatedRows = await annotateRestaurantsWithOrderability(rows);
            responseText = JSON.stringify(annotatedRows);
            if (Array.isArray(annotatedRows) && annotatedRows.length > 0) {
              const last = annotatedRows[annotatedRows.length - 1];
              const lastCreatedAt = last && typeof last.created_at === "string" ? last.created_at : null;
              const lastId = last && typeof last.id === "string" ? last.id : null;
              if (lastCreatedAt && lastId) {
                nextCursor = `${lastCreatedAt}|${lastId}`;
              }
            }
          } catch {
            nextCursor = "";
          }
        }

        return new Response(responseText, {
          status: restaurantsRes.status,
          headers: {
            "Content-Type": "application/json",
            ...cors,
            "X-Next-Offset": String(offset + limit),
            "X-Next-Cursor": nextCursor
          }
        });
      }

      // list visible meals for one restaurant (restaurant page)
      if (method === "GET" && path === "/user/restaurant-meals") {
        const cors = corsHeaders(request);
        const hideOfferMeals = (url.searchParams.get("hide_offer_meals") || "true").toLowerCase() !== "false";
        const restaurantId = url.searchParams.get("restaurant_id");
        if (!restaurantId || restaurantId.trim() === "") {
          return new Response(JSON.stringify({ error: "restaurant_id is required" }), {
            status: 400,
            headers: { "Content-Type": "application/json", ...cors }
          });
        }

        const limitRaw = url.searchParams.get("limit");
        const offsetRaw = url.searchParams.get("offset");
        const cursorRaw = url.searchParams.get("cursor");

        const limitParsed = limitRaw && limitRaw.trim() !== "" ? Number(limitRaw) : 10;
        const offsetParsed = offsetRaw && offsetRaw.trim() !== "" ? Number(offsetRaw) : 0;

        const limit = Number.isFinite(limitParsed) ? Math.max(1, Math.min(50, Math.trunc(limitParsed))) : 10;
        const offset = Number.isFinite(offsetParsed) ? Math.max(0, Math.trunc(offsetParsed)) : 0;

        const nowIso = new Date().toISOString();
        const params = new URLSearchParams();
        params.set("select", "id,title,description,price,meal_img_url,category,cuisine,tags,created_at,restaurant_id,restaurants!inner(id,name,img_url,rest_img_url,is_active,is_accepting_orders,pause_reason,accepting_orders_updated_at)");
        params.set("restaurants.is_active", "eq.true");
        params.set("restaurant_id", `eq.${restaurantId}`);
        params.set("is_available", "eq.true");
        params.set("or", `(expiry_time.is.null,expiry_time.gt.${nowIso})`);
        params.set("order", "created_at.desc,id.desc");
        params.set("limit", String(limit));

        if (cursorRaw && cursorRaw.trim() !== "") {
          let decoded = null;
          try {
            decoded = decodeURIComponent(cursorRaw);
          } catch {
            decoded = cursorRaw;
          }
          const parts = typeof decoded === "string" ? decoded.split("|") : [];
          const cursorCreatedAt = parts.length >= 1 && parts[0] ? parts[0] : null;
          const cursorId = parts.length >= 2 && parts[1] ? parts[1] : null;
          if (cursorCreatedAt && cursorId) {
            params.set("and", `(or(created_at.lt.${cursorCreatedAt},and(created_at.eq.${cursorCreatedAt},id.lt.${cursorId})))`);
          } else if (cursorCreatedAt) {
            params.set("created_at", `lt.${cursorCreatedAt}`);
          }
        } else {
          params.set("offset", String(offset));
        }

        const mealsRes = await fetch(`${SUPABASE_URL}/rest/v1/meals?${params.toString()}`, {
          headers: {
            "apikey": SUPABASE_KEY,
            "Authorization": `Bearer ${SUPABASE_KEY}`
          }
        });

        const text = await mealsRes.text();
        let responseText = text;

        let nextCursor = "";
        if (mealsRes.ok) {
          try {
            const rows = JSON.parse(text);
            const mealsWithOffers = await attachMealOffers(rows, { hideMealsWithActiveOffer: hideOfferMeals });
            const annotatedRows = await annotateMealsWithOrderability(mealsWithOffers, { requireOrderable: false });
            responseText = JSON.stringify(annotatedRows);
            if (Array.isArray(annotatedRows) && annotatedRows.length > 0) {
              const last = annotatedRows[annotatedRows.length - 1];
              const lastCreatedAt = last && typeof last.created_at === "string" ? last.created_at : null;
              const lastId = last && typeof last.id === "string" ? last.id : null;
              if (lastCreatedAt && lastId) {
                nextCursor = `${lastCreatedAt}|${lastId}`;
              }
            }
          } catch {
            nextCursor = "";
          }
        }

        return new Response(responseText, {
          status: mealsRes.status,
          headers: {
            "Content-Type": "application/json",
            ...cors,
            "X-Next-Offset": String(offset + limit),
            "X-Next-Cursor": nextCursor
          }
        });
      }

      // get current user's cart items
      if (method === "GET" && path === "/user/cart") {
        const cors = corsHeaders(request);
        const res = await fetch(`${SUPABASE_URL}/rest/v1/cart_items?user_id=eq.${profile.profile_id}&select=id,meal_id,offer_id,item_type,quantity,meal_title,unit_price,meal_img_url,category,created_at,updated_at`, {
          headers: {
            "apikey": SUPABASE_KEY,
            "Authorization": `Bearer ${SUPABASE_KEY}`
          }
        });
        const text = await res.text();
        if (!res.ok) {
          return new Response(text, { status: res.status, headers: { "Content-Type": "application/json", ...cors } });
        }
        let rows = [];
        try { rows = JSON.parse(text || "[]"); } catch { rows = []; }
        const enriched = [];
        for (const row of (Array.isArray(rows) ? rows : [])) {
          if (typeof row?.offer_id === "string" && row.offer_id.trim()) {
            const { offer } = await fetchUserOfferDetails(row.offer_id.trim());
            enriched.push({
              ...row,
              title: row?.meal_title ?? offer?.title ?? null,
              image_url: row?.meal_img_url ?? offer?.image_url ?? offer?.offer_img_url ?? null,
              category: row?.category ?? offer?.category ?? null,
              offer_price: offer?.offer_price ?? row?.unit_price ?? null,
              original_price: offer?.original_price ?? null,
              discount_percent: offer?.discount_percent ?? null,
              is_offer: true,
              offer: offer || null
            });
          } else {
            enriched.push({
              ...row,
              title: row?.meal_title ?? null,
              image_url: row?.meal_img_url ?? null,
              is_offer: false
            });
          }
        }
        return new Response(JSON.stringify(enriched), { status: res.status, headers: { "Content-Type": "application/json", ...cors } });
      }

      // add/update an item in the cart (quantity <= 0 removes)
      if (method === "POST" && path === "/user/cart/set-item") {
        const cors = corsHeaders(request);
        const body = await request.json();
        const meal_id = typeof body?.meal_id === "string" ? body.meal_id.trim() : "";
        const offer_id = typeof body?.offer_id === "string" ? body.offer_id.trim() : "";
        const quantityRaw = body?.quantity;
        const quantity = typeof quantityRaw === "number"
          ? quantityRaw
          : (typeof quantityRaw === "string" && quantityRaw !== "" ? Number(quantityRaw) : 1);

        if (!meal_id && !offer_id) return new Response("meal_id or offer_id is required", { status: 400, headers: cors });
        if (meal_id && offer_id) return new Response("send either meal_id or offer_id, not both", { status: 400, headers: cors });
        if (!Number.isFinite(quantity)) return new Response("quantity must be a number", { status: 400, headers: cors });

        if (quantity <= 0) {
          const deleteFilter = meal_id
            ? `meal_id=eq.${meal_id}`
            : `offer_id=eq.${offer_id}`;
          const delRes = await fetch(`${SUPABASE_URL}/rest/v1/cart_items?user_id=eq.${profile.profile_id}&${deleteFilter}`, {
            method: "DELETE",
            headers: {
              "apikey": SUPABASE_KEY,
              "Authorization": `Bearer ${SUPABASE_KEY}`
            }
          });
          const t = await delRes.text();
          const bodyOut = (t && t.trim().length > 0) ? t : "{}";
          const statusOut = delRes.status === 204 ? 200 : delRes.status;
          if (delRes.ok || delRes.status === 204) {
            await invalidateRecommendationCache("cart_item_removed");
          }
          return new Response(bodyOut, { status: statusOut, headers: { "Content-Type": "application/json", ...cors } });
        }

        const nowIso = new Date().toISOString();
        let itemRestaurantId = null;
        let itemTitle = null;
        let itemImageUrl = null;
        let itemCategory = null;
        let itemUnitPrice = null;
        let itemType = meal_id ? "meal" : "offer";
        if (meal_id) {
          const mealRes = await fetch(
            `${SUPABASE_URL}/rest/v1/meals?id=eq.${meal_id}&select=id,restaurant_id,title,price,meal_img_url,category,cuisine,tags,is_available,expiry_time,restaurants!inner(id,name,img_url,rest_img_url,is_active,is_accepting_orders,pause_reason,accepting_orders_updated_at)`,
            {
              headers: {
                "apikey": SUPABASE_KEY,
                "Authorization": `Bearer ${SUPABASE_KEY}`
              }
            }
          );
          if (!mealRes.ok) {
            const t = await mealRes.text();
            return new Response(t || "Meal lookup failed", { status: mealRes.status, headers: { "Content-Type": "application/json", ...cors } });
          }
          const mealRows = await mealRes.json();
          const annotatedMealRows = await annotateMealsWithOrderability(mealRows, { requireOrderable: false });
          const meal = Array.isArray(annotatedMealRows) ? annotatedMealRows[0] : null;
          if (!meal || !meal.id) return new Response("Meal not found", { status: 404, headers: cors });
          if (meal?.restaurants?.is_active === false) {
            return new Response(JSON.stringify({ error: "RESTAURANT_INACTIVE" }), { status: 403, headers: { "Content-Type": "application/json", ...cors } });
          }
          if (meal?.is_orderable_now === false) {
            return new Response(JSON.stringify({
              error: "RESTAURANT_NOT_ACCEPTING_ORDERS",
              pause_reason: meal?.restaurants?.pause_reason ?? null,
              is_open_now: meal?.is_open_now ?? null
            }), { status: 409, headers: { "Content-Type": "application/json", ...cors } });
          }
          if (meal?.is_available === false) {
            return new Response(JSON.stringify({ error: "MEAL_NOT_AVAILABLE" }), { status: 409, headers: { "Content-Type": "application/json", ...cors } });
          }
          if (typeof meal?.expiry_time === "string" && meal.expiry_time && meal.expiry_time <= nowIso) {
            return new Response(JSON.stringify({ error: "MEAL_EXPIRED" }), { status: 409, headers: { "Content-Type": "application/json", ...cors } });
          }
          const activeOffersMap = await fetchActiveOffersMapByMealIds([meal.id]);
          const activeOffer = activeOffersMap[meal.id] || null;
          if (activeOffer?.id) {
            return new Response(JSON.stringify({ error: "MEAL_HAS_ACTIVE_OFFER", meal_id: meal.id, offer_id: activeOffer.id }), {
              status: 409,
              headers: { "Content-Type": "application/json", ...cors }
            });
          }
          itemRestaurantId = typeof meal?.restaurant_id === "string" ? meal.restaurant_id : null;
          itemTitle = typeof meal?.title === "string" ? meal.title : null;
          itemImageUrl = typeof meal?.meal_img_url === "string" ? meal.meal_img_url : null;
          itemCategory = typeof meal?.category === "string" ? meal.category : null;
          itemUnitPrice = normalizeMoneyValue(meal?.price);
        } else {
          const { offerRes, offer, detail } = await fetchUserOfferDetails(offer_id);
          if (!offerRes.ok) {
            return new Response(detail || "Offer lookup failed", { status: offerRes.status, headers: { "Content-Type": "application/json", ...cors } });
          }
          if (!offer || !offer.id) {
            return new Response(JSON.stringify({ error: "OFFER_NOT_FOUND" }), { status: 404, headers: { "Content-Type": "application/json", ...cors } });
          }
          if (offer.is_active === false) {
            return new Response(JSON.stringify({ error: "OFFER_NOT_ACTIVE" }), { status: 409, headers: { "Content-Type": "application/json", ...cors } });
          }
          if (offer.is_orderable_now === false) {
            return new Response(JSON.stringify({
              error: "RESTAURANT_NOT_ACCEPTING_ORDERS",
              pause_reason: offer?.restaurants?.pause_reason ?? null,
              is_open_now: offer?.is_open_now ?? null
            }), { status: 409, headers: { "Content-Type": "application/json", ...cors } });
          }
          if (typeof offer?.expires_at === "string" && offer.expires_at && offer.expires_at <= nowIso) {
            return new Response(JSON.stringify({ error: "OFFER_EXPIRED" }), { status: 409, headers: { "Content-Type": "application/json", ...cors } });
          }
          if (typeof offer?.starts_at === "string" && offer.starts_at && offer.starts_at > nowIso) {
            return new Response(JSON.stringify({ error: "OFFER_NOT_STARTED" }), { status: 409, headers: { "Content-Type": "application/json", ...cors } });
          }
          itemRestaurantId = typeof offer?.restaurant_id === "string" ? offer.restaurant_id : null;
          itemTitle = typeof offer?.title === "string" ? offer.title : null;
          itemImageUrl = typeof offer?.image_url === "string" ? offer.image_url : (typeof offer?.offer_img_url === "string" ? offer.offer_img_url : null);
          itemCategory = typeof offer?.category === "string" ? offer.category : null;
          itemUnitPrice = normalizeMoneyValue(offer?.offer_price);
        }
        if (!itemRestaurantId) {
          return new Response(JSON.stringify({ error: "ITEM_RESTAURANT_MISSING" }), { status: 400, headers: { "Content-Type": "application/json", ...cors } });
        }

        const cartCheckRes = await fetch(
          `${SUPABASE_URL}/rest/v1/cart_items?user_id=eq.${profile.profile_id}&select=meal_id,offer_id&limit=1`,
          {
            headers: {
              "apikey": SUPABASE_KEY,
              "Authorization": `Bearer ${SUPABASE_KEY}`
            }
          }
        );
        if (!cartCheckRes.ok) {
          const t = await cartCheckRes.text();
          return new Response(t || "Cart lookup failed", { status: cartCheckRes.status, headers: { "Content-Type": "application/json", ...cors } });
        }
        const cartRows = await cartCheckRes.json();
        const firstCartRow = Array.isArray(cartRows) ? (cartRows[0] ?? null) : null;
        const cartRestaurantId = await resolveCartRestaurantId(firstCartRow);
        if (cartRestaurantId && cartRestaurantId !== itemRestaurantId) {
          return new Response(
            JSON.stringify({
              error: "CART_RESTAURANT_MISMATCH",
              cart_restaurant_id: cartRestaurantId,
              new_restaurant_id: itemRestaurantId
            }),
            { status: 409, headers: { "Content-Type": "application/json", ...cors } }
          );
        }

        const existingItemFilter = meal_id ? `meal_id=eq.${meal_id}` : `offer_id=eq.${offer_id}`;
        const existingItemRes = await fetch(
          `${SUPABASE_URL}/rest/v1/cart_items?user_id=eq.${profile.profile_id}&${existingItemFilter}&select=id&limit=1`,
          {
            headers: {
              "apikey": SUPABASE_KEY,
              "Authorization": `Bearer ${SUPABASE_KEY}`
            }
          }
        );
        const existingItemText = await existingItemRes.text().catch(() => "[]");
        let existingItemRows = [];
        try { existingItemRows = JSON.parse(existingItemText || "[]"); } catch { existingItemRows = []; }
        const existingItem = Array.isArray(existingItemRows) ? (existingItemRows[0] ?? null) : null;

        const cartPayload = {
          user_id: profile.profile_id,
          quantity: Math.trunc(quantity),
          meal_title: itemTitle,
          unit_price: itemUnitPrice,
          meal_img_url: itemImageUrl,
          category: itemCategory,
          updated_at: new Date().toISOString(),
          item_type: itemType,
          meal_id: meal_id || null,
          offer_id: offer_id || null
        };

        const upsertRes = await fetch(
          existingItem?.id
            ? `${SUPABASE_URL}/rest/v1/cart_items?id=eq.${existingItem.id}`
            : `${SUPABASE_URL}/rest/v1/cart_items`,
          {
            method: existingItem?.id ? "PATCH" : "POST",
            headers: {
              "Content-Type": "application/json",
              "apikey": SUPABASE_KEY,
              "Authorization": `Bearer ${SUPABASE_KEY}`,
              "Prefer": "return=representation"
            },
            body: JSON.stringify(existingItem?.id ? {
              quantity: cartPayload.quantity,
              meal_title: cartPayload.meal_title,
              unit_price: cartPayload.unit_price,
              meal_img_url: cartPayload.meal_img_url,
              category: cartPayload.category,
              item_type: cartPayload.item_type,
              meal_id: cartPayload.meal_id,
              offer_id: cartPayload.offer_id,
              updated_at: cartPayload.updated_at
            } : cartPayload)
          }
        );

        const upsertText = await upsertRes.text();
        if (upsertRes.ok) {
          await invalidateRecommendationCache("cart_item_upserted");
        }
        return new Response(upsertText, { status: upsertRes.status, headers: { "Content-Type": "application/json", ...cors } });
      }

      // remove one item from cart
      if (method === "POST" && path === "/user/cart/remove-item") {
        const cors = corsHeaders(request);
        const body = await request.json();
        const meal_id = typeof body?.meal_id === "string" ? body.meal_id.trim() : "";
        const offer_id = typeof body?.offer_id === "string" ? body.offer_id.trim() : "";
        if (!meal_id && !offer_id) return new Response("meal_id or offer_id is required", { status: 400, headers: cors });
        if (meal_id && offer_id) return new Response("send either meal_id or offer_id, not both", { status: 400, headers: cors });
        const deleteFilter = meal_id ? `meal_id=eq.${meal_id}` : `offer_id=eq.${offer_id}`;
        const delRes = await fetch(`${SUPABASE_URL}/rest/v1/cart_items?user_id=eq.${profile.profile_id}&${deleteFilter}`, {
          method: "DELETE",
          headers: {
            "apikey": SUPABASE_KEY,
            "Authorization": `Bearer ${SUPABASE_KEY}`
          }
        });
        const t = await delRes.text();
        const bodyOut = (t && t.trim().length > 0) ? t : "{}";
        const statusOut = delRes.status === 204 ? 200 : delRes.status;
        if (delRes.ok || delRes.status === 204) {
          await invalidateRecommendationCache("cart_item_removed");
        }
        return new Response(bodyOut, { status: statusOut, headers: { "Content-Type": "application/json", ...cors } });
      }

      // clear cart
      if (method === "POST" && path === "/user/cart/clear") {
        const cors = corsHeaders(request);
        const delRes = await fetch(`${SUPABASE_URL}/rest/v1/cart_items?user_id=eq.${profile.profile_id}`, {
          method: "DELETE",
          headers: {
            "apikey": SUPABASE_KEY,
            "Authorization": `Bearer ${SUPABASE_KEY}`
          }
        });
        const t = await delRes.text();
        const bodyOut = (t && t.trim().length > 0) ? t : "{}";
        const statusOut = delRes.status === 204 ? 200 : delRes.status;
        if (delRes.ok || delRes.status === 204) {
          await invalidateRecommendationCache("cart_cleared");
        }
        return new Response(bodyOut, { status: statusOut, headers: { "Content-Type": "application/json", ...cors } });
      }

      // checkout using validated cart snapshots and a transactional offer-aware RPC
      if (method === "POST" && path === "/user/checkout") {
        const cors = corsHeaders(request);
        const idempotencyKeyHeader = request.headers.get("Idempotency-Key");
        let body = null;
        try {
          body = await request.json();
        } catch {
          body = null;
        }
        const idempotencyKeyBody = body && typeof body.idempotency_key === "string" ? body.idempotency_key : null;
        const idempotencyKey = (idempotencyKeyBody && idempotencyKeyBody.trim()) ? idempotencyKeyBody.trim()
          : (idempotencyKeyHeader && idempotencyKeyHeader.trim()) ? idempotencyKeyHeader.trim()
            : null;
        const address = (body && typeof body.address === "string") ? body.address : null;
        const area = (body && typeof body.area === "string") ? body.area : null;
        const customerName = (body && typeof body.customer_name === "string") ? body.customer_name : null;
        const customerPhone = (body && typeof body.customer_phone === "string") ? body.customer_phone : null;

        const cartRes = await fetch(`${SUPABASE_URL}/rest/v1/cart_items?user_id=eq.${profile.profile_id}&select=id,meal_id,offer_id,item_type,quantity,meal_title,unit_price,meal_img_url,category`, {
          headers: {
            "apikey": SUPABASE_KEY,
            "Authorization": `Bearer ${SUPABASE_KEY}`
          }
        });
        if (!cartRes.ok) {
          const t = await cartRes.text();
          return new Response(t || "Cart lookup failed", { status: cartRes.status, headers: { "Content-Type": "application/json", ...cors } });
        }

        const cartItems = await cartRes.json();
        if (!Array.isArray(cartItems) || cartItems.length === 0) {
          return new Response(JSON.stringify({ error: "CART_EMPTY" }), { status: 400, headers: { "Content-Type": "application/json", ...cors } });
        }

        const nowIso = new Date().toISOString();
        const checkoutItems = [];
        let checkoutRestaurantId = null;

        for (const cartRow of cartItems) {
          const mealId = typeof cartRow?.meal_id === "string" ? cartRow.meal_id.trim() : "";
          const offerId = typeof cartRow?.offer_id === "string" ? cartRow.offer_id.trim() : "";
          const itemType = (typeof cartRow?.item_type === "string" ? cartRow.item_type.trim().toLowerCase() : "") === "offer" || offerId
            ? "offer"
            : "meal";
          const quantityNum = typeof cartRow?.quantity === "number"
            ? cartRow.quantity
            : (typeof cartRow?.quantity === "string" && cartRow.quantity.trim() !== "" ? Number(cartRow.quantity) : NaN);
          if (!Number.isFinite(quantityNum)) {
            return new Response(JSON.stringify({ error: "INVALID_CART_QUANTITY", cart_item_id: cartRow?.id ?? null }), { status: 400, headers: { "Content-Type": "application/json", ...cors } });
          }
          const requestedQuantity = Math.max(1, Math.trunc(quantityNum));

          if (itemType === "offer") {
            const { offerRes, offer, detail } = await fetchUserOfferDetails(offerId);
            if (!offerRes.ok) {
              return new Response(detail || "Offer lookup failed", { status: offerRes.status, headers: { "Content-Type": "application/json", ...cors } });
            }
            if (!offer || !offer.id) {
              return new Response(JSON.stringify({ error: "OFFER_NOT_FOUND", offer_id: offerId || null }), { status: 404, headers: { "Content-Type": "application/json", ...cors } });
            }
            if (offer?.restaurants?.is_active === false) {
              return new Response(JSON.stringify({ error: "RESTAURANT_INACTIVE", offer_id: offer.id }), { status: 403, headers: { "Content-Type": "application/json", ...cors } });
            }
            if (offer.is_active === false) {
              return new Response(JSON.stringify({ error: "OFFER_NOT_ACTIVE", offer_id: offer.id }), { status: 409, headers: { "Content-Type": "application/json", ...cors } });
            }
            if (offer.is_orderable_now === false) {
              return new Response(JSON.stringify({
                error: "RESTAURANT_NOT_ACCEPTING_ORDERS",
                offer_id: offer.id,
                pause_reason: offer?.restaurants?.pause_reason ?? null,
                is_open_now: offer?.is_open_now ?? null
              }), { status: 409, headers: { "Content-Type": "application/json", ...cors } });
            }
            if (typeof offer?.expires_at === "string" && offer.expires_at && offer.expires_at <= nowIso) {
              return new Response(JSON.stringify({ error: "OFFER_EXPIRED", offer_id: offer.id }), { status: 409, headers: { "Content-Type": "application/json", ...cors } });
            }
            if (typeof offer?.starts_at === "string" && offer.starts_at && offer.starts_at > nowIso) {
              return new Response(JSON.stringify({ error: "OFFER_NOT_STARTED", offer_id: offer.id }), { status: 409, headers: { "Content-Type": "application/json", ...cors } });
            }
            const itemRestaurantId = typeof offer?.restaurant_id === "string" ? offer.restaurant_id : null;
            if (!itemRestaurantId) {
              return new Response(JSON.stringify({ error: "ITEM_RESTAURANT_MISSING", offer_id: offer.id }), { status: 400, headers: { "Content-Type": "application/json", ...cors } });
            }
            if (checkoutRestaurantId && checkoutRestaurantId !== itemRestaurantId) {
              return new Response(JSON.stringify({
                error: "CART_RESTAURANT_MISMATCH",
                cart_restaurant_id: checkoutRestaurantId,
                new_restaurant_id: itemRestaurantId
              }), { status: 409, headers: { "Content-Type": "application/json", ...cors } });
            }
            checkoutRestaurantId = checkoutRestaurantId || itemRestaurantId;
            checkoutItems.push({
              meal_id: null,
              offer_id: offer.id,
              item_type: "offer",
              quantity: requestedQuantity,
              meal_title: typeof offer?.title === "string" ? offer.title : (typeof cartRow?.meal_title === "string" ? cartRow.meal_title : null),
              unit_price: normalizeMoneyValue(offer?.offer_price),
              meal_img_url: typeof offer?.image_url === "string" ? offer.image_url : (typeof offer?.offer_img_url === "string" ? offer.offer_img_url : null),
              category: typeof offer?.category === "string" ? offer.category : (typeof cartRow?.category === "string" ? cartRow.category : null)
            });
            continue;
          }

          const { mealRes, meal, detail } = await fetchCheckoutMealDetails(mealId);
          if (!mealRes.ok) {
            return new Response(detail || "Meal lookup failed", { status: mealRes.status, headers: { "Content-Type": "application/json", ...cors } });
          }
          if (!meal || !meal.id) {
            return new Response(JSON.stringify({ error: "MEAL_NOT_FOUND", meal_id: mealId || null }), { status: 404, headers: { "Content-Type": "application/json", ...cors } });
          }
          if (meal?.restaurants?.is_active === false) {
            return new Response(JSON.stringify({ error: "RESTAURANT_INACTIVE", meal_id: meal.id }), { status: 403, headers: { "Content-Type": "application/json", ...cors } });
          }
          if (meal?.is_orderable_now === false) {
            return new Response(JSON.stringify({
              error: "RESTAURANT_NOT_ACCEPTING_ORDERS",
              meal_id: meal.id,
              pause_reason: meal?.restaurants?.pause_reason ?? null,
              is_open_now: meal?.is_open_now ?? null
            }), { status: 409, headers: { "Content-Type": "application/json", ...cors } });
          }
          if (meal?.is_available === false) {
            return new Response(JSON.stringify({ error: "MEAL_NOT_AVAILABLE", meal_id: meal.id }), { status: 409, headers: { "Content-Type": "application/json", ...cors } });
          }
          if (typeof meal?.expiry_time === "string" && meal.expiry_time && meal.expiry_time <= nowIso) {
            return new Response(JSON.stringify({ error: "MEAL_EXPIRED", meal_id: meal.id }), { status: 409, headers: { "Content-Type": "application/json", ...cors } });
          }
          const activeOffersMap = await fetchActiveOffersMapByMealIds([meal.id]);
          const activeOffer = activeOffersMap[meal.id] || null;
          if (activeOffer?.id) {
            return new Response(JSON.stringify({ error: "MEAL_HAS_ACTIVE_OFFER", meal_id: meal.id, offer_id: activeOffer.id }), {
              status: 409,
              headers: { "Content-Type": "application/json", ...cors }
            });
          }

          const itemRestaurantId = typeof meal?.restaurant_id === "string" ? meal.restaurant_id : null;
          if (!itemRestaurantId) {
            return new Response(JSON.stringify({ error: "ITEM_RESTAURANT_MISSING", meal_id: meal.id }), { status: 400, headers: { "Content-Type": "application/json", ...cors } });
          }
          if (checkoutRestaurantId && checkoutRestaurantId !== itemRestaurantId) {
            return new Response(JSON.stringify({
              error: "CART_RESTAURANT_MISMATCH",
              cart_restaurant_id: checkoutRestaurantId,
              new_restaurant_id: itemRestaurantId
            }), { status: 409, headers: { "Content-Type": "application/json", ...cors } });
          }
          checkoutRestaurantId = checkoutRestaurantId || itemRestaurantId;
          checkoutItems.push({
            meal_id: meal.id,
            offer_id: null,
            item_type: "meal",
            quantity: requestedQuantity,
            meal_title: typeof meal?.title === "string" ? meal.title : (typeof cartRow?.meal_title === "string" ? cartRow.meal_title : null),
            unit_price: normalizeMoneyValue(meal?.price),
            meal_img_url: typeof meal?.meal_img_url === "string" ? meal.meal_img_url : null,
            category: typeof meal?.category === "string" ? meal.category : (typeof cartRow?.category === "string" ? cartRow.category : null)
          });
        }

        if (!checkoutRestaurantId || checkoutItems.length === 0) {
          return new Response(JSON.stringify({ error: "CART_EMPTY" }), { status: 400, headers: { "Content-Type": "application/json", ...cors } });
        }

        let orderResp = await fetch(`${SUPABASE_URL}/rest/v1/rpc/checkout_user_cart_with_offers_v1`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "apikey": SUPABASE_KEY,
            "Authorization": `Bearer ${SUPABASE_KEY}`
          },
          body: JSON.stringify({
            p_user_id: profile.profile_id,
            p_restaurant_id: checkoutRestaurantId,
            p_items: checkoutItems,
            p_address: address,
            p_area: area,
            p_customer_name: customerName,
            p_customer_phone: customerPhone,
            p_idempotency_key: idempotencyKey
          })
        });

        const orderText = await orderResp.text();
        if (!orderResp.ok) {
          return new Response(orderText, { status: orderResp.status, headers: { "Content-Type": "application/json", ...cors } });
        }

        await invalidateRecommendationCache("checkout_completed");
        return new Response(orderText, { status: 200, headers: { "Content-Type": "application/json", ...cors } });
      }

      // place an order
      if (method === "POST" && path === "/user/make-order") {
        const body = await request.json();
        if (!body.meals) return new Response("Meals data is required", { status: 400 });

        const idempotencyKeyHeader = request.headers.get("Idempotency-Key");
        const idempotencyKeyBody = typeof body.idempotency_key === "string" ? body.idempotency_key : null;
        const idempotencyKey = (idempotencyKeyBody && idempotencyKeyBody.trim()) ? idempotencyKeyBody.trim()
          : (idempotencyKeyHeader && idempotencyKeyHeader.trim()) ? idempotencyKeyHeader.trim()
            : null;

        const v2Attempt = await fetch(`${SUPABASE_URL}/rest/v1/rpc/make_order_user_only_with_delivery_v2`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "apikey": SUPABASE_KEY,
            "Authorization": `Bearer ${SUPABASE_KEY}`
          },
          body: JSON.stringify({
            p_user_id: profile.profile_id,
            p_meals: body.meals,
            p_address: body.address ?? null,
            p_area: body.area ?? null,
            p_customer_name: body.customer_name ?? null,
            p_customer_phone: body.customer_phone ?? null,
            p_idempotency_key: idempotencyKey
          })
        });
        const t = await v2Attempt.text().catch(() => "");
        if (v2Attempt.ok) {
          await invalidateRecommendationCache("order_created");
        }
        return new Response(t, { status: v2Attempt.status, headers: { "Content-Type": "application/json", ...corsHeaders(request) } });
      }

      // cancel an order
      if (method === "POST" && path === "/user/cancel-order") {
        const body = await request.json();
        if (!body.order_id) return new Response("Order ID is required", { status: 400 });

        const tryV2 = await fetch(`${SUPABASE_URL}/rest/v1/rpc/cancel_order_user_only_v2`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "apikey": SUPABASE_KEY,
            "Authorization": `Bearer ${SUPABASE_KEY}`
          },
          body: JSON.stringify({
            p_order_id: body.order_id,
            p_user_id: profile.profile_id
          })
        });
        const t = await tryV2.text().catch(() => "");
        return new Response(t, { status: tryV2.status, headers: { "Content-Type": "application/json", ...corsHeaders(request) } });
      }

      // user order history
      if (method === "GET" && path === "/user/history/orders") {
        const limitRaw = url.searchParams.get("limit");
        const offsetRaw = url.searchParams.get("offset");
        const cursorRaw = url.searchParams.get("cursor");
        const time = (url.searchParams.get("time") || "all").toLowerCase();
        const fromRaw = url.searchParams.get("from");
        const toRaw = url.searchParams.get("to");
        const statusRaw = url.searchParams.get("status");
        const tzOffsetRaw = url.searchParams.get("tz_offset_minutes");
        const hasPaginationParams =
          (typeof limitRaw === "string" && limitRaw.trim() !== "") ||
          (typeof offsetRaw === "string" && offsetRaw.trim() !== "") ||
          (typeof cursorRaw === "string" && cursorRaw.trim() !== "") ||
          (typeof fromRaw === "string" && fromRaw.trim() !== "") ||
          (typeof toRaw === "string" && toRaw.trim() !== "") ||
          (typeof statusRaw === "string" && statusRaw.trim() !== "") ||
          (typeof tzOffsetRaw === "string" && tzOffsetRaw.trim() !== "") ||
          (typeof time === "string" && time !== "" && time !== "all");

        if (!hasPaginationParams) {
          return callRPC("user_history", { p_user_id: profile.profile_id }, request);
        }

        const cors = corsHeaders(request);
        const limitParsed = limitRaw && limitRaw.trim() !== "" ? Number(limitRaw) : 10;
        const offsetParsed = offsetRaw && offsetRaw.trim() !== "" ? Number(offsetRaw) : 0;
        const limit = Number.isFinite(limitParsed) ? Math.max(1, Math.min(50, Math.trunc(limitParsed))) : 10;
        const offset = Number.isFinite(offsetParsed) ? Math.max(0, Math.trunc(offsetParsed)) : 0;

        const tzOffsetMinutesParsed = tzOffsetRaw && tzOffsetRaw.trim() !== "" ? Number(tzOffsetRaw) : null;
        const tzOffsetMinutes = Number.isFinite(tzOffsetMinutesParsed) ? Math.max(-840, Math.min(840, Math.trunc(tzOffsetMinutesParsed))) : null;

        const parseIso = (v) => {
          if (!v || typeof v !== "string" || !v.trim()) return null;
          const d = new Date(v);
          return Number.isFinite(d.getTime()) ? d.toISOString() : null;
        };

        const now = new Date();
        const computeStartOfDayIso = () => {
          if (tzOffsetMinutes == null) {
            const d = new Date(now);
            d.setUTCHours(0, 0, 0, 0);
            return d.toISOString();
          }
          const localMs = now.getTime() - tzOffsetMinutes * 60_000;
          const local = new Date(localMs);
          local.setUTCHours(0, 0, 0, 0);
          const utcMs = local.getTime() + tzOffsetMinutes * 60_000;
          return new Date(utcMs).toISOString();
        };

        const computeStartOfWeekIso = () => {
          if (tzOffsetMinutes == null) {
            const d = new Date(now);
            const day = d.getUTCDay();
            const diffToMonday = (day + 6) % 7;
            d.setUTCDate(d.getUTCDate() - diffToMonday);
            d.setUTCHours(0, 0, 0, 0);
            return d.toISOString();
          }
          const localMs = now.getTime() - tzOffsetMinutes * 60_000;
          const local = new Date(localMs);
          const day = local.getUTCDay();
          const diffToMonday = (day + 6) % 7;
          local.setUTCDate(local.getUTCDate() - diffToMonday);
          local.setUTCHours(0, 0, 0, 0);
          const utcMs = local.getTime() + tzOffsetMinutes * 60_000;
          return new Date(utcMs).toISOString();
        };

        const fromIso =
          time === "today"
            ? computeStartOfDayIso()
            : (time === "week" || time === "thisweek" || time === "this_week")
              ? computeStartOfWeekIso()
              : parseIso(fromRaw);
        const toIso = parseIso(toRaw);

        const statusList = typeof statusRaw === "string"
          ? statusRaw.split(",").map((s) => s.trim()).filter(Boolean)
          : [];

        const params = new URLSearchParams();
        params.set(
          "select",
          "id,status,created_at,restaurant_id,address,area,customer_name,customer_phone,order_items(id,meal_id,offer_id,item_type,quantity,meal_title,unit_price,meal_img_url,category)"
        );
        params.set("user_id", `eq.${profile.profile_id}`);
        params.set("order", "created_at.desc,id.desc");
        params.set("limit", String(limit));

        if (fromIso) params.set("created_at", `gte.${fromIso}`);
        if (toIso) params.set("created_at", `${params.get("created_at") ? params.get("created_at") + "," : ""}lte.${toIso}`);

        if (statusList.length === 1) {
          params.set("status", `eq.${statusList[0]}`);
        } else if (statusList.length > 1) {
          params.set("status", `in.(${statusList.join(",")})`);
        }

        if (cursorRaw && cursorRaw.trim() !== "") {
          let decoded = null;
          try {
            decoded = decodeURIComponent(cursorRaw);
          } catch {
            decoded = cursorRaw;
          }
          const parts = typeof decoded === "string" ? decoded.split("|") : [];
          const cursorCreatedAt = parts.length >= 1 && parts[0] ? parts[0] : null;
          const cursorId = parts.length >= 2 && parts[1] ? parts[1] : null;
          if (cursorCreatedAt && cursorId) {
            params.set("and", `(or(created_at.lt.${cursorCreatedAt},and(created_at.eq.${cursorCreatedAt},id.lt.${cursorId})))`);
          } else if (cursorCreatedAt) {
            params.set("created_at", `${params.get("created_at") ? params.get("created_at") + "," : ""}lt.${cursorCreatedAt}`);
          }
        } else {
          params.set("offset", String(offset));
        }

        const ordersRes = await fetch(`${SUPABASE_URL}/rest/v1/orders?${params.toString()}`, {
          headers: {
            "apikey": SUPABASE_KEY,
            "Authorization": `Bearer ${SUPABASE_KEY}`
          }
        });

        const text = await ordersRes.text();

        let nextCursor = "";
        let payloadText = text;
        if (ordersRes.ok) {
          try {
            const rows = JSON.parse(text);
            if (Array.isArray(rows)) {
              const mapped = rows.map((o) => {
                const items = o && Array.isArray(o.order_items) ? o.order_items : [];
                const { order_items, ...rest } = o || {};
                return { ...rest, items };
              });
              payloadText = JSON.stringify(mapped);

              if (mapped.length > 0) {
                const last = mapped[mapped.length - 1];
                const lastCreatedAt = last && typeof last.created_at === "string" ? last.created_at : null;
                const lastId = last && typeof last.id === "string" ? last.id : null;
                if (lastCreatedAt && lastId) {
                  nextCursor = `${lastCreatedAt}|${lastId}`;
                }
              }
            }
          } catch {
            nextCursor = "";
            payloadText = text;
          }
        }

        const headers = {
          "Content-Type": "application/json",
          ...cors,
          "X-Next-Offset": String(offset + limit),
          "X-Next-Cursor": nextCursor
        };
        return new Response(payloadText, { status: ordersRes.status, headers });
      }

      // user statistics
      if (method === "GET" && path === "/user/statistics") {
        return callRPC("user_statistics", {
          p_user_id: profile.profile_id
        }, request);
      }
    }
    
    // Profile update route (role-based fields)
    if (path === "/profile/update" && method === "POST") {
      if (!profile) {
        return new Response("Unauthorized: Profile not found", { status: 401 });
      }

      const body = await request.json();

      // Role-based field control
      const updateData = {
        p_profile_id: profile.profile_id,
        p_full_name: body.full_name ?? null,
        p_email: body.email ?? null,
        p_name: body.name ?? null,
        p_address: body.address ?? null,
        p_description: body.description ?? null
      };

      if (profile.role === "restaurant") {
        updateData.p_rest_img_url = body.rest_img_url ?? null;
      }

      return callRPC("update_profile", updateData, request);
    }
    ////search engine

     if (method === "GET" && path === "/search") {
        const cors = corsHeaders(request);
        const hideOfferMeals = (url.searchParams.get("hide_offer_meals") || "true").toLowerCase() !== "false";

        if (!profile || profile.role !== "user") {
          return new Response(
            JSON.stringify({ error: "Only users can search" }),
            { status: 403, headers: { "Content-Type": "application/json", ...cors } }
          );
        }

        const q = (url.searchParams.get("q") || "").toLowerCase().trim();

        if (!q) {
          return new Response(
            JSON.stringify({ error: "Query is required" }),
            { status: 400, headers: { "Content-Type": "application/json", ...cors } }
          );
        }

  
        const mealsRes = await fetch(`${SUPABASE_URL}/rest/v1/meals?select=*`, {
          headers: {
            apikey: SUPABASE_KEY,
            Authorization: `Bearer ${SUPABASE_KEY}`
          }
        });

        const restaurantsRes = await fetch(`${SUPABASE_URL}/rest/v1/restaurants?select=*`, {
          headers: {
            apikey: SUPABASE_KEY,
            Authorization: `Bearer ${SUPABASE_KEY}`
          }
        });

        const meals = await mealsRes.json();
        const restaurants = await restaurantsRes.json();
        const nowMs = Date.now();
        const mealsWithOffers = await attachMealOffers(Array.isArray(meals) ? meals : [], { hideMealsWithActiveOffer: hideOfferMeals });
        const visibleMeals = mealsWithOffers.filter((m) => {
          const isAvailable = m?.is_available;
          if (typeof isAvailable === "boolean" && isAvailable === false) return false;
          const expRaw = typeof m?.expiry_time === "string" ? m.expiry_time : null;
          const expMs = expRaw ? Date.parse(expRaw) : NaN;
          if (Number.isFinite(expMs) && expMs <= nowMs) return false;
          return true;
        });
        const visibleRestaurants = (Array.isArray(restaurants) ? restaurants : []).filter((r) => {
          const isActive = r?.is_active;
          if (typeof isActive === "boolean") return isActive === true;
          return true;
        });

        const scoreMeal = (m) => {
          let score = 0;
          if ((m.title || "").toLowerCase().includes(q)) score += 3;
          if ((m.category || "").toLowerCase().includes(q)) score += 2;
          if ((m.cuisine || "").toLowerCase().includes(q)) score += 2;
          const mealTags = Array.isArray(m?.tags) ? m.tags : [];
          if (mealTags.some((tag) => typeof tag === "string" && tag.toLowerCase().includes(q))) score += 2;
          if ((m.description || "").toLowerCase().includes(q)) score += 1;
          return score;
       };

        const scoreRestaurant = (r) => {
          let score = 0;
          if ((r.name || "").toLowerCase().includes(q)) score += 3;
          if ((r.description || "").toLowerCase().includes(q)) score += 1;
          return score;
        };

        const filteredMeals = visibleMeals
          .map(m => ({ ...m, score: scoreMeal(m) }))
          .filter(m => m.score > 0)
          .sort((a, b) => b.score - a.score)
          .slice(0, 10);

        const filteredRestaurants = visibleRestaurants
          .map(r => ({ ...r, score: scoreRestaurant(r) }))
          .filter(r => r.score > 0)
          .sort((a, b) => b.score - a.score)
          .slice(0, 10);

        return new Response(
          JSON.stringify({
          meals: filteredMeals,
          restaurants: filteredRestaurants,
          total_meals: filteredMeals.length,
          total_restaurants: filteredRestaurants.length
        }),
        {
          status: 200,
          headers: {
          "Content-Type": "application/json",
          ...cors
          }
        }
        );
      }


    // Route not found
    return new Response("Route not found", { status: 404, headers: corsHeaders(request) });
  }
};
