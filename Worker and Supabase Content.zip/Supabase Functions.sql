
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'user_role') THEN
        CREATE TYPE user_role AS ENUM ('user', 'restaurant', 'charity');
    END IF;

    IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'meal_status') THEN
        CREATE TYPE meal_status AS ENUM ('available', 'ordered', 'unavailable', 'expired');
    END IF;

    IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'order_status') THEN
        CREATE TYPE order_status AS ENUM ('pending', 'approved', 'picked', 'cancelled');
    END IF;

    IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'pickup_status') THEN
        CREATE TYPE pickup_status AS ENUM ('pending', 'approved', 'rejected');
    END IF;
END $$;
ALTER TYPE pickup_status
ADD VALUE IF NOT EXISTS 'picked_up';


-- Add enum columns (if missing) and set defaults

ALTER TABLE profiles ADD COLUMN IF NOT EXISTS role user_role DEFAULT 'user';
ALTER TABLE meals ADD COLUMN IF NOT EXISTS status meal_status DEFAULT 'available';
ALTER TABLE orders ADD COLUMN IF NOT EXISTS status order_status DEFAULT 'pending';
ALTER TABLE pickup_requests ADD COLUMN IF NOT EXISTS status pickup_status DEFAULT 'pending';
ALTER TABLE donations ADD COLUMN IF NOT EXISTS picked_up pickup_status DEFAULT 'pending';

-- =========================================
--Add image columns (if missing)
-- =========================================
ALTER TABLE restaurants ADD COLUMN IF NOT EXISTS rest_img_url TEXT;
ALTER TABLE meals ADD COLUMN IF NOT EXISTS meal_img_url TEXT;
ALTER TABLE donations ADD COLUMN IF NOT EXISTS donation_img_url TEXT;

-- =========================================
--  Drop old constraints (safe)
-- =========================================
ALTER TABLE meals DROP CONSTRAINT IF EXISTS positive_price;
ALTER TABLE meals DROP CONSTRAINT IF EXISTS positive_quantity;
ALTER TABLE meals DROP CONSTRAINT IF EXISTS valid_expiry;

ALTER TABLE pickup_requests DROP CONSTRAINT IF EXISTS unique_pickup;

-- =========================================
--  Add constraints back
-- =========================================
ALTER TABLE meals ADD CONSTRAINT positive_price CHECK (price >= 0);
ALTER TABLE meals ADD CONSTRAINT positive_quantity CHECK (quantity >= 0);
ALTER TABLE meals ADD CONSTRAINT valid_expiry CHECK (expiry_time > created_at);

ALTER TABLE pickup_requests
ADD CONSTRAINT unique_pickup UNIQUE (donation_id, charity_id);



DROP FUNCTION IF EXISTS make_order_user_only(UUID, JSON);
CREATE FUNCTION make_order_user_only(
    p_user_id UUID,
    p_meals JSON
) RETURNS UUID AS $$
DECLARE
    new_order_id UUID;
    meal_record RECORD;
    user_role_check user_role;
BEGIN
    SELECT role INTO user_role_check FROM profiles WHERE id = p_user_id;
    IF user_role_check != 'user' THEN RAISE EXCEPTION 'Only users can place orders'; END IF;

    INSERT INTO orders(user_id, status) VALUES(p_user_id,'pending') RETURNING id INTO new_order_id;

    FOR meal_record IN SELECT * FROM json_to_recordset(p_meals) AS x(meal_id UUID, quantity INT)
    LOOP
        IF meal_record.quantity <= 0 THEN RAISE EXCEPTION 'Quantity must be greater than 0'; END IF;

        UPDATE meals SET quantity = quantity - meal_record.quantity
        WHERE id = meal_record.meal_id AND quantity >= meal_record.quantity AND status='available';
        IF NOT FOUND THEN RAISE EXCEPTION 'Meal not available or insufficient quantity'; END IF;

        INSERT INTO order_items(order_id, meal_id, quantity)
        VALUES(new_order_id, meal_record.meal_id, meal_record.quantity);

        UPDATE meals SET status='unavailable' WHERE id=meal_record.meal_id AND quantity=0;
    END LOOP;

    RETURN new_order_id;
END;
$$ LANGUAGE plpgsql;

-- =========================================
-- 4️⃣ CANCEL ORDER
-- =========================================
DROP FUNCTION IF EXISTS cancel_order_user_only(UUID, UUID);
CREATE FUNCTION cancel_order_user_only(
    p_order_id UUID,
    p_user_id UUID
) RETURNS UUID AS $$
DECLARE
    meal RECORD;
    owner_id UUID;
    user_role_check user_role;
BEGIN
    SELECT role INTO user_role_check FROM profiles WHERE id = p_user_id;
    IF user_role_check != 'user' THEN RAISE EXCEPTION 'Only users can cancel orders'; END IF;

    SELECT user_id INTO owner_id FROM orders WHERE id = p_order_id;
    IF owner_id IS NULL THEN RAISE EXCEPTION 'Order does not exist'; END IF;
    IF owner_id != p_user_id THEN RAISE EXCEPTION 'You are not allowed to cancel this order'; END IF;

    IF EXISTS (SELECT 1 FROM orders WHERE id=p_order_id AND status='cancelled') THEN
        RAISE EXCEPTION 'Order is already cancelled';
    END IF;

    UPDATE orders SET status='cancelled' WHERE id=p_order_id;

    FOR meal IN SELECT oi.meal_id, oi.quantity FROM order_items oi WHERE oi.order_id=p_order_id
    LOOP
        UPDATE meals SET quantity = quantity + meal.quantity, status='available' WHERE id = meal.meal_id;
    END LOOP;

    RETURN p_order_id;
END;
$$ LANGUAGE plpgsql;




-- Function: register_user
-- Purpose: Register a new profile with a role (user, charity, restaurant)
DROP FUNCTION IF EXISTS register_user(
    p_full_name TEXT,
    p_email TEXT,
    p_role user_role,
    p_firebase_uid TEXT
);

CREATE OR REPLACE FUNCTION register_user(
    p_full_name TEXT,
    p_email TEXT,
    p_role user_role,
    p_firebase_uid TEXT
) RETURNS UUID AS $$
DECLARE
    new_id UUID;
    restaurant_exists INT;
BEGIN
    -- Insert or update profile
    INSERT INTO profiles(full_name, email, role, firebase_uid)
    VALUES (p_full_name, p_email, p_role, p_firebase_uid)
    ON CONFLICT (firebase_uid) DO UPDATE
        SET full_name = EXCLUDED.full_name,
            email = EXCLUDED.email,
            role = EXCLUDED.role
    RETURNING id INTO new_id;

    -- If the role is restaurant, create an entry in restaurants table if not exists
    IF p_role = 'restaurant' THEN
        SELECT COUNT(*) INTO restaurant_exists
        FROM restaurants
        WHERE profile_id = new_id;

        IF restaurant_exists = 0 THEN
            INSERT INTO restaurants(profile_id, name, description, img_url)
            VALUES (new_id, p_full_name, NULL, NULL);
        END IF;
    END IF;

    RETURN new_id;
END;
$$ LANGUAGE plpgsql;

--restaurant add description
CREATE OR REPLACE FUNCTION update_restaurant_description(
    p_profile_id UUID,
    p_description TEXT
) RETURNS VOID AS $$
BEGIN
    UPDATE restaurants
    SET description = p_description
    WHERE profile_id = p_profile_id;
END;
$$ LANGUAGE plpgsql;

--restaurant add img
CREATE OR REPLACE FUNCTION update_restaurant_image(
    p_profile_id UUID,
    p_img_url TEXT
) RETURNS VOID AS $$
BEGIN
    UPDATE restaurants
    SET img_url = p_img_url
    WHERE profile_id = p_profile_id;
END;
$$ LANGUAGE plpgsql;


--update profile

CREATE OR REPLACE FUNCTION update_profile(
    p_profile_id UUID,
    p_full_name TEXT DEFAULT NULL,
    p_email TEXT DEFAULT NULL,
    p_name TEXT DEFAULT NULL,
    p_address TEXT DEFAULT NULL,
    p_description TEXT DEFAULT NULL,
    p_rest_img_url TEXT DEFAULT NULL
) RETURNS VOID AS $$
DECLARE
    v_role TEXT;
BEGIN
    -- get role of the profile
    SELECT role INTO v_role FROM profiles WHERE id = p_profile_id;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'Profile with id % not found', p_profile_id;
    END IF;

    -- update profiles table
    UPDATE profiles
    SET
        full_name = COALESCE(p_full_name, full_name),
        email = COALESCE(p_email, email)
    WHERE id = p_profile_id;

    -- if restaurant, also update restaurants table
    IF v_role = 'restaurant' THEN
        UPDATE restaurants
        SET
            name = COALESCE(p_name, name),
            address = COALESCE(p_address, address),
            description = COALESCE(p_description, description),
            rest_img_url = COALESCE(p_rest_img_url, rest_img_url)
        WHERE profile_id = p_profile_id;
    END IF;
END;
$$ LANGUAGE plpgsql;

DROP FUNCTION IF EXISTS restaurant_get_meals(UUID);
CREATE FUNCTION restaurant_get_meals(
    p_profile_id UUID
) RETURNS TABLE (
    id UUID,
    title TEXT,
    description TEXT,
    price INT,
    quantity INT,
    status meal_status,
    expiry_time TIMESTAMP,
    meal_img_url TEXT
) AS $$
BEGIN
    RETURN QUERY
    SELECT m.id, m.title, m.description, m.price, m.quantity, m.status, m.expiry_time, m.meal_img_url
    FROM meals m
    JOIN restaurants r ON r.id = m.restaurant_id
    WHERE r.profile_id=p_profile_id
    ORDER BY m.created_at DESC;
END;
$$ LANGUAGE plpgsql;

DROP FUNCTION IF EXISTS restaurant_add_meal(UUID, TEXT, TEXT, INT, INT, TIMESTAMP, TEXT);
CREATE FUNCTION restaurant_add_meal(
    p_profile_id UUID,
    p_title TEXT,
    p_description TEXT,
    p_quantity INT,
    p_price INT,
    p_expiry TIMESTAMP,
    p_meal_img_url TEXT
) RETURNS UUID AS $$
DECLARE
    v_restaurant_id UUID;
    new_meal_id UUID;
BEGIN
    -- Check mandatory image
    IF p_meal_img_url IS NULL OR LENGTH(TRIM(p_meal_img_url)) = 0 THEN
        RAISE EXCEPTION 'Meal image URL is mandatory';
    END IF;

    SELECT id INTO v_restaurant_id FROM restaurants WHERE profile_id=p_profile_id;
    IF v_restaurant_id IS NULL THEN RAISE EXCEPTION 'Restaurant not found'; END IF;

    INSERT INTO meals(restaurant_id,title,description,quantity,price,status,expiry_time,meal_img_url)
    VALUES(v_restaurant_id, p_title, p_description, p_quantity, p_price, 'available', p_expiry, p_meal_img_url)
    RETURNING id INTO new_meal_id;

    RETURN new_meal_id;
END;
$$ LANGUAGE plpgsql;

DROP FUNCTION IF EXISTS restaurant_update_meal(UUID, UUID, INT, INT, TIMESTAMP, TEXT);
CREATE FUNCTION restaurant_update_meal(
    p_profile_id UUID,
    p_meal_id UUID,
    p_quantity INT DEFAULT NULL,
    p_price INT DEFAULT NULL,
    p_expiry TIMESTAMP DEFAULT NULL,
    p_meal_img_url TEXT DEFAULT NULL
) RETURNS UUID AS $$
BEGIN
    UPDATE meals m
    SET quantity = COALESCE(p_quantity, m.quantity),
        price = COALESCE(p_price, m.price),
        expiry_time = COALESCE(p_expiry, m.expiry_time),
        meal_img_url = COALESCE(p_meal_img_url, m.meal_img_url)
    FROM restaurants r
    WHERE m.id=p_meal_id AND r.id=m.restaurant_id AND r.profile_id=p_profile_id;

    IF NOT FOUND THEN RAISE EXCEPTION 'Unauthorized or meal not found'; END IF;
    RETURN p_meal_id;
END;
$$ LANGUAGE plpgsql;

DROP FUNCTION IF EXISTS restaurant_delete_meal(UUID, UUID);
CREATE FUNCTION restaurant_delete_meal(
    p_profile_id UUID,
    p_meal_id UUID
) RETURNS UUID AS $$
BEGIN
    UPDATE meals m
    SET status='expired'
    FROM restaurants r
    WHERE m.id=p_meal_id AND r.id=m.restaurant_id AND r.profile_id=p_profile_id;

    IF NOT FOUND THEN RAISE EXCEPTION 'Unauthorized or meal not found'; END IF;
    RETURN p_meal_id;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE FUNCTION user_history(p_user_id UUID)
RETURNS TABLE (
    order_id UUID,
    meal_title TEXT,
    quantity INT,
    price INT,
    total_price INT,
    order_status order_status,
    ordered_at TIMESTAMP
) AS $$
BEGIN
    RETURN QUERY
    SELECT
        o.id AS order_id,
        m.title AS meal_title,
        om.quantity,
        m.price,
        om.quantity * m.price AS total_price,
        o.status AS order_status,
        o.created_at AS ordered_at
    FROM orders o
    JOIN order_meals om ON om.order_id = o.id
    JOIN meals m ON m.id = om.meal_id
    WHERE o.user_id = p_user_id
    ORDER BY o.created_at DESC;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION restaurant_statistics(p_profile_id UUID)
RETURNS JSON AS $$
DECLARE
    v_restaurant_id UUID;
    result JSON;
BEGIN
    -- get restaurant id from profile
    SELECT id INTO v_restaurant_id
    FROM restaurants
    WHERE profile_id = p_profile_id;

    SELECT json_build_object(
        'total_meals',
            (SELECT COUNT(*) FROM meals WHERE restaurant_id = v_restaurant_id),

        'active_meals',
            (SELECT COUNT(*) FROM meals
             WHERE restaurant_id = v_restaurant_id
             AND status = 'available'),

        'total_orders',
            (SELECT COUNT(*) FROM orders
             WHERE restaurant_id = v_restaurant_id),

        'total_items_sold',
            (SELECT COALESCE(SUM(quantity),0)
             FROM order_items oi
             JOIN orders o ON oi.order_id = o.id
             WHERE o.restaurant_id = v_restaurant_id),

        'total_revenue',
            (SELECT COALESCE(SUM(m.price * oi.quantity),0)
             FROM order_items oi
             JOIN meals m ON oi.meal_id = m.id
             JOIN orders o ON oi.order_id = o.id
             WHERE o.restaurant_id = v_restaurant_id
             AND o.status = 'completed'),

        'total_donations',
            (SELECT COUNT(*) FROM donations
             WHERE restaurant_id = v_restaurant_id),

        'completed_pickups',
            (SELECT COUNT(*) FROM pickup_requests pr
             JOIN donations d ON pr.donation_id = d.id
             WHERE d.restaurant_id = v_restaurant_id
             AND pr.status = 'confirmed')
    )
    INTO result;

    RETURN result;
END;
$$ LANGUAGE plpgsql;







CREATE OR REPLACE FUNCTION user_statistics(p_user_id UUID)
RETURNS JSON AS $$
DECLARE
    result JSON;
BEGIN
    SELECT json_build_object(
        'total_orders',
            (SELECT COUNT(*) FROM orders WHERE user_id = p_user_id),

        'completed_orders',
            (SELECT COUNT(*) FROM orders
             WHERE user_id = p_user_id
             AND status = 'completed'),

        'cancelled_orders',
            (SELECT COUNT(*) FROM orders
             WHERE user_id = p_user_id
             AND status = 'cancelled'),

        'total_meals_bought',
            (SELECT COALESCE(SUM(quantity),0)
             FROM order_items oi
             JOIN orders o ON oi.order_id = o.id
             WHERE o.user_id = p_user_id),

        'total_spent',
            (SELECT COALESCE(SUM(m.price * oi.quantity),0)
             FROM order_items oi
             JOIN meals m ON oi.meal_id = m.id
             JOIN orders o ON oi.order_id = o.id
             WHERE o.user_id = p_user_id
             AND o.status = 'completed')
    )
    INTO result;

    RETURN result;
END;
$$ LANGUAGE plpgsql;



CREATE OR REPLACE FUNCTION add_user_from_profile()
RETURNS TRIGGER AS $$
BEGIN
  IF NEW.role = 'user' THEN
    INSERT INTO users (user_id, firebase_uid)
    VALUES (NEW.id, NEW.firebase_uid)
    ON CONFLICT (user_id) DO NOTHING;
  END IF;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER auto_add_user
AFTER INSERT ON profiles
FOR EACH ROW
EXECUTE FUNCTION add_user_from_profile();



CREATE OR REPLACE FUNCTION create_restaurant_from_profile()
RETURNS trigger AS $$
BEGIN

  -- only act if role is restaurant
  IF NEW.role = 'restaurant' THEN

    INSERT INTO restaurants (
      profile_id,
      firebase_uid,
      name,
      created_at
    )
    VALUES (
      NEW.id,
      NEW.firebase_uid,
      NEW.full_name,
      NOW()
    );

  END IF;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER after_profile_insert
AFTER INSERT ON profiles
FOR EACH ROW
EXECUTE FUNCTION create_restaurant_from_profile();



create or replace function search_meals(
  p_query text default null,
  p_min_price numeric default null,
  p_max_price numeric default null
)
returns setof meals
language sql
as $$
  select *
  from meals
  where is_available = true
    and (
      p_query is null
      or p_query = ''
      or title ilike '%' || p_query || '%'
      or description ilike '%' || p_query || '%'
      or category ilike '%' || p_query || '%'
    )
    and (p_min_price is null or price >= p_min_price)
    and (p_max_price is null or price <= p_max_price);
$$;

create or replace function search_restaurants(p_query text)
returns setof restaurants
language sql
as $$
  select *
  from restaurants
  where
    p_query is null
    or p_query = ''
    or name ilike '%' || p_query || '%'
    or description ilike '%' || p_query || '%';
$$;


-- =========================================
-- ADD DONATION (UPDATED)
-- =========================================
DROP FUNCTION IF EXISTS add_donation(UUID, TEXT);
DROP FUNCTION IF EXISTS add_donation(UUID, TEXT, TEXT, TEXT);

CREATE OR REPLACE FUNCTION add_donation(
    p_profile_id UUID,
    p_donation_img_url TEXT,
    p_description TEXT DEFAULT NULL,
    p_pickup_location TEXT DEFAULT NULL
)
RETURNS UUID AS $$
DECLARE
    v_restaurant_id UUID;
    v_donation_id UUID;
BEGIN
    IF p_donation_img_url IS NULL OR LENGTH(TRIM(p_donation_img_url)) = 0 THEN
        RAISE EXCEPTION 'Donation image is required';
    END IF;

    SELECT id INTO v_restaurant_id
    FROM restaurants
    WHERE profile_id = p_profile_id;

    IF v_restaurant_id IS NULL THEN
        RAISE EXCEPTION 'Restaurant not found';
    END IF;

    INSERT INTO donations (
        restaurant_id,
        donation_img_url,
        picked_up,
        is_available,
        description,
        pickup_location
    )
    VALUES (
        v_restaurant_id,
        p_donation_img_url,
        'pending',
        TRUE,
        p_description,
        p_pickup_location
    )
    RETURNING id INTO v_donation_id;

    RETURN v_donation_id;
END;
$$ LANGUAGE plpgsql;


-- =========================================
-- UPDATED REMOVE DONATION
-- =========================================
DROP FUNCTION IF EXISTS remove_donation(UUID, UUID);

CREATE OR REPLACE FUNCTION remove_donation(
    p_profile_id UUID,
    p_donation_id UUID
)
RETURNS UUID AS $$
BEGIN
    -- delete donation items first
    DELETE FROM donation_items
    WHERE donation_id = p_donation_id;

    -- delete pickup requests
    DELETE FROM pickup_requests
    WHERE donation_id = p_donation_id;

    -- delete donation
    DELETE FROM donations d
    USING restaurants r
    WHERE d.restaurant_id = r.id
    AND r.profile_id = p_profile_id
    AND d.id = p_donation_id;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'Donation not found or unauthorized';
    END IF;

    RETURN p_donation_id;
END;
$$ LANGUAGE plpgsql;

-- =========================================
-- CHARITY REQUEST PICKUP
-- =========================================
DROP FUNCTION IF EXISTS request_pickup_charity(UUID, UUID);

CREATE OR REPLACE FUNCTION request_pickup_charity(
    p_charity_id UUID,
    p_donation_id UUID
)
RETURNS UUID AS $$
DECLARE
    v_role user_role;
    v_available BOOLEAN;
    v_pickup_id UUID;
BEGIN
    SELECT role INTO v_role
    FROM profiles
    WHERE id = p_charity_id;

    IF v_role != 'charity' THEN
        RAISE EXCEPTION 'Only charities can request pickup';
    END IF;

    SELECT is_available INTO v_available
    FROM donations
    WHERE id = p_donation_id;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'Donation not found';
    END IF;

    IF v_available = FALSE THEN
        RAISE EXCEPTION 'Donation is unavailable';
    END IF;

    IF EXISTS (
        SELECT 1
        FROM pickup_requests
        WHERE donation_id = p_donation_id
        AND charity_id = p_charity_id
        AND status = 'pending'
    ) THEN
        RAISE EXCEPTION 'Pickup request already pending';
    END IF;

    INSERT INTO pickup_requests (
        donation_id,
        charity_id,
        status
    )
    VALUES (
        p_donation_id,
        p_charity_id,
        'pending'
    )
    RETURNING id INTO v_pickup_id;

    RETURN v_pickup_id;
END;
$$ LANGUAGE plpgsql;


-- =========================================
-- RESTAURANT APPROVE PICKUP
-- =========================================
DROP FUNCTION IF EXISTS restaurant_approve_pickup(UUID, UUID);

CREATE OR REPLACE FUNCTION restaurant_approve_pickup(
    p_pickup_id UUID,
    p_profile_id UUID
)
RETURNS UUID AS $$
DECLARE
    v_donation_id UUID;
BEGIN
    SELECT pr.donation_id INTO v_donation_id
    FROM pickup_requests pr
    JOIN donations d ON d.id = pr.donation_id
    JOIN restaurants r ON r.id = d.restaurant_id
    WHERE pr.id = p_pickup_id
    AND r.profile_id = p_profile_id;

    IF v_donation_id IS NULL THEN
        RAISE EXCEPTION 'Unauthorized or request not found';
    END IF;

    UPDATE pickup_requests
    SET status = 'approved',
        updated_at = NOW()
    WHERE id = p_pickup_id;

    UPDATE pickup_requests
    SET status = 'rejected',
        updated_at = NOW()
    WHERE donation_id = v_donation_id
    AND id != p_pickup_id
    AND status = 'pending';

    UPDATE donations
    SET is_available = FALSE
    WHERE id = v_donation_id;

    RETURN p_pickup_id;
END;
$$ LANGUAGE plpgsql;


-- =========================================
-- RESTAURANT REJECT PICKUP
-- =========================================
DROP FUNCTION IF EXISTS restaurant_reject_pickup(UUID, UUID);

CREATE OR REPLACE FUNCTION restaurant_reject_pickup(
    p_pickup_id UUID,
    p_profile_id UUID
)
RETURNS UUID AS $$
DECLARE
    v_exists UUID;
BEGIN
    SELECT pr.id INTO v_exists
    FROM pickup_requests pr
    JOIN donations d ON d.id = pr.donation_id
    JOIN restaurants r ON r.id = d.restaurant_id
    WHERE pr.id = p_pickup_id
    AND r.profile_id = p_profile_id;

    IF v_exists IS NULL THEN
        RAISE EXCEPTION 'Unauthorized or request not found';
    END IF;

    UPDATE pickup_requests
    SET status = 'rejected',
        updated_at = NOW()
    WHERE id = p_pickup_id;

    RETURN p_pickup_id;
END;
$$ LANGUAGE plpgsql;


-- =========================================
-- CANCEL PICKUP REQUEST
-- =========================================
DROP FUNCTION IF EXISTS cancel_pickup_request(UUID, UUID);
CREATE OR REPLACE FUNCTION cancel_pickup_request(
    p_charity_id UUID,
    p_pickup_id UUID
)
RETURNS UUID AS $$
DECLARE
    v_status pickup_status;
    v_donation_id UUID;
BEGIN
    SELECT status, donation_id INTO v_status, v_donation_id
    FROM pickup_requests
    WHERE id = p_pickup_id
    AND charity_id = p_charity_id;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'Pickup request not found';
    END IF;

    IF v_status != 'pending' THEN
        RAISE EXCEPTION 'Only pending requests can be cancelled';
    END IF;

    UPDATE pickup_requests
    SET status = 'rejected',
        updated_at = NOW()
    WHERE id = p_pickup_id;

    -- Restore the donation to available
    UPDATE donations
    SET is_available = TRUE,
        picked_up = 'pending'
    WHERE id = v_donation_id;

    RETURN p_pickup_id;
END;
$$ LANGUAGE plpgsql;

-- =========================================
-- CHARITY CONFIRM PICKUP
-- =========================================
DROP FUNCTION IF EXISTS charity_confirm_pickup(UUID, UUID);

CREATE OR REPLACE FUNCTION charity_confirm_pickup(
    p_pickup_id UUID,
    p_charity_id UUID
)
RETURNS UUID AS $$
DECLARE
    v_donation_id UUID;
BEGIN
    SELECT donation_id INTO v_donation_id
    FROM pickup_requests
    WHERE id = p_pickup_id
      AND charity_id = p_charity_id
      AND status = 'approved';

    IF v_donation_id IS NULL THEN
        RAISE EXCEPTION 'Approved request not found';
    END IF;

    UPDATE donations
    SET
        picked_up = 'picked_up',
        is_available = FALSE
    WHERE id = v_donation_id;

    UPDATE pickup_requests
    SET status = 'picked_up',
        updated_at = NOW()
    WHERE id = p_pickup_id;

    RETURN p_pickup_id;
END;
$$ LANGUAGE plpgsql;


-- =========================================
-- CHARITY HISTORY
-- =========================================
DROP FUNCTION IF EXISTS charity_history(UUID);

CREATE OR REPLACE FUNCTION charity_history(
    p_charity_id UUID
)
RETURNS TABLE (
    donation_id UUID,
    restaurant_id UUID,
    donation_img_url TEXT,
    picked_up pickup_status,
    request_status pickup_status,
    request_date TIMESTAMP
) AS $$
BEGIN
    RETURN QUERY
    SELECT
        d.id,
        d.restaurant_id,
        d.donation_img_url,
        d.picked_up,
        pr.status,
        pr.created_at
    FROM pickup_requests pr
    JOIN donations d ON d.id = pr.donation_id
    WHERE pr.charity_id = p_charity_id
    ORDER BY pr.created_at DESC;
END;
$$ LANGUAGE plpgsql;


-- =========================================
-- GET AVAILABLE DONATIONS (with restaurant name)
-- =========================================
DROP FUNCTION IF EXISTS get_available_donations();

CREATE OR REPLACE FUNCTION get_available_donations()
RETURNS TABLE (
    id UUID,
    restaurant_id UUID,
    restaurant_name TEXT,
    created_at TIMESTAMP,
    donation_img_url TEXT,
    picked_up pickup_status,
    is_available BOOLEAN,
    description TEXT,
    pickup_location TEXT
)
LANGUAGE sql AS $$
    SELECT
        d.id,
        d.restaurant_id,
        r.name AS restaurant_name,
        d.created_at,
        d.donation_img_url,
        d.picked_up,
        d.is_available,
        d.description,
        d.pickup_location
    FROM donations d
    JOIN restaurants r ON r.id = d.restaurant_id
    WHERE d.is_available = TRUE
      AND d.picked_up = 'pending'
    ORDER BY d.created_at DESC;
$$;
-- =========================================
-- GET MY DONATIONS (UPDATED)
-- =========================================
DROP FUNCTION IF EXISTS get_my_donations(UUID);

CREATE OR REPLACE FUNCTION get_my_donations(
    p_profile_id UUID
)
RETURNS TABLE (
    donation_id UUID,
    donation_img_url TEXT,
    picked_up pickup_status,
    is_available BOOLEAN,
    created_at TIMESTAMP,
    description TEXT,
    pickup_location TEXT
)
LANGUAGE sql AS $$
    SELECT
        d.id,
        d.donation_img_url,
        d.picked_up,
        d.is_available,
        d.created_at,
        d.description,
        d.pickup_location
    FROM donations d
    JOIN restaurants r ON r.id = d.restaurant_id
    WHERE r.profile_id = p_profile_id
    ORDER BY d.created_at DESC;
$$;


-- =========================================
-- RESTAURANT DONATIONS HISTORY (UPDATED)
-- =========================================
DROP FUNCTION IF EXISTS restaurant_donations_history(UUID);

CREATE OR REPLACE FUNCTION restaurant_donations_history(
    p_profile_id UUID
)
RETURNS TABLE (
    donation_id UUID,
    donation_img_url TEXT,
    picked_up pickup_status,
    created_at TIMESTAMP,
    approved_charity UUID,
    request_status pickup_status,
    description TEXT,
    pickup_location TEXT
)
LANGUAGE plpgsql AS $$
BEGIN
    RETURN QUERY
    SELECT
        d.id,
        d.donation_img_url,
        d.picked_up,
        d.created_at,
        pr.charity_id,
        pr.status,
        d.description,
        d.pickup_location
    FROM donations d
    JOIN restaurants r ON r.id = d.restaurant_id
    LEFT JOIN pickup_requests pr
        ON pr.donation_id = d.id
    WHERE r.profile_id = p_profile_id
    ORDER BY d.created_at DESC;
END;
$$;
-- =========================================
-- GET DONATION ITEMS (CHARITY)
-- =========================================
DROP FUNCTION IF EXISTS get_donation_items(UUID);

CREATE OR REPLACE FUNCTION get_donation_items(
    p_donation_id UUID
)
RETURNS TABLE (
    item_id UUID,
    donation_id UUID,
    item_name TEXT,
    quantity INT,
    donation_item_img TEXT,
    description TEXT,
    created_at TIMESTAMP
)
LANGUAGE sql AS $$
    SELECT
        di.id,
        di.donation_id,
        di.item_name,
        di.quantity,
        di.donation_item_img,
        di.description,
        di.created_at
    FROM donation_items di
    JOIN donations d
        ON d.id = di.donation_id
    WHERE di.donation_id = p_donation_id
    ORDER BY di.created_at DESC;
$$;

-- =========================================
-- GET DONATION ITEMS (RESTAURANT)
-- =========================================
DROP FUNCTION IF EXISTS get_my_donation_items(UUID, UUID);

CREATE OR REPLACE FUNCTION get_my_donation_items(
    p_profile_id UUID,
    p_donation_id UUID
)
RETURNS TABLE (
    item_id UUID,
    donation_id UUID,
    item_name TEXT,
    quantity INT,
    donation_item_img TEXT,
    description TEXT,
    created_at TIMESTAMP
)
LANGUAGE plpgsql AS $$
DECLARE
    v_restaurant_id UUID;
BEGIN
    SELECT id INTO v_restaurant_id
    FROM restaurants
    WHERE profile_id = p_profile_id;

    IF v_restaurant_id IS NULL THEN
        RAISE EXCEPTION 'Restaurant not found';
    END IF;

    IF NOT EXISTS (
        SELECT 1
        FROM donations
        WHERE id = p_donation_id
        AND restaurant_id = v_restaurant_id
    ) THEN
        RAISE EXCEPTION 'Unauthorized access';
    END IF;

    RETURN QUERY
    SELECT
        di.id   AS item_id,
        di.donation_id,
        di.item_name,
        di.quantity,
        di.donation_item_img,
        di.description,
        di.created_at
    FROM donation_items di
    WHERE di.donation_id = p_donation_id
    ORDER BY di.created_at DESC;
END;
$$;
-- =========================================
-- REMOVE DONATION ITEM
-- =========================================
DROP FUNCTION IF EXISTS remove_donation_item(UUID, UUID);

CREATE OR REPLACE FUNCTION remove_donation_item(
    p_profile_id UUID,
    p_item_id UUID
)
RETURNS UUID AS $$
BEGIN
    DELETE FROM donation_items di
    USING donations d, restaurants r
    WHERE di.id = p_item_id
    AND di.donation_id = d.id
    AND d.restaurant_id = r.id
    AND r.profile_id = p_profile_id;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'Donation item not found or unauthorized';
    END IF;

    RETURN p_item_id;
END;
$$ LANGUAGE plpgsql;

-- =========================================
-- ADD DONATION ITEM
-- =========================================
DROP FUNCTION IF EXISTS add_donation_item(UUID, UUID, TEXT, INT, TEXT, TEXT);

CREATE OR REPLACE FUNCTION add_donation_item(
    p_profile_id UUID,
    p_donation_id UUID,
    p_item_name TEXT,
    p_quantity INT,
    p_donation_item_img TEXT,
    p_description TEXT DEFAULT NULL
)
RETURNS UUID AS $$
DECLARE
    v_restaurant_id UUID;
    v_item_id UUID;
BEGIN
    -- get restaurant
    SELECT id INTO v_restaurant_id
    FROM restaurants
    WHERE profile_id = p_profile_id;

    IF v_restaurant_id IS NULL THEN
        RAISE EXCEPTION 'Restaurant not found';
    END IF;

    -- verify donation belongs to restaurant
    IF NOT EXISTS (
        SELECT 1
        FROM donations
        WHERE id = p_donation_id
        AND restaurant_id = v_restaurant_id
    ) THEN
        RAISE EXCEPTION 'Unauthorized donation access';
    END IF;

    IF p_quantity <= 0 THEN
        RAISE EXCEPTION 'Quantity must be greater than 0';
    END IF;

    INSERT INTO donation_items (
        donation_id,
        item_name,
        quantity,
        donation_item_img,
        description
    )
    VALUES (
        p_donation_id,
        p_item_name,
        p_quantity,
        p_donation_item_img,
        p_description
    )
    RETURNING id INTO v_item_id;

    RETURN v_item_id;
END;
$$ LANGUAGE plpgsql;


-- =========================================
-- ENUMS
-- =========================================
DO $$ BEGIN
  CREATE TYPE schedule_status AS ENUM ('pending','confirmed','cancelled','completed');
EXCEPTION WHEN duplicate_object THEN null; END $$;

DO $$ BEGIN
  CREATE TYPE notification_type AS ENUM (
    'new_donation',
    'new_pickup_request',
    'pickup_approved',
    'pickup_rejected',
    'pickup_confirmed',
    'pickup_reminder',
    'system'
  );
EXCEPTION WHEN duplicate_object THEN
  -- Add missing values to existing enum
  ALTER TYPE notification_type ADD VALUE IF NOT EXISTS 'new_pickup_request';
  ALTER TYPE notification_type ADD VALUE IF NOT EXISTS 'pickup_rejected';
  ALTER TYPE notification_type ADD VALUE IF NOT EXISTS 'pickup_confirmed';
END $$;

-- =========================================
-- TABLE: pickup_schedules
-- =========================================
CREATE TABLE IF NOT EXISTS pickup_schedules (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  pickup_request_id  UUID NOT NULL REFERENCES pickup_requests(id) ON DELETE CASCADE,
  scheduled_at       TIMESTAMPTZ NOT NULL,
  notes              TEXT,
  status             schedule_status NOT NULL DEFAULT 'pending',
  confirmed_at       TIMESTAMPTZ,
  created_at         TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at         TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_pickup_schedules_request
  ON pickup_schedules(pickup_request_id);
CREATE INDEX IF NOT EXISTS idx_pickup_schedules_scheduled_at
  ON pickup_schedules(scheduled_at);


-- =========================================
-- TABLE: notifications
-- =========================================
CREATE TABLE IF NOT EXISTS notifications (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  profile_id  UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  type        notification_type NOT NULL,
  title       TEXT NOT NULL,
  body        TEXT NOT NULL,
  link_path   TEXT,           -- e.g. '/admin/donations' or '/charity/pickups'
  read_at     TIMESTAMPTZ,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_notifications_profile
  ON notifications(profile_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_notifications_unread
  ON notifications(profile_id) WHERE read_at IS NULL;


-- =========================================
-- TABLE: push_subscriptions
-- =========================================
CREATE TABLE IF NOT EXISTS push_subscriptions (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  profile_id  UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  endpoint    TEXT NOT NULL UNIQUE,
  p256dh      TEXT NOT NULL,
  auth        TEXT NOT NULL,
  user_agent  TEXT,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_push_subscriptions_profile
  ON push_subscriptions(profile_id);


-- =========================================
-- FUNCTION: schedule_pickup
-- Called by restaurant when approving + proposing a time
-- =========================================
DROP FUNCTION IF EXISTS schedule_pickup(UUID, UUID, TIMESTAMPTZ, TEXT);

CREATE OR REPLACE FUNCTION schedule_pickup(
  p_profile_id       UUID,
  p_pickup_request_id UUID,
  p_scheduled_at     TIMESTAMPTZ,
  p_notes            TEXT DEFAULT NULL
)
RETURNS UUID AS $$
DECLARE
  v_restaurant_id UUID;
  v_donation_id   UUID;
  v_schedule_id   UUID;
BEGIN
  -- verify caller owns the pickup's donation
  SELECT pr.donation_id INTO v_donation_id
  FROM pickup_requests pr
  JOIN donations d      ON d.id = pr.donation_id
  JOIN restaurants r    ON r.id = d.restaurant_id
  WHERE pr.id = p_pickup_request_id
    AND r.profile_id = p_profile_id;

  IF v_donation_id IS NULL THEN
    RAISE EXCEPTION 'Unauthorized or pickup request not found';
  END IF;

  -- cancel any existing pending schedule for this request
  UPDATE pickup_schedules
  SET status = 'cancelled', updated_at = NOW()
  WHERE pickup_request_id = p_pickup_request_id
    AND status = 'pending';

  INSERT INTO pickup_schedules (
    pickup_request_id, scheduled_at, notes, status
  ) VALUES (
    p_pickup_request_id, p_scheduled_at, p_notes, 'pending'
  ) RETURNING id INTO v_schedule_id;

  RETURN v_schedule_id;
END;
$$ LANGUAGE plpgsql;


-- =========================================
-- FUNCTION: confirm_schedule (charity side)
-- =========================================
DROP FUNCTION IF EXISTS confirm_schedule(UUID, UUID);

CREATE OR REPLACE FUNCTION confirm_schedule(
  p_profile_id  UUID,
  p_schedule_id UUID
)
RETURNS UUID AS $$
DECLARE
  v_request_id UUID;
BEGIN
  -- verify charity owns the pickup request tied to this schedule
  SELECT ps.pickup_request_id INTO v_request_id
  FROM pickup_schedules ps
  JOIN pickup_requests pr ON pr.id = ps.pickup_request_id
  WHERE ps.id = p_schedule_id
    AND pr.charity_id = p_profile_id
    AND ps.status = 'pending';

  IF v_request_id IS NULL THEN
    RAISE EXCEPTION 'Schedule not found or not yours';
  END IF;

  UPDATE pickup_schedules
  SET status = 'confirmed', confirmed_at = NOW(), updated_at = NOW()
  WHERE id = p_schedule_id;

  RETURN p_schedule_id;
END;
$$ LANGUAGE plpgsql;


-- =========================================
-- FUNCTION: cancel_schedule
-- Either party can cancel
-- =========================================
DROP FUNCTION IF EXISTS cancel_schedule(UUID, UUID);

CREATE OR REPLACE FUNCTION cancel_schedule(
  p_profile_id  UUID,
  p_schedule_id UUID
)
RETURNS UUID AS $$
DECLARE
  v_found UUID;
BEGIN
  -- restaurant path
  SELECT ps.id INTO v_found
  FROM pickup_schedules ps
  JOIN pickup_requests pr ON pr.id = ps.pickup_request_id
  JOIN donations d         ON d.id  = pr.donation_id
  JOIN restaurants r       ON r.id  = d.restaurant_id
  WHERE ps.id = p_schedule_id
    AND r.profile_id = p_profile_id
    AND ps.status IN ('pending','confirmed');

  IF v_found IS NULL THEN
    -- charity path
    SELECT ps.id INTO v_found
    FROM pickup_schedules ps
    JOIN pickup_requests pr ON pr.id = ps.pickup_request_id
    WHERE ps.id = p_schedule_id
      AND pr.charity_id = p_profile_id
      AND ps.status IN ('pending','confirmed');
  END IF;

  IF v_found IS NULL THEN
    RAISE EXCEPTION 'Schedule not found or cannot be cancelled';
  END IF;

  UPDATE pickup_schedules
  SET status = 'cancelled', updated_at = NOW()
  WHERE id = p_schedule_id;

  RETURN p_schedule_id;
END;
$$ LANGUAGE plpgsql;


-- =========================================
-- FUNCTION: create_notification
-- =========================================
DROP FUNCTION IF EXISTS create_notification(UUID, notification_type, TEXT, TEXT, TEXT);

CREATE OR REPLACE FUNCTION create_notification(
  p_profile_id UUID,
  p_type       notification_type,
  p_title      TEXT,
  p_body       TEXT,
  p_link_path  TEXT DEFAULT NULL
)
RETURNS UUID AS $$
DECLARE
  v_id UUID;
BEGIN
  INSERT INTO notifications (profile_id, type, title, body, link_path)
  VALUES (p_profile_id, p_type, p_title, p_body, p_link_path)
  RETURNING id INTO v_id;
  RETURN v_id;
END;
$$ LANGUAGE plpgsql;


-- =========================================
-- FUNCTION: mark_notifications_read
-- =========================================
DROP FUNCTION IF EXISTS mark_notifications_read(UUID, UUID[]);

CREATE OR REPLACE FUNCTION mark_notifications_read(
  p_profile_id       UUID,
  p_notification_ids UUID[]
)
RETURNS INT AS $$
DECLARE
  v_count INT;
BEGIN
  UPDATE notifications
  SET read_at = NOW()
  WHERE profile_id = p_profile_id
    AND id = ANY(p_notification_ids)
    AND read_at IS NULL;
  GET DIAGNOSTICS v_count = ROW_COUNT;
  RETURN v_count;
END;
$$ LANGUAGE plpgsql;

-- Drop the duplicate trigger first to avoid "already exists" error
DROP TRIGGER IF EXISTS trg_auto_create_charity ON profiles;

-- Recreate function + trigger once
CREATE OR REPLACE FUNCTION auto_create_charity_row()
RETURNS TRIGGER AS $$
BEGIN
  IF NEW.role = 'charity' THEN
    INSERT INTO charity (profile_id)
    VALUES (NEW.id)
    ON CONFLICT (profile_id) DO NOTHING;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_auto_create_charity
AFTER INSERT ON profiles
FOR EACH ROW EXECUTE FUNCTION auto_create_charity_row();

-- RPC function (CREATE OR REPLACE handles duplicates fine)
CREATE OR REPLACE FUNCTION ensure_charity_profile(
  p_profile_id uuid
) RETURNS void AS $$
BEGIN
  INSERT INTO charity (profile_id)
  VALUES (p_profile_id)
  ON CONFLICT (profile_id) DO NOTHING;
END;
$$ LANGUAGE plpgsql;

-- Fix the default + add unique constraint





