-- WARNING: This schema is for context only and is not meant to be run.
-- Table order and constraints may not be valid for execution.

CREATE TABLE public.profiles (
  id uuid NOT NULL DEFAULT gen_random_uuid(),
  firebase_uid text NOT NULL,
  full_name text NOT NULL,
  email text NOT NULL UNIQUE,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  role text NOT NULL,
  CONSTRAINT profiles_pkey PRIMARY KEY (id)
);
CREATE TABLE public.restaurants (
  id uuid NOT NULL DEFAULT gen_random_uuid(),
  profile_id uuid NOT NULL UNIQUE,
  name text NOT NULL,
  address text,
  description text,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  rest_img_url text,
  is_active boolean NOT NULL DEFAULT true,
  accepting_orders boolean NOT NULL DEFAULT true,
  img_url text,
  is_accepting_orders boolean NOT NULL DEFAULT true,
  pause_reason text,
  accepting_orders_updated_at timestamp with time zone,
  CONSTRAINT restaurants_pkey PRIMARY KEY (id),
  CONSTRAINT restaurants_profile_id_fkey FOREIGN KEY (profile_id) REFERENCES public.profiles(id)
);
CREATE TABLE public.meals (
  id uuid NOT NULL DEFAULT gen_random_uuid(),
  restaurant_id uuid NOT NULL,
  title text NOT NULL,
  description text,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  expiry_time timestamp with time zone,
  price integer NOT NULL CHECK (price >= 0),
  quantity integer NOT NULL CHECK (quantity >= 0),
  meal_img_url text,
  meal_status text,
  status USER-DEFINED DEFAULT 'available'::meal_status,
  category text CHECK (category IS NULL OR (category = ANY (ARRAY['burgers'::text, 'pizza'::text, 'fried_chicken'::text, 'shawarma'::text, 'grills'::text, 'sandwiches'::text, 'wraps'::text, 'koshary'::text, 'pasta'::text, 'rice_bowls'::text, 'salads'::text, 'soups'::text, 'breakfast'::text, 'desserts'::text, 'bakery'::text, 'coffee'::text, 'drinks'::text, 'snacks'::text, 'seafood_meals'::text, 'healthy_meals'::text, 'crepes'::text, 'waffles'::text, 'ice_cream'::text, 'hot_dogs'::text, 'manakish'::text]))),
  is_available boolean NOT NULL DEFAULT true,
  avg_rating numeric NOT NULL DEFAULT 0,
  rating_count integer NOT NULL DEFAULT 0,
  cuisine text CHECK (cuisine IS NULL OR (cuisine = ANY (ARRAY['american'::text, 'egyptian'::text, 'syrian'::text, 'italian'::text, 'levant'::text, 'turkish'::text, 'indian'::text, 'mexican'::text, 'asian'::text, 'chinese'::text, 'japanese'::text, 'international'::text]))),
  tags ARRAY NOT NULL DEFAULT '{}'::text[] CHECK (tags <@ ARRAY['spicy'::text, 'breakfast'::text, 'healthy'::text, 'budget_friendly'::text, 'popular'::text, 'high_protein'::text, 'low_calorie'::text, 'vegetarian'::text, 'vegan'::text, 'kids_friendly'::text, 'family_meal'::text, 'sweet'::text, 'savory'::text, 'cheesy'::text, 'crispy'::text, 'grilled'::text, 'fried'::text, 'cold_drink'::text, 'hot_drink'::text, 'late_night'::text]),
  CONSTRAINT meals_pkey PRIMARY KEY (id),
  CONSTRAINT meals_restaurant_id_fkey FOREIGN KEY (restaurant_id) REFERENCES public.restaurants(id)
);
CREATE TABLE public.orders (
  id uuid NOT NULL DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  restaurant_id uuid NOT NULL,
  status USER-DEFINED DEFAULT 'pending'::order_status,
  address text,
  area text,
  customer_name text,
  customer_phone text,
  idempotency_key text,
  CONSTRAINT orders_pkey PRIMARY KEY (id),
  CONSTRAINT orders_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.profiles(id),
  CONSTRAINT orders_restaurant_id_fkey FOREIGN KEY (restaurant_id) REFERENCES public.restaurants(id)
);
CREATE TABLE public.donations (
  id uuid NOT NULL DEFAULT gen_random_uuid(),
  restaurant_id uuid NOT NULL,
  created_at timestamp with time zone,
  donation_img_url text,
  picked_up USER-DEFINED DEFAULT 'pending'::pickup_status,
  is_available boolean,
  description text,
  pickup_location text,
  CONSTRAINT donations_pkey PRIMARY KEY (id),
  CONSTRAINT donations_restaurant_id_fkey FOREIGN KEY (restaurant_id) REFERENCES public.restaurants(id)
);
CREATE TABLE public.order_items (
  id uuid NOT NULL DEFAULT gen_random_uuid(),
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  order_id uuid NOT NULL,
  meal_id uuid,
  quantity integer NOT NULL,
  meal_title text,
  unit_price integer,
  meal_img_url text,
  category text,
  offer_id uuid,
  item_type text NOT NULL DEFAULT 'meal'::text,
  CONSTRAINT order_items_pkey PRIMARY KEY (id),
  CONSTRAINT order_items_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.orders(id),
  CONSTRAINT order_items_meal_id_fkey FOREIGN KEY (meal_id) REFERENCES public.meals(id),
  CONSTRAINT order_items_offer_id_fkey FOREIGN KEY (offer_id) REFERENCES public.offers(id)
);
CREATE TABLE public.demand_predictions (
  id uuid NOT NULL DEFAULT gen_random_uuid(),
  restaurant_id uuid NOT NULL,
  prediction_date date NOT NULL,
  predicted_visitors smallint NOT NULL,
  demand_level text NOT NULL,
  created_at timestamp without time zone NOT NULL DEFAULT now(),
  day_of_week_num integer NOT NULL,
  is_weekend boolean NOT NULL,
  holiday_flg boolean NOT NULL,
  lag_7 integer,
  rolling_mean_7 double precision,
  day_of_week text NOT NULL,
  predicted_orders integer NOT NULL,
  order_level text NOT NULL,
  is_ramadan boolean NOT NULL,
  CONSTRAINT demand_predictions_pkey PRIMARY KEY (id),
  CONSTRAINT demand_predictions_restaurant_id_fkey FOREIGN KEY (restaurant_id) REFERENCES public.restaurants(id)
);
CREATE TABLE public.chat_sessions (
  id uuid NOT NULL DEFAULT gen_random_uuid(),
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  last_search_query text NOT NULL DEFAULT ''::text,
  language text,
  profile_id uuid NOT NULL,
  CONSTRAINT chat_sessions_pkey PRIMARY KEY (id),
  CONSTRAINT chat_sessions_profile_id_fkey FOREIGN KEY (profile_id) REFERENCES public.profiles(id)
);
CREATE TABLE public.chat_messages (
  id uuid NOT NULL DEFAULT gen_random_uuid(),
  session_id uuid NOT NULL,
  role text NOT NULL CHECK (role = ANY (ARRAY['user'::text, 'assistant'::text, 'system'::text])),
  content text NOT NULL,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  CONSTRAINT chat_messages_pkey PRIMARY KEY (id),
  CONSTRAINT chat_messages_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.chat_sessions(id)
);
CREATE TABLE public.meals_reco (
  meal_id bigint GENERATED ALWAYS AS IDENTITY NOT NULL,
  restaurant_id text NOT NULL,
  name text,
  ingredients text,
  category text,
  price integer,
  discount boolean,
  expiry timestamp with time zone,
  tags text,
  description text,
  CONSTRAINT meals_reco_pkey PRIMARY KEY (meal_id)
);
CREATE TABLE public.interactions (
  profile_id uuid NOT NULL,
  meal_id uuid NOT NULL,
  timestamp timestamp with time zone NOT NULL DEFAULT now(),
  action text,
  CONSTRAINT interactions_pkey PRIMARY KEY (profile_id, meal_id, timestamp),
  CONSTRAINT interactions_profile_id_fkey FOREIGN KEY (profile_id) REFERENCES public.profiles(id),
  CONSTRAINT interactions_meal_id_fkey FOREIGN KEY (meal_id) REFERENCES public.meals(id)
);
CREATE TABLE public.users (
  user_id uuid NOT NULL DEFAULT gen_random_uuid(),
  signup timestamp with time zone NOT NULL DEFAULT now(),
  lat text,
  ion text,
  pref text,
  firebase_uid text,
  CONSTRAINT users_pkey PRIMARY KEY (user_id),
  CONSTRAINT users_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.profiles(id)
);
CREATE TABLE public.cart_items (
  id uuid NOT NULL DEFAULT gen_random_uuid(),
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now(),
  user_id uuid NOT NULL,
  meal_id uuid,
  quantity integer NOT NULL CHECK (quantity > 0),
  meal_title text,
  unit_price integer,
  meal_img_url text,
  category text,
  offer_id uuid,
  item_type text NOT NULL DEFAULT 'meal'::text,
  CONSTRAINT cart_items_pkey PRIMARY KEY (id),
  CONSTRAINT cart_items_offer_id_fkey FOREIGN KEY (offer_id) REFERENCES public.offers(id),
  CONSTRAINT cart_items_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.profiles(id),
  CONSTRAINT cart_items_meal_id_fkey FOREIGN KEY (meal_id) REFERENCES public.meals(id)
);
CREATE TABLE public.order_status_events (
  id uuid NOT NULL DEFAULT gen_random_uuid(),
  order_id uuid NOT NULL,
  old_status USER-DEFINED,
  new_status USER-DEFINED NOT NULL,
  actor_profile_id uuid,
  actor_role text NOT NULL,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  CONSTRAINT order_status_events_pkey PRIMARY KEY (id),
  CONSTRAINT order_status_events_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.orders(id),
  CONSTRAINT order_status_events_actor_profile_id_fkey FOREIGN KEY (actor_profile_id) REFERENCES public.profiles(id)
);
CREATE TABLE public.pickup_requests (
  id uuid NOT NULL DEFAULT gen_random_uuid(),
  donation_id uuid NOT NULL,
  charity_id uuid NOT NULL,
  status USER-DEFINED DEFAULT 'pending'::pickup_status,
  created_at timestamp without time zone DEFAULT now(),
  updated_at timestamp without time zone DEFAULT now(),
  CONSTRAINT pickup_requests_pkey PRIMARY KEY (id),
  CONSTRAINT pickup_requests_donation_id_fkey FOREIGN KEY (donation_id) REFERENCES public.donations(id),
  CONSTRAINT pickup_requests_charity_id_fkey FOREIGN KEY (charity_id) REFERENCES public.profiles(id)
);
CREATE TABLE public.analytics_events (
  id uuid NOT NULL DEFAULT gen_random_uuid(),
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  event_type text NOT NULL,
  session_id text,
  restaurant_id uuid,
  CONSTRAINT analytics_events_pkey PRIMARY KEY (id),
  CONSTRAINT analytics_events_restaurant_id_fkey FOREIGN KEY (restaurant_id) REFERENCES public.restaurants(id)
);
CREATE TABLE public.calendar_flags (
  prediction_date date NOT NULL,
  day_of_week text NOT NULL,
  day_of_week_num integer NOT NULL,
  is_weekend boolean NOT NULL,
  holiday_flg boolean NOT NULL,
  is_ramadan boolean NOT NULL,
  holiday_name text,
  holiday_name_ar text,
  holiday_group text,
  notes text,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  CONSTRAINT calendar_flags_pkey PRIMARY KEY (prediction_date)
);
CREATE TABLE public.user_recommendation_cache (
  profile_id uuid NOT NULL,
  topn integer NOT NULL,
  candidate_limit integer NOT NULL,
  meal_ids jsonb NOT NULL,
  strategy text,
  generated_at timestamp with time zone NOT NULL DEFAULT now(),
  expires_at timestamp with time zone NOT NULL,
  cache_key text,
  CONSTRAINT user_recommendation_cache_pkey PRIMARY KEY (profile_id, topn, candidate_limit),
  CONSTRAINT user_recommendation_cache_profile_id_fkey FOREIGN KEY (profile_id) REFERENCES public.profiles(id)
);
CREATE TABLE public.pickup_schedules (
  id uuid NOT NULL DEFAULT gen_random_uuid(),
  pickup_request_id uuid NOT NULL,
  scheduled_at timestamp with time zone NOT NULL,
  notes text,
  status USER-DEFINED NOT NULL DEFAULT 'pending'::schedule_status,
  confirmed_at timestamp with time zone,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now(),
  CONSTRAINT pickup_schedules_pkey PRIMARY KEY (id),
  CONSTRAINT pickup_schedules_pickup_request_id_fkey FOREIGN KEY (pickup_request_id) REFERENCES public.pickup_requests(id)
);
CREATE TABLE public.notifications (
  id uuid NOT NULL DEFAULT gen_random_uuid(),
  profile_id uuid NOT NULL,
  type USER-DEFINED NOT NULL,
  title text NOT NULL,
  body text NOT NULL,
  link_path text,
  read_at timestamp with time zone,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  CONSTRAINT notifications_pkey PRIMARY KEY (id),
  CONSTRAINT notifications_profile_id_fkey FOREIGN KEY (profile_id) REFERENCES public.profiles(id)
);
CREATE TABLE public.push_subscriptions (
  id uuid NOT NULL DEFAULT gen_random_uuid(),
  profile_id uuid NOT NULL,
  endpoint text NOT NULL UNIQUE,
  p256dh text NOT NULL,
  auth text NOT NULL,
  user_agent text,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  CONSTRAINT push_subscriptions_pkey PRIMARY KEY (id),
  CONSTRAINT push_subscriptions_profile_id_fkey FOREIGN KEY (profile_id) REFERENCES public.profiles(id)
);
CREATE TABLE public.charity (
  id uuid NOT NULL DEFAULT gen_random_uuid(),
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  profile_id uuid UNIQUE,
  name text,
  description text,
  charity_img_url text,
  address text,
  is_active boolean DEFAULT true,
  email text,
  phone text,
  website text,
  CONSTRAINT charity_pkey PRIMARY KEY (id),
  CONSTRAINT charity_profile_id_fkey FOREIGN KEY (profile_id) REFERENCES public.profiles(id)
);
CREATE TABLE public.donation_items (
  id uuid NOT NULL DEFAULT gen_random_uuid(),
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  donation_id uuid,
  description text,
  donation_item_img text,
  item_name text,
  quantity smallint,
  CONSTRAINT donation_items_pkey PRIMARY KEY (id),
  CONSTRAINT donation_items_donation_id_fkey FOREIGN KEY (donation_id) REFERENCES public.donations(id)
);
CREATE TABLE public.meal_likes (
  id uuid NOT NULL DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  meal_id uuid NOT NULL,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  CONSTRAINT meal_likes_pkey PRIMARY KEY (id),
  CONSTRAINT meal_likes_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.profiles(id),
  CONSTRAINT meal_likes_meal_id_fkey FOREIGN KEY (meal_id) REFERENCES public.meals(id)
);
CREATE TABLE public.meal_ratings (
  id uuid NOT NULL DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  meal_id uuid NOT NULL,
  rating numeric NOT NULL CHECK (rating >= 1::numeric AND rating <= 5::numeric),
  review_text text,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now(),
  CONSTRAINT meal_ratings_pkey PRIMARY KEY (id),
  CONSTRAINT meal_ratings_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.profiles(id),
  CONSTRAINT meal_ratings_meal_id_fkey FOREIGN KEY (meal_id) REFERENCES public.meals(id)
);
CREATE TABLE public.meal_views (
  id uuid NOT NULL DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  meal_id uuid NOT NULL,
  view_count integer NOT NULL DEFAULT 1,
  first_viewed_at timestamp with time zone NOT NULL DEFAULT now(),
  last_viewed_at timestamp with time zone NOT NULL DEFAULT now(),
  CONSTRAINT meal_views_pkey PRIMARY KEY (id),
  CONSTRAINT meal_views_meal_id_fkey FOREIGN KEY (meal_id) REFERENCES public.meals(id),
  CONSTRAINT meal_views_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.profiles(id)
);
CREATE TABLE public.meal_affinities (
  id uuid NOT NULL DEFAULT gen_random_uuid(),
  source_meal_id uuid NOT NULL,
  target_meal_id uuid NOT NULL,
  score numeric NOT NULL CHECK (score >= 0::numeric),
  support_count integer NOT NULL DEFAULT 0,
  window_days integer NOT NULL DEFAULT 60,
  updated_at timestamp with time zone NOT NULL DEFAULT now(),
  CONSTRAINT meal_affinities_pkey PRIMARY KEY (id),
  CONSTRAINT meal_affinities_source_meal_id_fkey FOREIGN KEY (source_meal_id) REFERENCES public.meals(id),
  CONSTRAINT meal_affinities_target_meal_id_fkey FOREIGN KEY (target_meal_id) REFERENCES public.meals(id)
);
CREATE TABLE public.restaurant_opening_hours (
  id uuid NOT NULL DEFAULT gen_random_uuid(),
  restaurant_id uuid NOT NULL,
  day_of_week smallint NOT NULL CHECK (day_of_week >= 0 AND day_of_week <= 6),
  open_time time without time zone,
  close_time time without time zone,
  is_closed boolean NOT NULL DEFAULT false,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now(),
  CONSTRAINT restaurant_opening_hours_pkey PRIMARY KEY (id),
  CONSTRAINT restaurant_opening_hours_restaurant_id_fkey FOREIGN KEY (restaurant_id) REFERENCES public.restaurants(id)
);
CREATE TABLE public.offers (
  id uuid NOT NULL DEFAULT gen_random_uuid(),
  restaurant_id uuid NOT NULL,
  meal_id uuid,
  title text NOT NULL,
  description text,
  offer_img_url text,
  original_price numeric NOT NULL CHECK (original_price >= 0::numeric),
  offer_price numeric NOT NULL CHECK (offer_price >= 0::numeric),
  quantity integer CHECK (quantity IS NULL OR quantity >= 0),
  is_active boolean NOT NULL DEFAULT true,
  category text,
  cuisine text,
  tags jsonb NOT NULL DEFAULT '[]'::jsonb CHECK (jsonb_typeof(tags) = 'array'::text),
  starts_at timestamp with time zone,
  expires_at timestamp with time zone,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now(),
  CONSTRAINT offers_pkey PRIMARY KEY (id),
  CONSTRAINT offers_restaurant_id_fkey FOREIGN KEY (restaurant_id) REFERENCES public.restaurants(id),
  CONSTRAINT offers_meal_id_fkey FOREIGN KEY (meal_id) REFERENCES public.meals(id)
);