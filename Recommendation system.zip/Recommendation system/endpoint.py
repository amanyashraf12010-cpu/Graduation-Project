"""
Food Recommendation Engine — v2
Improvements over v1:
  - Time-of-day meal-period awareness (breakfast / lunch / dinner / late-night)
  - Collaborative filtering via co-purchase affinity matrix
  - Diversity enforcement (max N meals per restaurant in top-K)
  - Richer signal ingestion: ratings, explicit likes, search history, views
  - Two-stage pipeline: candidate generation → re-ranking
  - Fine-grained cache keys (includes meal_period + strategy_hint)
  - Background-safe async-friendly structure (sync wrappers kept for FastAPI)
  - Configurable scoring weights via env vars
  - A/B strategy routing stub
"""

import hashlib
import logging
import math
import os
from collections import defaultdict
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, List, Optional, Tuple
from zoneinfo import ZoneInfo

from fastapi import Body, FastAPI, Header, HTTPException, Query
from supabase import Client, create_client

app = FastAPI(title="Food Recommendation API v2")
logger = logging.getLogger("food-recommender")

CACHE_TABLE = os.getenv("RECOMMEND_CACHE_TABLE", "user_recommendation_cache")

# ── Scoring weights (tunable via env) ────────────────────────────────────────
W_RESTAURANT    = float(os.getenv("W_RESTAURANT",    "0.15"))
W_CATEGORY      = float(os.getenv("W_CATEGORY",      "0.45"))
W_COLLAB        = float(os.getenv("W_COLLAB",        "0.20"))
W_RATING        = float(os.getenv("W_RATING",        "0.10"))
W_CONTEXT       = float(os.getenv("W_CONTEXT",       "0.10"))
W_NEGATIVE      = float(os.getenv("W_NEGATIVE",      "0.22"))
RECOMMEND_OFFERS_TOPN = max(1, min(12, int(os.getenv("RECOMMEND_OFFERS_TOPN", "4"))))
MAX_PER_RESTAURANT = int(os.getenv("MAX_PER_RESTAURANT", "3"))   # diversity cap
EARLY_DIVERSITY_WINDOW = int(os.getenv("EARLY_DIVERSITY_WINDOW", "5"))
EARLY_MAX_PER_RESTAURANT = int(os.getenv("EARLY_MAX_PER_RESTAURANT", "2"))
MULTI_INTEREST_WINDOW = int(os.getenv("MULTI_INTEREST_WINDOW", "4"))
MULTI_INTEREST_MAX_PER_CATEGORY = int(os.getenv("MULTI_INTEREST_MAX_PER_CATEGORY", "2"))
MULTI_INTEREST_MIN_RATIO = float(os.getenv("MULTI_INTEREST_MIN_RATIO", "0.45"))
RECOMMEND_TIMEZONE = os.getenv("RECOMMEND_TIMEZONE", "Africa/Cairo").strip() or "Africa/Cairo"
ENABLE_AB = (os.getenv("RECOMMEND_ENABLE_AB", "0").strip().lower() in {"1", "true", "yes", "on"})
ENABLE_LIVE_COLLAB = (
    os.getenv("RECOMMEND_ENABLE_LIVE_COLLAB", "0").strip().lower() in {"1", "true", "yes", "on"}
)
LIVE_COLLAB_MAX_ORDERS = max(50, min(5000, int(os.getenv("RECOMMEND_LIVE_COLLAB_MAX_ORDERS", "250"))))
COLLAB_TABLE = os.getenv("RECOMMEND_COLLAB_TABLE", "meal_affinities")
ORDER_SIGNAL_WEIGHT = float(os.getenv("ORDER_SIGNAL_WEIGHT", "5.0"))
CART_SIGNAL_WEIGHT = float(os.getenv("CART_SIGNAL_WEIGHT", "2.0"))
LIKE_SIGNAL_WEIGHT = float(os.getenv("LIKE_SIGNAL_WEIGHT", "5.0"))
POSITIVE_RATING_SIGNAL_WEIGHT = float(os.getenv("POSITIVE_RATING_SIGNAL_WEIGHT", "3.0"))
VIEW_SIGNAL_WEIGHT = float(os.getenv("VIEW_SIGNAL_WEIGHT", "0.2"))
NEGATIVE_RATING_SIGNAL_WEIGHT = float(os.getenv("NEGATIVE_RATING_SIGNAL_WEIGHT", "4.0"))
NEGATIVE_HIDE_SIGNAL_WEIGHT = float(os.getenv("NEGATIVE_HIDE_SIGNAL_WEIGHT", "5.0"))
ENABLE_RECOMMEND_LOGS = (
    os.getenv("RECOMMEND_ENABLE_LOGS", "1").strip().lower() in {"1", "true", "yes", "on"}
)
ENFORCE_OPENING_HOURS = (
    os.getenv("RECOMMEND_ENFORCE_OPENING_HOURS", "1").strip().lower() in {"1", "true", "yes", "on"}
)


# ══════════════════════════════════════════════════════════════════════════════
# Utilities
# ══════════════════════════════════════════════════════════════════════════════

def _env_first(*names: str) -> Optional[str]:
    for n in names:
        v = os.getenv(n)
        if isinstance(v, str) and v.strip():
            return v.strip()
    return None


def _log_info(msg: str, *args: Any) -> None:
    if ENABLE_RECOMMEND_LOGS:
        logger.info(msg, *args)


def _get_supabase() -> Client:
    url = _env_first("SUPABASE_URL")
    key = _env_first(
        "SUPABASE_SERVICE_ROLE_KEY", "SUPABASE_ROLE_KEY",
        "SUPABASE_KEY", "SUPABASE_ANON_KEY",
    )
    if not url or not key:
        raise RuntimeError("Supabase env vars missing")
    return create_client(url, key)


def _require_api_key(x_api_key: Optional[str]) -> None:
    expected = _env_first("RECOMMEND_API_KEY")
    if not expected:
        raise HTTPException(status_code=500, detail="RECOMMEND_API_KEY_NOT_SET")
    if (x_api_key or "").strip() != expected:
        raise HTTPException(status_code=401, detail="Unauthorized")


def _parse_iso_dt(value: Any) -> Optional[datetime]:
    if not isinstance(value, str) or not value.strip():
        return None
    s = value.strip()
    try:
        if s.endswith("Z"):
            s = s[:-1] + "+00:00"
        dt = datetime.fromisoformat(s)
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt.astimezone(timezone.utc)
    except Exception:
        return None


def _coerce_int(v: Any, default: int = 0) -> int:
    if isinstance(v, bool):
        return default
    if isinstance(v, int):
        return v
    if isinstance(v, float) and math.isfinite(v):
        return int(v)
    if isinstance(v, str):
        try:
            return int(float(v.strip()))
        except Exception:
            return default
    return default


def _coerce_float(v: Any, default: float = 0.0) -> float:
    if isinstance(v, bool):
        return default
    if isinstance(v, (int, float)) and math.isfinite(float(v)):
        return float(v)
    if isinstance(v, str):
        try:
            return float(v.strip())
        except Exception:
            return default
    return default


def _normalize_weights(weights: Dict[str, float]) -> Dict[str, float]:
    if not weights:
        return {}
    m = max(weights.values())
    if not math.isfinite(m) or m <= 0:
        return {}
    return {k: v / m for k, v in weights.items()}


def _cache_ttl_seconds() -> int:
    raw = _env_first("RECOMMEND_CACHE_TTL_SECONDS")
    v = _coerce_int(raw, default=1800)
    return max(60, min(86400, v))


def _is_missing_table_error(e: Exception) -> bool:
    msg = str(e).lower()
    return "does not exist" in msg and ("relation" in msg or "table" in msg)


def _is_missing_column_error(e: Exception, column_name: str) -> bool:
    msg = str(e).lower()
    col = (column_name or "").strip().lower()
    if not col:
        return False
    return "column" in msg and col in msg and "does not exist" in msg


def _is_on_conflict_constraint_error(e: Exception) -> bool:
    msg = str(e).lower()
    return (
        "42p10" in msg
        or "no unique or exclusion constraint matching the on conflict specification" in msg
        or "on conflict specification" in msg
    )


def _now_utc() -> datetime:
    return datetime.now(timezone.utc)


def _get_local_tz():
    try:
        return ZoneInfo(RECOMMEND_TIMEZONE)
    except Exception:
        return timezone.utc


def _now_local(now_dt: Optional[datetime] = None) -> datetime:
    base = now_dt or _now_utc()
    return base.astimezone(_get_local_tz())


# ══════════════════════════════════════════════════════════════════════════════
# Meal-period detection  (NEW)
# ══════════════════════════════════════════════════════════════════════════════

MEAL_PERIODS = {
    "breakfast":  (5,  11),   # 05:00–10:59
    "lunch":      (11, 15),   # 11:00–14:59
    "afternoon":  (15, 18),   # 15:00–17:59
    "dinner":     (18, 23),   # 18:00–22:59
    "late_night": (23, 5),    # 23:00–04:59 (wraps)
}

PERIOD_CATEGORY_BOOST: Dict[str, Dict[str, float]] = {
    "breakfast":  {"breakfast": 0.20, "bakery": 0.15, "coffee": 0.10},
    "lunch":      {"lunch": 0.15, "sandwiches": 0.10, "salads": 0.10, "fast food": 0.08},
    "afternoon":  {"desserts": 0.15, "coffee": 0.12, "snacks": 0.10},
    "dinner":     {"dinner": 0.12, "grills": 0.10, "pizza": 0.08, "seafood": 0.08},
    "late_night": {"fast food": 0.15, "burgers": 0.12, "pizza": 0.10},
}


def _current_meal_period(now_dt: Optional[datetime] = None) -> str:
    now = _now_local(now_dt)
    h = now.hour
    for period, (start, end) in MEAL_PERIODS.items():
        if start < end:
            if start <= h < end:
                return period
        else:  # wraps midnight
            if h >= start or h < end:
                return period
    return "dinner"


def _period_category_boost(category: Optional[str], period: str) -> float:
    if not isinstance(category, str):
        return 0.0
    cat_lower = category.lower().strip()
    boosts = PERIOD_CATEGORY_BOOST.get(period, {})
    for key, val in boosts.items():
        if key in cat_lower:
            return val
    return 0.0


def _meal_tags(meal: Dict[str, Any]) -> List[str]:
    raw = meal.get("tags")
    out: List[str] = []

    def _collect(value: Any) -> None:
        if isinstance(value, str):
            cleaned = value.strip().lower()
            if cleaned and cleaned not in out:
                out.append(cleaned)
            return
        if isinstance(value, list):
            for item in value:
                _collect(item)

    _collect(raw)
    return out


def _offer_tags(offer: Dict[str, Any]) -> List[str]:
    raw = offer.get("tags")
    out: List[str] = []

    def _collect(value: Any) -> None:
        if isinstance(value, str):
            cleaned = value.strip().lower()
            if cleaned and cleaned not in out:
                out.append(cleaned)
            return
        if isinstance(value, list):
            for item in value:
                _collect(item)

    _collect(raw)
    return out


def _offer_discount_percent(offer: Dict[str, Any]) -> Optional[int]:
    original = _coerce_float(offer.get("original_price"), -1.0)
    current = _coerce_float(offer.get("offer_price"), -1.0)
    if original <= 0 or current < 0 or current > original:
        return None
    return max(0, min(100, int(round(((original - current) / original) * 100.0))))


def _offer_image_url(offer: Dict[str, Any]) -> Optional[str]:
    direct = offer.get("offer_img_url")
    if isinstance(direct, str) and direct.strip():
        return direct.strip()
    meal = offer.get("meals")
    if isinstance(meal, dict):
        linked = meal.get("meal_img_url")
        if isinstance(linked, str) and linked.strip():
            return linked.strip()
    return None


def _offer_title(offer: Dict[str, Any]) -> str:
    title = offer.get("title")
    if isinstance(title, str) and title.strip():
        return title.strip()
    meal = offer.get("meals")
    if isinstance(meal, dict):
        linked = meal.get("title")
        if isinstance(linked, str) and linked.strip():
            return linked.strip()
    return "Offer"


def _offer_description(offer: Dict[str, Any]) -> str:
    description = offer.get("description")
    if isinstance(description, str) and description.strip():
        return description.strip()
    meal = offer.get("meals")
    if isinstance(meal, dict):
        linked = meal.get("description")
        if isinstance(linked, str) and linked.strip():
            return linked.strip()
    return ""


def _fetch_meal_features_by_ids(
    supabase: Client, meal_ids: List[str]
) -> Dict[str, Dict[str, Any]]:
    ids = [m for m in dict.fromkeys(meal_ids) if isinstance(m, str) and m.strip()]
    if not ids:
        return {}
    resp = (
        supabase.table("meals")
        .select("id,restaurant_id,category,cuisine,tags,price")
        .in_("id", ids[:1000])
        .execute()
    )
    rows = getattr(resp, "data", None) or []
    return {
        row["id"]: row
        for row in rows
        if isinstance(row, dict) and isinstance(row.get("id"), str) and row["id"].strip()
    }


# ══════════════════════════════════════════════════════════════════════════════
# Cache  (fine-grained key now includes meal_period)
# ══════════════════════════════════════════════════════════════════════════════

def _cache_key_hash(topn: int, candidate_limit: int, meal_period: str, strategy_hint: str) -> str:
    raw = f"{topn}:{candidate_limit}:{meal_period}:{strategy_hint}"
    return hashlib.sha256(raw.encode()).hexdigest()[:16]


def _fetch_cached_recommendations(
    supabase: Client,
    profile_id: str,
    cache_key: str,
    topn: int,
    candidate_limit: int,
) -> Tuple[Optional[Dict[str, Any]], Optional[str]]:
    now_iso = _now_utc().isoformat()
    try:
        resp = (
            supabase.table(CACHE_TABLE)
            .select("profile_id,cache_key,meal_ids,strategy,generated_at,expires_at")
            .eq("profile_id", profile_id)
            .eq("cache_key", cache_key)
            .gt("expires_at", now_iso)
            .order("generated_at", desc=True)
            .limit(1)
            .execute()
        )
        rows = getattr(resp, "data", None) or []
        if rows:
            return rows[0] if isinstance(rows[0], dict) else None, None
    except Exception as e:
        if _is_missing_table_error(e):
            return None, "table_missing"
        if not _is_missing_column_error(e, "cache_key"):
            return None, "error"

    try:
        resp = (
            supabase.table(CACHE_TABLE)
            .select("profile_id,topn,candidate_limit,meal_ids,strategy,generated_at,expires_at")
            .eq("profile_id", profile_id)
            .eq("topn", topn)
            .eq("candidate_limit", candidate_limit)
            .gt("expires_at", now_iso)
            .order("generated_at", desc=True)
            .limit(1)
            .execute()
        )
        rows = getattr(resp, "data", None) or []
        if not rows:
            return None, None
        return rows[0] if isinstance(rows[0], dict) else None, None
    except Exception as e:
        return None, ("table_missing" if _is_missing_table_error(e) else "error")


def _save_cached_recommendations(
    supabase: Client,
    profile_id: str,
    cache_key: str,
    topn: int,
    candidate_limit: int,
    strategy: str,
    meal_ids: List[str],
) -> Optional[str]:
    ttl = _cache_ttl_seconds()
    now_dt = _now_utc()
    payload = {
        "profile_id": profile_id,
        "cache_key": cache_key,
        "topn": topn,
        "candidate_limit": candidate_limit,
        "strategy": strategy,
        "meal_ids": meal_ids,
        "generated_at": now_dt.isoformat(),
        "expires_at": (now_dt + timedelta(seconds=ttl)).isoformat(),
    }
    try:
        supabase.table(CACHE_TABLE).upsert(
            payload, on_conflict="profile_id,cache_key"
        ).execute()
        return None
    except Exception as e:
        if _is_missing_table_error(e):
            return "table_missing"
        if not (
            _is_missing_column_error(e, "cache_key")
            or _is_on_conflict_constraint_error(e)
        ):
            return "error"

    legacy_payload = {
        "profile_id": profile_id,
        "topn": topn,
        "candidate_limit": candidate_limit,
        "strategy": strategy,
        "meal_ids": meal_ids,
        "generated_at": now_dt.isoformat(),
        "expires_at": (now_dt + timedelta(seconds=ttl)).isoformat(),
    }
    try:
        supabase.table(CACHE_TABLE).upsert(
            legacy_payload, on_conflict="profile_id,topn,candidate_limit"
        ).execute()
        return None
    except Exception as e:
        return "table_missing" if _is_missing_table_error(e) else "error"


def _invalidate_user_cache(supabase: Client, profile_id: str) -> Dict[str, Any]:
    try:
        resp = supabase.table(CACHE_TABLE).delete().eq("profile_id", profile_id).execute()
        rows = getattr(resp, "data", None) or []
        return {"ok": True, "deleted": len(rows)}
    except Exception as e:
        reason = "table_missing" if _is_missing_table_error(e) else "error"
        return {"ok": False, "reason": reason, "detail": str(e)}


# ══════════════════════════════════════════════════════════════════════════════
# Meal fetching
# ══════════════════════════════════════════════════════════════════════════════

_MEAL_SELECT = (
    "id,title,description,price,meal_img_url,category,cuisine,tags,avg_rating,rating_count,"
    "restaurant_id,is_available,quantity,expiry_time,created_at,"
    "restaurants!inner(id,name,img_url,is_active,is_accepting_orders,pause_reason,accepting_orders_updated_at)"
)

_OFFER_SELECT = (
    "id,title,description,offer_img_url,original_price,offer_price,quantity,is_active,"
    "category,cuisine,tags,starts_at,expires_at,created_at,updated_at,restaurant_id,meal_id,"
    "restaurants!inner(id,name,img_url,is_active,is_accepting_orders,pause_reason,accepting_orders_updated_at),"
    "meals(id,title,description,price,meal_img_url,category,cuisine,tags,is_available,quantity,expiry_time,avg_rating,rating_count)"
)


def _is_meal_visible(meal: Dict[str, Any], now_dt: datetime) -> bool:
    category = meal.get("category")
    if not isinstance(category, str) or not category.strip():
        return False
    exp_dt = _parse_iso_dt(meal.get("expiry_time"))
    if exp_dt is not None and exp_dt <= now_dt:
        return False
    qty = meal.get("quantity")
    if qty is not None and _coerce_int(qty, 0) <= 0:
        return False
    return True


def _is_offer_visible(offer: Dict[str, Any], now_dt: datetime) -> bool:
    if offer.get("is_active") is False:
        return False
    starts_dt = _parse_iso_dt(offer.get("starts_at"))
    if starts_dt is not None and starts_dt > now_dt:
        return False
    exp_dt = _parse_iso_dt(offer.get("expires_at"))
    if exp_dt is not None and exp_dt <= now_dt:
        return False
    qty = offer.get("quantity")
    if qty is not None and _coerce_int(qty, 0) <= 0:
        return False
    return True


def _current_local_weekday_and_time(now_dt: Optional[datetime] = None) -> Tuple[int, str]:
    local_now = _now_local(now_dt)
    return local_now.weekday(), local_now.strftime("%H:%M:%S")


def _time_in_window(current_time: str, open_time: Optional[str], close_time: Optional[str]) -> bool:
    if not open_time or not close_time:
        return True
    current = current_time[:8]
    start = str(open_time)[:8]
    end = str(close_time)[:8]
    if start <= end:
        return start <= current <= end
    return current >= start or current <= end


def _fetch_opening_hours_map(
    supabase: Client,
    restaurant_ids: List[str],
    now_dt: Optional[datetime] = None,
) -> Dict[str, List[Dict[str, Any]]]:
    ids = [rid for rid in restaurant_ids if isinstance(rid, str) and rid.strip()]
    if not ids:
        return {}
    weekday, _ = _current_local_weekday_and_time(now_dt)
    try:
        resp = (
            supabase.table("restaurant_opening_hours")
            .select("restaurant_id,day_of_week,open_time,close_time,is_closed")
            .in_("restaurant_id", ids)
            .eq("day_of_week", weekday)
            .execute()
        )
    except Exception:
        return {}

    out: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
    for row in getattr(resp, "data", None) or []:
        rid = row.get("restaurant_id")
        if isinstance(rid, str) and rid.strip():
            out[rid].append(row)
    return dict(out)


def _restaurant_schedule_open_now(
    restaurant_id: str,
    opening_hours_map: Dict[str, List[Dict[str, Any]]],
    now_dt: Optional[datetime] = None,
) -> Optional[bool]:
    rows = opening_hours_map.get(restaurant_id) or []
    if not rows:
        return None
    _, current_time = _current_local_weekday_and_time(now_dt)
    has_open_window = False
    for row in rows:
        if bool(row.get("is_closed")):
            continue
        has_open_window = True
        if _time_in_window(current_time, row.get("open_time"), row.get("close_time")):
            return True
    return False if has_open_window else False


def _compute_restaurant_orderability(
    restaurant: Dict[str, Any],
    opening_hours_map: Dict[str, List[Dict[str, Any]]],
    now_dt: Optional[datetime] = None,
) -> Dict[str, Any]:
    rid = restaurant.get("id")
    is_active = bool(restaurant.get("is_active"))
    is_accepting = bool(restaurant.get("is_accepting_orders"))
    is_open_now = None
    if ENFORCE_OPENING_HOURS and isinstance(rid, str) and rid.strip():
        is_open_now = _restaurant_schedule_open_now(rid, opening_hours_map, now_dt)
    is_orderable_now = is_active and is_accepting and (is_open_now is not False)
    enriched = dict(restaurant)
    enriched["is_open_now"] = is_open_now
    enriched["is_orderable_now"] = is_orderable_now
    return enriched


def _annotate_meals_with_orderability(
    supabase: Client,
    meals: List[Dict[str, Any]],
    now_dt: Optional[datetime] = None,
    *,
    require_orderable: bool,
) -> List[Dict[str, Any]]:
    now_dt = now_dt or _now_utc()
    restaurant_ids = [
        m.get("restaurant_id")
        for m in meals
        if isinstance(m.get("restaurant_id"), str) and m.get("restaurant_id").strip()
    ]
    opening_hours_map = _fetch_opening_hours_map(supabase, restaurant_ids, now_dt)
    enriched_meals: List[Dict[str, Any]] = []
    for meal in meals:
        restaurant = meal.get("restaurants")
        if not isinstance(restaurant, dict):
            continue
        enriched_restaurant = _compute_restaurant_orderability(restaurant, opening_hours_map, now_dt)
        if require_orderable and not enriched_restaurant.get("is_orderable_now"):
            continue
        enriched_meal = dict(meal)
        enriched_meal["restaurants"] = enriched_restaurant
        enriched_meal["is_open_now"] = enriched_restaurant.get("is_open_now")
        enriched_meal["is_orderable_now"] = enriched_restaurant.get("is_orderable_now")
        enriched_meals.append(enriched_meal)
    return enriched_meals


def _annotate_offers_with_orderability(
    supabase: Client,
    offers: List[Dict[str, Any]],
    now_dt: Optional[datetime] = None,
    *,
    require_orderable: bool,
) -> List[Dict[str, Any]]:
    now_dt = now_dt or _now_utc()
    restaurant_ids = [
        o.get("restaurant_id")
        for o in offers
        if isinstance(o.get("restaurant_id"), str) and o.get("restaurant_id").strip()
    ]
    opening_hours_map = _fetch_opening_hours_map(supabase, restaurant_ids, now_dt)
    enriched_offers: List[Dict[str, Any]] = []
    for offer in offers:
        restaurant = offer.get("restaurants")
        if not isinstance(restaurant, dict):
            continue
        enriched_restaurant = _compute_restaurant_orderability(restaurant, opening_hours_map, now_dt)
        if require_orderable and not enriched_restaurant.get("is_orderable_now"):
            continue
        enriched_offer = dict(offer)
        enriched_offer["restaurants"] = enriched_restaurant
        enriched_offer["is_open_now"] = enriched_restaurant.get("is_open_now")
        enriched_offer["is_orderable_now"] = enriched_restaurant.get("is_orderable_now")
        enriched_offers.append(enriched_offer)
    return enriched_offers


def _fetch_visible_meals(supabase: Client, limit: int) -> List[Dict[str, Any]]:
    resp = (
        supabase.table("meals")
        .select(_MEAL_SELECT)
        .eq("restaurants.is_active", True)
        .eq("is_available", True)
        .order("created_at", desc=True)
        .limit(limit)
        .execute()
    )
    now_dt = _now_utc()
    visible = [r for r in (getattr(resp, "data", None) or []) if _is_meal_visible(r, now_dt)]
    return _annotate_meals_with_orderability(
        supabase,
        visible,
        now_dt,
        require_orderable=True,
    )


def _fetch_meals_by_ids_visible(supabase: Client, meal_ids: List[str]) -> List[Dict[str, Any]]:
    ids = [m for m in meal_ids if isinstance(m, str) and m.strip()]
    if not ids:
        return []
    resp = (
        supabase.table("meals")
        .select(_MEAL_SELECT)
        .eq("restaurants.is_active", True)
        .eq("is_available", True)
        .in_("id", ids)
        .execute()
    )
    now_dt = _now_utc()
    by_id = {
        r["id"]: r
        for r in (getattr(resp, "data", None) or [])
        if isinstance(r.get("id"), str) and _is_meal_visible(r, now_dt)
    }
    ordered = [by_id[mid] for mid in ids if mid in by_id]
    return _annotate_meals_with_orderability(
        supabase,
        ordered,
        now_dt,
        require_orderable=True,
    )


def _serialize_offer(offer: Dict[str, Any]) -> Dict[str, Any]:
    meal = offer.get("meals") if isinstance(offer.get("meals"), dict) else {}
    restaurant = offer.get("restaurants") if isinstance(offer.get("restaurants"), dict) else {}
    original_price = _coerce_float(offer.get("original_price"), 0.0)
    offer_price = _coerce_float(offer.get("offer_price"), 0.0)
    return {
        "id": offer.get("id"),
        "item_type": "offer",
        "is_offer": True,
        "offer_id": offer.get("id"),
        "meal_id": offer.get("meal_id"),
        "restaurant_id": offer.get("restaurant_id"),
        "restaurant_name": restaurant.get("name") if isinstance(restaurant.get("name"), str) else None,
        "title": _offer_title(offer),
        "description": _offer_description(offer),
        "image_url": _offer_image_url(offer),
        "offer_img_url": offer.get("offer_img_url"),
        "original_price": round(original_price, 2),
        "offer_price": round(offer_price, 2),
        "price": round(offer_price, 2),
        "discount_percent": _offer_discount_percent(offer),
        "quantity": offer.get("quantity"),
        "category": offer.get("category") or meal.get("category"),
        "cuisine": offer.get("cuisine") or meal.get("cuisine"),
        "tags": offer.get("tags") if isinstance(offer.get("tags"), list) else (meal.get("tags") if isinstance(meal.get("tags"), list) else []),
        "starts_at": offer.get("starts_at"),
        "expires_at": offer.get("expires_at"),
        "created_at": offer.get("created_at"),
        "updated_at": offer.get("updated_at"),
        "is_open_now": offer.get("is_open_now"),
        "is_orderable_now": offer.get("is_orderable_now"),
        "restaurants": restaurant,
        "linked_meal": meal if isinstance(meal, dict) else None,
    }


def _fetch_visible_offers(supabase: Client, limit: int) -> List[Dict[str, Any]]:
    resp = (
        supabase.table("offers")
        .select(_OFFER_SELECT)
        .eq("restaurants.is_active", True)
        .eq("is_active", True)
        .order("created_at", desc=True)
        .limit(limit)
        .execute()
    )
    now_dt = _now_utc()
    visible = [r for r in (getattr(resp, "data", None) or []) if isinstance(r, dict) and _is_offer_visible(r, now_dt)]
    annotated = _annotate_offers_with_orderability(
        supabase,
        visible,
        now_dt,
        require_orderable=True,
    )
    return [_serialize_offer(o) for o in annotated]


def _fetch_offer_features_by_ids(
    supabase: Client,
    offer_ids: List[str],
) -> Dict[str, Dict[str, Any]]:
    ids = [oid for oid in dict.fromkeys(offer_ids) if isinstance(oid, str) and oid.strip()]
    if not ids:
        return {}
    resp = (
        supabase.table("offers")
        .select(_OFFER_SELECT)
        .in_("id", ids[:1000])
        .execute()
    )
    now_dt = _now_utc()
    visible = [r for r in (getattr(resp, "data", None) or []) if isinstance(r, dict) and _is_offer_visible(r, now_dt)]
    annotated = _annotate_offers_with_orderability(
        supabase,
        visible,
        now_dt,
        require_orderable=True,
    )
    return {
        row["id"]: _serialize_offer(row)
        for row in annotated
        if isinstance(row.get("id"), str) and row["id"].strip()
    }


def _fetch_restaurant_base(supabase: Client, restaurant_id: str) -> Optional[Dict[str, Any]]:
    resp = (
        supabase.table("restaurants")
        .select("id,name,img_url,is_active,is_accepting_orders,pause_reason,accepting_orders_updated_at")
        .eq("id", restaurant_id)
        .limit(1)
        .execute()
    )
    rows = getattr(resp, "data", None) or []
    if not rows:
        return None
    row = rows[0]
    return row if isinstance(row, dict) else None


def _fetch_restaurant_opening_hours(
    supabase: Client,
    restaurant_id: str,
) -> List[Dict[str, Any]]:
    try:
        resp = (
            supabase.table("restaurant_opening_hours")
            .select("id,restaurant_id,day_of_week,open_time,close_time,is_closed")
            .eq("restaurant_id", restaurant_id)
            .order("day_of_week")
            .order("open_time")
            .execute()
        )
    except Exception:
        return []
    return [r for r in (getattr(resp, "data", None) or []) if isinstance(r, dict)]


def _restaurant_orderability_payload(
    supabase: Client,
    restaurant_id: str,
    now_dt: Optional[datetime] = None,
) -> Optional[Dict[str, Any]]:
    restaurant = _fetch_restaurant_base(supabase, restaurant_id)
    if not restaurant:
        return None
    now_dt = now_dt or _now_utc()
    opening_hours = _fetch_restaurant_opening_hours(supabase, restaurant_id)
    opening_hours_map = {restaurant_id: opening_hours} if opening_hours else {}
    enriched = _compute_restaurant_orderability(restaurant, opening_hours_map, now_dt)
    return {
        "restaurant": enriched,
        "opening_hours": opening_hours,
        "is_open_now": enriched.get("is_open_now"),
        "is_orderable_now": enriched.get("is_orderable_now"),
    }


def _set_restaurant_accepting_orders(
    supabase: Client,
    restaurant_id: str,
    *,
    is_accepting_orders: bool,
    pause_reason: Optional[str],
) -> Optional[Dict[str, Any]]:
    payload = {
        "is_accepting_orders": bool(is_accepting_orders),
        "pause_reason": (pause_reason or "").strip() or None,
        "accepting_orders_updated_at": _now_utc().isoformat(),
    }
    resp = (
        supabase.table("restaurants")
        .update(payload)
        .eq("id", restaurant_id)
        .execute()
    )
    rows = getattr(resp, "data", None) or []
    if rows:
        row = rows[0]
        return row if isinstance(row, dict) else None
    return _fetch_restaurant_base(supabase, restaurant_id)


def _replace_restaurant_opening_hours(
    supabase: Client,
    restaurant_id: str,
    opening_hours: List[Dict[str, Any]],
) -> int:
    supabase.table("restaurant_opening_hours").delete().eq("restaurant_id", restaurant_id).execute()
    payload: List[Dict[str, Any]] = []
    for row in opening_hours:
        if not isinstance(row, dict):
            continue
        day_of_week = _coerce_int(row.get("day_of_week"), -1)
        if day_of_week < 0 or day_of_week > 6:
            continue
        payload.append(
            {
                "restaurant_id": restaurant_id,
                "day_of_week": day_of_week,
                "open_time": row.get("open_time"),
                "close_time": row.get("close_time"),
                "is_closed": bool(row.get("is_closed")),
            }
        )
    if payload:
        supabase.table("restaurant_opening_hours").insert(payload).execute()
    return len(payload)


# ══════════════════════════════════════════════════════════════════════════════
# Profile helpers
# ══════════════════════════════════════════════════════════════════════════════

def _fetch_profile_id(supabase: Client, firebase_uid: str) -> Optional[str]:
    resp = (
        supabase.table("profiles")
        .select("id")
        .eq("firebase_uid", firebase_uid)
        .limit(1)
        .execute()
    )
    rows = getattr(resp, "data", None) or []
    if not rows:
        return None
    pid = rows[0].get("id")
    return pid if isinstance(pid, str) and pid.strip() else None


# ══════════════════════════════════════════════════════════════════════════════
# Signal ingestion  (EXPANDED)
# ══════════════════════════════════════════════════════════════════════════════

def _fetch_user_signals(
    supabase: Client, profile_id: str
) -> Tuple[Dict[str, float], List[str], Dict[str, float]]:
    """
    Returns (positive_weights_by_meal_id, ordered_hard_exclude_meal_ids, negative_weights_by_meal_id).
    Signal sources and their base weights:
      - Orders          : 5.0 × qty × time-decay(14d half-life)
      - Cart items      : 2.0 × qty  (strong intent)
      - Explicit likes  : 5.0        (table: meal_likes)
      - Ratings ≥ 4     : 3.0        (table: meal_ratings, score 1-5)
      - Recent views    : 0.2 × log(view_count+1)  (table: meal_views)

    Important:
      - Views are a weak preference signal only.
      - Views should not hard-exclude a meal from recommendations by themselves.
    """
    now_dt = _now_utc()
    weights: Dict[str, float] = {}
    negative_weights: Dict[str, float] = {}
    hard_seen: List[str] = []

    def _add(mid: str, w: float, *, hard_exclude: bool = True) -> None:
        if isinstance(mid, str) and mid.strip():
            weights[mid] = weights.get(mid, 0.0) + w
            if hard_exclude:
                hard_seen.append(mid)

    def _add_negative(mid: str, w: float) -> None:
        if isinstance(mid, str) and mid.strip() and w > 0:
            negative_weights[mid] = negative_weights.get(mid, 0.0) + w

    # 1. Cart
    cart_resp = (
        supabase.table("cart_items")
        .select("meal_id,quantity")
        .eq("user_id", profile_id)
        .limit(200)
        .execute()
    )
    for r in getattr(cart_resp, "data", None) or []:
        qty = max(1, min(10, _coerce_int(r.get("quantity"), 1)))
        _add(r.get("meal_id"), CART_SIGNAL_WEIGHT * qty, hard_exclude=True)

    # 2. Orders (with time-decay)
    orders_resp = (
        supabase.table("orders")
        .select("created_at,order_items(meal_id,quantity)")
        .eq("user_id", profile_id)
        .order("created_at", desc=True)
        .limit(50)
        .execute()
    )
    for o in getattr(orders_resp, "data", None) or []:
        created = _parse_iso_dt(o.get("created_at"))
        days = max(0.0, (now_dt - created).total_seconds() / 86400) if created else 0.0
        decay = math.exp(-days / 14.0)
        for it in (o.get("order_items") or []):
            if not isinstance(it, dict):
                continue
            qty = max(1, min(20, _coerce_int(it.get("quantity"), 1)))
            _add(it.get("meal_id"), ORDER_SIGNAL_WEIGHT * qty * decay, hard_exclude=True)

    # 3. Explicit likes  (NEW — requires meal_likes table)
    try:
        likes_resp = (
            supabase.table("meal_likes")
            .select("meal_id")
            .eq("user_id", profile_id)
            .limit(500)
            .execute()
        )
        for r in getattr(likes_resp, "data", None) or []:
            _add(r.get("meal_id"), LIKE_SIGNAL_WEIGHT, hard_exclude=False)
    except Exception:
        pass

    # 4. Ratings — strong positives for high ratings, mild negatives for low ratings
    try:
        ratings_resp = (
            supabase.table("meal_ratings")
            .select("meal_id,rating")
            .eq("user_id", profile_id)
            .limit(500)
            .execute()
        )
        for r in getattr(ratings_resp, "data", None) or []:
            rating = _coerce_float(r.get("rating"), 0.0)
            if rating >= 4:
                _add(
                    r.get("meal_id"),
                    POSITIVE_RATING_SIGNAL_WEIGHT * (rating / 5.0),
                    hard_exclude=False,
                )
            elif rating <= 2:
                _add_negative(
                    r.get("meal_id"),
                    NEGATIVE_RATING_SIGNAL_WEIGHT * max(0.5, (3.0 - rating) / 2.0),
                )
    except Exception:
        pass

    # 5. Recent views  (NEW — requires meal_views table)
    try:
        since_iso = (now_dt - timedelta(days=7)).isoformat()
        views_resp = (
            supabase.table("meal_views")
            .select("meal_id,view_count")
            .eq("user_id", profile_id)
            .gte("last_viewed_at", since_iso)
            .limit(300)
            .execute()
        )
        for r in getattr(views_resp, "data", None) or []:
            vc = max(1, _coerce_int(r.get("view_count"), 1))
            _add(r.get("meal_id"), VIEW_SIGNAL_WEIGHT * math.log(vc + 1), hard_exclude=False)
    except Exception:
        pass

    # 6. Optional explicit hides / dislikes (if the schema supports them)
    for table_name in ("meal_hides", "meal_dislikes"):
        try:
            resp = (
                supabase.table(table_name)
                .select("meal_id")
                .eq("user_id", profile_id)
                .limit(500)
                .execute()
            )
            for r in getattr(resp, "data", None) or []:
                _add_negative(r.get("meal_id"), NEGATIVE_HIDE_SIGNAL_WEIGHT)
        except Exception:
            pass

    hard_seen_dedup = list(dict.fromkeys(m for m in hard_seen if isinstance(m, str) and m.strip()))
    return weights, hard_seen_dedup, negative_weights


def _fetch_user_offer_preferences(
    supabase: Client,
    profile_id: str,
) -> Tuple[Dict[str, float], Dict[str, float], Dict[str, float], Dict[str, float], List[str], float]:
    now_dt = _now_utc()
    offer_signal_weights: Dict[str, float] = {}
    seen_offer_ids: List[str] = []

    def _add_offer_signal(offer_id: Any, weight: float, *, hard_seen: bool) -> None:
        if not isinstance(offer_id, str) or not offer_id.strip() or weight <= 0:
            return
        oid = offer_id.strip()
        offer_signal_weights[oid] = offer_signal_weights.get(oid, 0.0) + weight
        if hard_seen:
            seen_offer_ids.append(oid)

    try:
        cart_resp = (
            supabase.table("cart_items")
            .select("offer_id,item_type,quantity")
            .eq("user_id", profile_id)
            .limit(200)
            .execute()
        )
        for row in getattr(cart_resp, "data", None) or []:
            if not isinstance(row, dict):
                continue
            if (row.get("item_type") != "offer") and not row.get("offer_id"):
                continue
            qty = max(1, min(10, _coerce_int(row.get("quantity"), 1)))
            _add_offer_signal(row.get("offer_id"), CART_SIGNAL_WEIGHT * qty, hard_seen=True)
    except Exception:
        pass

    try:
        orders_resp = (
            supabase.table("orders")
            .select("created_at,order_items(offer_id,item_type,quantity)")
            .eq("user_id", profile_id)
            .order("created_at", desc=True)
            .limit(50)
            .execute()
        )
        for order in getattr(orders_resp, "data", None) or []:
            created = _parse_iso_dt(order.get("created_at"))
            days = max(0.0, (now_dt - created).total_seconds() / 86400) if created else 0.0
            decay = math.exp(-days / 14.0)
            for item in (order.get("order_items") or []):
                if not isinstance(item, dict):
                    continue
                if (item.get("item_type") != "offer") and not item.get("offer_id"):
                    continue
                qty = max(1, min(20, _coerce_int(item.get("quantity"), 1)))
                _add_offer_signal(item.get("offer_id"), ORDER_SIGNAL_WEIGHT * qty * decay, hard_seen=True)
    except Exception:
        pass

    offer_features = _fetch_offer_features_by_ids(supabase, list(offer_signal_weights.keys()))
    restaurant_w: Dict[str, float] = {}
    category_w: Dict[str, float] = {}
    cuisine_w: Dict[str, float] = {}
    tag_w: Dict[str, float] = {}
    for oid, weight in offer_signal_weights.items():
        offer = offer_features.get(oid)
        if not offer:
            continue
        rid = offer.get("restaurant_id")
        if isinstance(rid, str) and rid.strip():
            restaurant_w[rid] = restaurant_w.get(rid, 0.0) + weight
        cat = offer.get("category")
        if isinstance(cat, str) and cat.strip():
            category_w[cat] = category_w.get(cat, 0.0) + weight
        cuisine = offer.get("cuisine")
        if isinstance(cuisine, str) and cuisine.strip():
            cuisine_w[cuisine] = cuisine_w.get(cuisine, 0.0) + weight
        for tag in _offer_tags(offer):
            tag_w[tag] = tag_w.get(tag, 0.0) + weight

    return restaurant_w, category_w, cuisine_w, tag_w, list(dict.fromkeys(seen_offer_ids)), sum(offer_signal_weights.values())


def _compute_value_affinity(
    weights_by_meal: Dict[str, float],
    source_meals_by_id: Dict[str, Dict[str, Any]],
    normalized_tag_w: Dict[str, float],
    seen_offer_ids: List[str],
    offer_signal_total: float,
) -> float:
    budget_pref = max(0.0, min(1.0, normalized_tag_w.get("budget_friendly", 0.0)))

    weighted_price_sum = 0.0
    weight_sum = 0.0
    for meal_id, weight in weights_by_meal.items():
        meal = source_meals_by_id.get(meal_id)
        if not meal:
            continue
        price = _coerce_float(meal.get("price"), 0.0)
        if price <= 0:
            continue
        weighted_price_sum += price * max(0.0, weight)
        weight_sum += max(0.0, weight)
    avg_price = (weighted_price_sum / weight_sum) if weight_sum > 0 else 0.0
    if 0 < avg_price <= 50:
        price_pref = 1.0
    elif 0 < avg_price <= 80:
        price_pref = 0.75
    elif 0 < avg_price <= 120:
        price_pref = 0.45
    elif 0 < avg_price <= 180:
        price_pref = 0.20
    else:
        price_pref = 0.0

    offer_history_pref = min(1.0, (len(seen_offer_ids) * 0.35) + (max(0.0, offer_signal_total) / 12.0))
    return max(0.0, min(1.0, (budget_pref * 0.45) + (price_pref * 0.35) + (offer_history_pref * 0.20)))


# ══════════════════════════════════════════════════════════════════════════════
# Collaborative filtering — co-purchase affinity  (NEW)
# ══════════════════════════════════════════════════════════════════════════════

def _fetch_collab_scores(
    supabase: Client,
    user_meal_ids: List[str],
    candidate_meal_ids: List[str],
    limit_orders: int = LIVE_COLLAB_MAX_ORDERS,
) -> Dict[str, float]:
    """
    Lightweight item-based collaborative filtering:
    For each meal the user has interacted with, find other meals that appear
    in the same orders (co-purchased), then aggregate affinity scores for
    candidate meals.
    """
    if not user_meal_ids or not candidate_meal_ids:
        return {}

    user_set = set(user_meal_ids)
    candidate_set = set(candidate_meal_ids)
    collab_scores: Dict[str, float] = {}

    # Prefer a precomputed affinity table for cheap request-time lookups.
    try:
        resp = (
            supabase.table(COLLAB_TABLE)
            .select("source_meal_id,target_meal_id,score")
            .in_("source_meal_id", list(user_set))
            .limit(max(200, min(5000, len(user_set) * 100)))
            .execute()
        )
        for row in getattr(resp, "data", None) or []:
            if not isinstance(row, dict):
                continue
            target = row.get("target_meal_id")
            if target not in candidate_set:
                continue
            score = max(0.0, _coerce_float(row.get("score"), 0.0))
            if score <= 0:
                continue
            collab_scores[target] = collab_scores.get(target, 0.0) + score
    except Exception as e:
        if not _is_missing_table_error(e):
            collab_scores = {}

    if collab_scores:
        max_co = max(collab_scores.values())
        if max_co > 0:
            return {mid: v / max_co for mid, v in collab_scores.items()}

    # Live collaborative filtering is much heavier, so keep it opt-in.
    if not ENABLE_LIVE_COLLAB:
        return {}

    since_iso = (_now_utc() - timedelta(days=60)).isoformat()
    resp = (
        supabase.table("orders")
        .select("order_items(meal_id)")
        .gte("created_at", since_iso)
        .limit(limit_orders)
        .execute()
    )
    orders = getattr(resp, "data", None) or []
    co_counts: Dict[str, float] = defaultdict(float)

    for o in orders:
        items = o.get("order_items") or []
        if not isinstance(items, list):
            continue
        mids = [it["meal_id"] for it in items if isinstance(it, dict) and isinstance(it.get("meal_id"), str)]
        basket_set = set(mids)
        overlap = basket_set & user_set
        if not overlap:
            continue
        for mid in basket_set & candidate_set:
            co_counts[mid] += len(overlap)

    if not co_counts:
        return {}

    max_co = max(co_counts.values())
    return {mid: v / max_co for mid, v in co_counts.items()}


# ══════════════════════════════════════════════════════════════════════════════
# Popularity baseline
# ══════════════════════════════════════════════════════════════════════════════

def _fetch_popular_meal_ids(supabase: Client, limit_orders: int = 250) -> List[str]:
    since_iso = (_now_utc() - timedelta(days=30)).isoformat()
    resp = (
        supabase.table("orders")
        .select("created_at,order_items(meal_id,quantity)")
        .gte("created_at", since_iso)
        .order("created_at", desc=True)
        .limit(limit_orders)
        .execute()
    )
    scores: Dict[str, float] = {}
    for o in getattr(resp, "data", None) or []:
        for it in (o.get("order_items") or []):
            mid = it.get("meal_id") if isinstance(it, dict) else None
            if not isinstance(mid, str) or not mid.strip():
                continue
            qty = max(1, min(20, _coerce_int(it.get("quantity"), 1)))
            scores[mid] = scores.get(mid, 0.0) + float(qty)
    return [mid for mid, _ in sorted(scores.items(), key=lambda kv: kv[1], reverse=True)]


def _fetch_popular_offer_ids(supabase: Client, limit_orders: int = 250) -> List[str]:
    since_iso = (_now_utc() - timedelta(days=30)).isoformat()
    resp = (
        supabase.table("orders")
        .select("created_at,order_items(offer_id,item_type,quantity)")
        .gte("created_at", since_iso)
        .order("created_at", desc=True)
        .limit(limit_orders)
        .execute()
    )
    scores: Dict[str, float] = {}
    for order in getattr(resp, "data", None) or []:
        for item in (order.get("order_items") or []):
            if not isinstance(item, dict):
                continue
            oid = item.get("offer_id")
            if not isinstance(oid, str) or not oid.strip():
                continue
            qty = max(1, min(20, _coerce_int(item.get("quantity"), 1)))
            scores[oid] = scores.get(oid, 0.0) + float(qty)
    return [oid for oid, _ in sorted(scores.items(), key=lambda kv: kv[1], reverse=True)]


# ══════════════════════════════════════════════════════════════════════════════
# Context boost
# ══════════════════════════════════════════════════════════════════════════════

def _meal_context_boost(meal: Dict[str, Any], now_dt: datetime, period: str) -> float:
    boost = 0.0

    # Price tier bonus
    price = _coerce_float(meal.get("price"), 0.0)
    if 0 < price <= 50:
        boost += 0.05
    elif price <= 100:
        boost += 0.02

    # Urgency from expiry
    exp_dt = _parse_iso_dt(meal.get("expiry_time"))
    if exp_dt is not None:
        hours_left = (exp_dt - now_dt).total_seconds() / 3600.0
        if hours_left <= 0:
            return -1.0
        if hours_left < 6:
            boost += 0.08
        elif hours_left < 12:
            boost += 0.05
        elif hours_left < 24:
            boost += 0.02

    # Meal-period category fit  (NEW)
    boost += _period_category_boost(meal.get("category"), period)

    return boost


def _offer_context_boost(offer: Dict[str, Any], now_dt: datetime, period: str) -> float:
    boost = 0.0
    offer_price = _coerce_float(offer.get("offer_price"), 0.0)
    if 0 < offer_price <= 50:
        boost += 0.06
    elif offer_price <= 100:
        boost += 0.03

    exp_dt = _parse_iso_dt(offer.get("expires_at"))
    if exp_dt is not None:
        hours_left = (exp_dt - now_dt).total_seconds() / 3600.0
        if hours_left <= 0:
            return -1.0
        if hours_left < 6:
            boost += 0.10
        elif hours_left < 12:
            boost += 0.06
        elif hours_left < 24:
            boost += 0.03

    boost += _period_category_boost(offer.get("category"), period)
    return boost


def _offer_quality_score(offer: Dict[str, Any]) -> float:
    linked = offer.get("linked_meal") if isinstance(offer.get("linked_meal"), dict) else {}
    avg = linked.get("avg_rating")
    count = linked.get("rating_count")
    base_quality = 0.0
    if avg is not None or count is not None:
        avg_f = _coerce_float(avg, 0.0)
        count_i = _coerce_int(count, 0)
        if avg_f > 0 and count_i > 0:
            bayesian = (avg_f * count_i + 3.5 * 10) / (count_i + 10)
            base_quality = max(0.0, (bayesian - 3.5) / 1.5)
    discount_norm = (_offer_discount_percent(offer) or 0) / 100.0
    return max(0.0, min(1.0, (base_quality * 0.7) + (discount_norm * 0.3)))


def _recommend_offers_for_profile(
    supabase: Client,
    profile_id: Optional[str],
    topn: int,
    candidate_limit: int,
    now_dt: datetime,
    period: str,
) -> List[Dict[str, Any]]:
    visible_offers = _fetch_visible_offers(supabase, limit=max(candidate_limit, 100))
    if not visible_offers:
        return []

    popular_offer_ids = _fetch_popular_offer_ids(supabase)
    popularity_rank = {oid: idx for idx, oid in enumerate(popular_offer_ids)}
    topn = max(1, min(RECOMMEND_OFFERS_TOPN, topn))

    if not profile_id:
        scored_cold: List[Tuple[float, Dict[str, Any]]] = []
        for offer in visible_offers:
            oid = offer.get("id")
            rank = popularity_rank.get(oid, len(popularity_rank) + 100)
            popularity_score = 1.0 / (1.0 + float(rank))
            quality_score = _offer_quality_score(offer)
            ctx = _offer_context_boost(offer, now_dt, period)
            if ctx < 0:
                continue
            discount_score = (_offer_discount_percent(offer) or 0) / 100.0
            score = (0.55 * popularity_score) + (0.25 * quality_score) + (0.10 * max(0.0, ctx)) + (0.10 * discount_score)
            scored_cold.append((score, offer))
        scored_cold.sort(key=lambda t: t[0], reverse=True)
        return _enforce_diversity(scored_cold, topn, MAX_PER_RESTAURANT)

    weights_by_meal, _, _ = _fetch_user_signals(supabase, profile_id)
    source_meals_by_id = _fetch_meal_features_by_ids(supabase, list(weights_by_meal.keys()))
    restaurant_w: Dict[str, float] = {}
    category_w: Dict[str, float] = {}
    cuisine_w: Dict[str, float] = {}
    tag_w: Dict[str, float] = {}

    for mid, weight in weights_by_meal.items():
        meal = source_meals_by_id.get(mid)
        if not meal:
            continue
        rid = meal.get("restaurant_id")
        if isinstance(rid, str) and rid.strip():
            restaurant_w[rid] = restaurant_w.get(rid, 0.0) + weight
        cat = meal.get("category")
        if isinstance(cat, str) and cat.strip():
            category_w[cat] = category_w.get(cat, 0.0) + weight
        cuisine = meal.get("cuisine")
        if isinstance(cuisine, str) and cuisine.strip():
            cuisine_w[cuisine] = cuisine_w.get(cuisine, 0.0) + weight
        for tag in _meal_tags(meal):
            tag_w[tag] = tag_w.get(tag, 0.0) + weight

    offer_restaurant_w, offer_category_w, offer_cuisine_w, offer_tag_w, seen_offer_ids, offer_signal_total = _fetch_user_offer_preferences(
        supabase, profile_id
    )
    for source, target in (
        (offer_restaurant_w, restaurant_w),
        (offer_category_w, category_w),
        (offer_cuisine_w, cuisine_w),
        (offer_tag_w, tag_w),
    ):
        for key, value in source.items():
            target[key] = target.get(key, 0.0) + value

    restaurant_w = _normalize_weights(restaurant_w)
    category_w = _normalize_weights(category_w)
    cuisine_w = _normalize_weights(cuisine_w)
    tag_w = _normalize_weights(tag_w)
    value_affinity = _compute_value_affinity(
        weights_by_meal,
        source_meals_by_id,
        tag_w,
        seen_offer_ids,
        offer_signal_total,
    )
    category_focus = max(category_w.values(), default=0.0)
    cuisine_focus = max(cuisine_w.values(), default=0.0)
    tag_focus = max(tag_w.values(), default=0.0)
    strong_taxonomy_focus = max(category_focus, cuisine_focus, tag_focus) >= 0.70
    seen_offer_set = set(seen_offer_ids)

    scored: List[Tuple[float, Dict[str, Any]]] = []
    for offer in visible_offers:
        oid = offer.get("id")
        if isinstance(oid, str) and oid in seen_offer_set:
            continue
        rid = offer.get("restaurant_id")
        cat = offer.get("category")
        cuisine = offer.get("cuisine")
        tags = _offer_tags(offer)
        r_score = restaurant_w.get(rid, 0.0) if isinstance(rid, str) else 0.0
        category_score = category_w.get(cat, 0.0) if isinstance(cat, str) else 0.0
        cuisine_score = cuisine_w.get(cuisine, 0.0) if isinstance(cuisine, str) else 0.0
        tag_score = max((tag_w.get(tag, 0.0) for tag in tags), default=0.0)
        taxonomy_score = (0.65 * category_score) + (0.20 * cuisine_score) + (0.15 * tag_score)
        if strong_taxonomy_focus and taxonomy_score < 0.12 and r_score < 0.08:
            continue
        quality_score = _offer_quality_score(offer)
        discount_score = (_offer_discount_percent(offer) or 0) / 100.0
        popularity_rank_value = popularity_rank.get(oid, len(popularity_rank) + 100)
        popularity_score = 1.0 / (1.0 + float(popularity_rank_value))
        ctx = _offer_context_boost(offer, now_dt, period)
        if ctx < 0:
            continue
        relevance_signal = max(r_score, taxonomy_score)
        if relevance_signal < 0.08 and quality_score < 0.20:
            continue
        if value_affinity < 0.25 and taxonomy_score < 0.10 and r_score < 0.08:
            continue
        discount_weight = 0.04 + (0.16 * value_affinity)
        restaurant_weight = 0.22 if value_affinity >= 0.45 else 0.26
        taxonomy_weight = 0.40 if value_affinity >= 0.45 else 0.46
        quality_weight = 0.18 if value_affinity >= 0.45 else 0.20
        popularity_weight = 0.04
        context_weight = 0.08 if value_affinity >= 0.45 else 0.04
        score = (
            (restaurant_weight * r_score)
            + (taxonomy_weight * taxonomy_score)
            + (quality_weight * quality_score)
            + (discount_weight * discount_score)
            + (context_weight * max(0.0, ctx))
            + (popularity_weight * popularity_score)
        )
        scored.append((score, offer))

    scored.sort(key=lambda t: t[0], reverse=True)
    return _enforce_diversity(scored, topn, MAX_PER_RESTAURANT)


# ══════════════════════════════════════════════════════════════════════════════
# Diversity enforcement  (NEW)
# ══════════════════════════════════════════════════════════════════════════════

def _enforce_diversity(
    scored: List[Tuple[float, Dict[str, Any]]],
    topn: int,
    max_per_restaurant: int,
) -> List[Dict[str, Any]]:
    """
    Pick top-N from a scored list with stronger early diversity:
    - the first EARLY_DIVERSITY_WINDOW results allow at most
      EARLY_MAX_PER_RESTAURANT items per restaurant
    - the full list still respects max_per_restaurant first
    - only the final backfill stage ignores caps when necessary
    """
    early_window = max(1, min(topn, EARLY_DIVERSITY_WINDOW))
    early_cap = max(1, min(max_per_restaurant, EARLY_MAX_PER_RESTAURANT))
    restaurant_counts: Dict[str, int] = defaultdict(int)
    early_restaurant_counts: Dict[str, int] = defaultdict(int)
    picked: List[Dict[str, Any]] = []
    leftover: List[Dict[str, Any]] = []

    for _, meal in scored:
        rid = meal.get("restaurant_id") or "__none__"
        in_early_window = len(picked) < early_window
        early_ok = (not in_early_window) or (early_restaurant_counts[rid] < early_cap)
        if (
            len(picked) < topn
            and restaurant_counts[rid] < max_per_restaurant
            and early_ok
        ):
            picked.append(meal)
            restaurant_counts[rid] += 1
            if len(picked) <= early_window:
                early_restaurant_counts[rid] += 1
        else:
            leftover.append(meal)

    for meal in leftover:
        if len(picked) >= topn:
            break
        rid = meal.get("restaurant_id") or "__none__"
        in_early_window = len(picked) < early_window
        early_ok = (not in_early_window) or (early_restaurant_counts[rid] < early_cap)
        if restaurant_counts[rid] < max_per_restaurant and early_ok:
            picked.append(meal)
            restaurant_counts[rid] += 1
            if len(picked) <= early_window:
                early_restaurant_counts[rid] += 1

    for meal in leftover:
        if len(picked) >= topn:
            break
        picked.append(meal)

    return picked[:topn]


def _rebalance_multi_interest(
    scored: List[Tuple[float, Dict[str, Any]]],
    category_w: Dict[str, float],
    topn: int,
) -> List[Tuple[float, Dict[str, Any]]]:
    if len(scored) < 3 or len(category_w) < 2:
        return scored
    ranked_categories = sorted(
        ((cat, w) for cat, w in category_w.items() if w > 0),
        key=lambda kv: kv[1],
        reverse=True,
    )
    if len(ranked_categories) < 2:
        return scored
    primary_weight = ranked_categories[0][1]
    eligible = [
        cat for cat, w in ranked_categories
        if primary_weight > 0 and (w / primary_weight) >= MULTI_INTEREST_MIN_RATIO
    ][:3]
    if len(eligible) < 2:
        return scored

    early_window = max(2, min(topn, MULTI_INTEREST_WINDOW))
    per_category_cap = max(1, MULTI_INTEREST_MAX_PER_CATEGORY)
    grouped: Dict[str, List[Tuple[float, Dict[str, Any]]]] = {cat: [] for cat in eligible}
    remainder: List[Tuple[float, Dict[str, Any]]] = []
    for item in scored:
        meal = item[1]
        cat = meal.get("category")
        if isinstance(cat, str) and cat in grouped:
            grouped[cat].append(item)
        else:
            remainder.append(item)

    if sum(1 for cat in eligible if grouped[cat]) < 2:
        return scored

    picked_ids = set()
    balanced: List[Tuple[float, Dict[str, Any]]] = []
    category_counts: Dict[str, int] = defaultdict(int)

    while len(balanced) < early_window:
        placed = False
        for cat in eligible:
            if category_counts[cat] >= per_category_cap:
                continue
            queue = grouped.get(cat) or []
            while queue:
                item = queue.pop(0)
                meal_id = item[1].get("id")
                if meal_id in picked_ids:
                    continue
                balanced.append(item)
                picked_ids.add(meal_id)
                category_counts[cat] += 1
                placed = True
                break
            if len(balanced) >= early_window:
                break
        if not placed:
            break

    if not balanced:
        return scored

    for item in scored:
        meal_id = item[1].get("id")
        if meal_id in picked_ids:
            continue
        balanced.append(item)
    return balanced


# ══════════════════════════════════════════════════════════════════════════════
# Core recommendation engine
# ══════════════════════════════════════════════════════════════════════════════

def _recommend_for_user(
    supabase: Client,
    firebase_uid: str,
    topn: int,
    candidate_limit: int,
) -> Dict[str, Any]:
    topn = max(1, min(50, _coerce_int(topn, 10)))
    candidate_limit = max(50, min(1000, _coerce_int(candidate_limit, 400)))
    now_dt = _now_utc()
    period = _current_meal_period(now_dt)
    topn_offers = max(1, min(RECOMMEND_OFFERS_TOPN, topn))

    visible_meals = _fetch_visible_meals(supabase, limit=candidate_limit)
    meals_by_id: Dict[str, Dict[str, Any]] = {
        m["id"]: m for m in visible_meals
        if isinstance(m.get("id"), str) and m["id"].strip()
    }
    candidate_ids = list(meals_by_id.keys())

    profile_id = _fetch_profile_id(supabase, firebase_uid)

    # ── Cold-start: no profile ───────────────────────────────────────────────
    if not profile_id:
        popular_ids = _fetch_popular_meal_ids(supabase)
        pool = [meals_by_id[mid] for mid in popular_ids if mid in meals_by_id]
        for m in visible_meals:
            if m not in pool:
                pool.append(m)
        # Still apply context boost + diversity even for cold-start
        scored = []
        for m in pool:
            ctx = _meal_context_boost(m, now_dt, period)
            if ctx < 0:
                continue
            scored.append((ctx, m))
        scored.sort(key=lambda t: t[0], reverse=True)
        picked = _enforce_diversity(scored, topn, MAX_PER_RESTAURANT)
        return {
            "user_id": firebase_uid,
            "strategy": "cold_start_v2",
            "meal_period": period,
            "generated_at": now_dt.isoformat(),
            "recommendations": picked,
            "recommended_offers": _recommend_offers_for_profile(
                supabase,
                None,
                topn=topn_offers,
                candidate_limit=candidate_limit,
                now_dt=now_dt,
                period=period,
            ),
        }

    weights_by_meal, seen_meal_ids, negative_weights_by_meal = _fetch_user_signals(supabase, profile_id)
    source_feature_ids = list(dict.fromkeys(list(weights_by_meal.keys()) + list(negative_weights_by_meal.keys())))
    source_meals_by_id = _fetch_meal_features_by_ids(supabase, source_feature_ids)

    # ── Profile exists but no history ───────────────────────────────────────
    if not weights_by_meal:
        popular_ids = _fetch_popular_meal_ids(supabase)
        pool = [meals_by_id[mid] for mid in popular_ids if mid in meals_by_id]
        for m in visible_meals:
            if m not in pool:
                pool.append(m)
        scored = []
        for m in pool:
            ctx = _meal_context_boost(m, now_dt, period)
            if ctx < 0:
                continue
            scored.append((ctx, m))
        scored.sort(key=lambda t: t[0], reverse=True)
        picked = _enforce_diversity(scored, topn, MAX_PER_RESTAURANT)
        return {
            "user_id": firebase_uid,
            "strategy": "profile_no_history_v2",
            "meal_period": period,
            "generated_at": now_dt.isoformat(),
            "recommendations": picked,
            "recommended_offers": _recommend_offers_for_profile(
                supabase,
                profile_id,
                topn=topn_offers,
                candidate_limit=candidate_limit,
                now_dt=now_dt,
                period=period,
            ),
        }

    # ── Build restaurant + taxonomy preference vectors ───────────────────────
    restaurant_w: Dict[str, float] = {}
    category_w: Dict[str, float] = {}
    cuisine_w: Dict[str, float] = {}
    tag_w: Dict[str, float] = {}
    negative_restaurant_w: Dict[str, float] = {}
    negative_category_w: Dict[str, float] = {}
    negative_cuisine_w: Dict[str, float] = {}
    negative_tag_w: Dict[str, float] = {}
    for mid, w in weights_by_meal.items():
        meal = source_meals_by_id.get(mid)
        if not meal:
            continue
        rid = meal.get("restaurant_id")
        if isinstance(rid, str) and rid.strip():
            restaurant_w[rid] = restaurant_w.get(rid, 0.0) + w
        cat = meal.get("category")
        if isinstance(cat, str) and cat.strip():
            category_w[cat] = category_w.get(cat, 0.0) + w
        cuisine = meal.get("cuisine")
        if isinstance(cuisine, str) and cuisine.strip():
            cuisine_w[cuisine] = cuisine_w.get(cuisine, 0.0) + w
        for tag in _meal_tags(meal):
            tag_w[tag] = tag_w.get(tag, 0.0) + w

    for mid, w in negative_weights_by_meal.items():
        meal = source_meals_by_id.get(mid)
        if not meal:
            continue
        rid = meal.get("restaurant_id")
        if isinstance(rid, str) and rid.strip():
            negative_restaurant_w[rid] = negative_restaurant_w.get(rid, 0.0) + w
        cat = meal.get("category")
        if isinstance(cat, str) and cat.strip():
            negative_category_w[cat] = negative_category_w.get(cat, 0.0) + w
        cuisine = meal.get("cuisine")
        if isinstance(cuisine, str) and cuisine.strip():
            negative_cuisine_w[cuisine] = negative_cuisine_w.get(cuisine, 0.0) + w
        for tag in _meal_tags(meal):
            negative_tag_w[tag] = negative_tag_w.get(tag, 0.0) + w

    restaurant_w = _normalize_weights(restaurant_w)
    category_w = _normalize_weights(category_w)
    cuisine_w = _normalize_weights(cuisine_w)
    tag_w = _normalize_weights(tag_w)
    negative_restaurant_w = _normalize_weights(negative_restaurant_w)
    negative_category_w = _normalize_weights(negative_category_w)
    negative_cuisine_w = _normalize_weights(negative_cuisine_w)
    negative_tag_w = _normalize_weights(negative_tag_w)
    category_focus = max(category_w.values(), default=0.0)
    cuisine_focus = max(cuisine_w.values(), default=0.0)
    tag_focus = max(tag_w.values(), default=0.0)
    taxonomy_focus = max(category_focus, cuisine_focus, tag_focus)
    strong_taxonomy_focus = taxonomy_focus >= 0.70

    # ── Collaborative filtering scores ───────────────────────────────────────
    user_meal_ids = list(weights_by_meal.keys())
    collab_scores = _fetch_collab_scores(supabase, user_meal_ids, candidate_ids)

    # ── Aggregate rating signals per meal ────────────────────────────────────
    # (ratings stored in meals table as avg_rating; fall back to 0)
    def _meal_rating_score(meal: Dict[str, Any]) -> float:
        avg = _coerce_float(meal.get("avg_rating"), 0.0)
        count = _coerce_int(meal.get("rating_count"), 0)
        if avg <= 0 or count == 0:
            return 0.0
        # Bayesian average: blend toward 3.5 global prior with weight 10
        bayesian = (avg * count + 3.5 * 10) / (count + 10)
        return max(0.0, (bayesian - 3.5) / 1.5)  # normalize to [0, 1] approx

    # ── Score + filter candidates ─────────────────────────────────────────────
    seen_set = set(seen_meal_ids)
    scored: List[Tuple[float, Dict[str, Any]]] = []

    for m in visible_meals:
        mid = m.get("id")
        if not isinstance(mid, str) or not mid.strip():
            continue
        if mid in seen_set:
            continue

        rid = m.get("restaurant_id")
        cat = m.get("category")
        cuisine = m.get("cuisine")
        tags = _meal_tags(m)

        r_score = restaurant_w.get(rid, 0.0) if isinstance(rid, str) else 0.0
        category_score = category_w.get(cat, 0.0) if isinstance(cat, str) else 0.0
        cuisine_score = cuisine_w.get(cuisine, 0.0) if isinstance(cuisine, str) else 0.0
        tag_score = max((tag_w.get(tag, 0.0) for tag in tags), default=0.0)
        negative_category_score = negative_category_w.get(cat, 0.0) if isinstance(cat, str) else 0.0
        negative_cuisine_score = negative_cuisine_w.get(cuisine, 0.0) if isinstance(cuisine, str) else 0.0
        negative_tag_score = max((negative_tag_w.get(tag, 0.0) for tag in tags), default=0.0)
        negative_restaurant_score = negative_restaurant_w.get(rid, 0.0) if isinstance(rid, str) else 0.0
        c_score = (0.65 * category_score) + (0.20 * cuisine_score) + (0.15 * tag_score)
        negative_score = (
            0.55 * negative_category_score
            + 0.20 * negative_cuisine_score
            + 0.15 * negative_tag_score
            + 0.10 * negative_restaurant_score
        )
        col_score = collab_scores.get(mid, 0.0)
        rating_score = _meal_rating_score(m)
        ctx = _meal_context_boost(m, now_dt, period)
        if ctx < 0:
            continue

        # When the user shows a clear taxonomy preference (for example pizza/italian),
        # prefer category/cuisine/tag matches over merely being from the same restaurant.
        restaurant_weight = W_RESTAURANT * (0.40 if strong_taxonomy_focus else 0.85)
        taxonomy_weight = W_CATEGORY * (1.35 if strong_taxonomy_focus else 1.0)
        exact_match_bonus = 0.0
        if category_score > 0:
            exact_match_bonus += 0.20 * category_score
        if cuisine_score > 0:
            exact_match_bonus += 0.12 * cuisine_score
        if tag_score > 0:
            exact_match_bonus += 0.08 * tag_score

        mismatch_penalty = 0.0
        has_category = isinstance(cat, str) and bool(cat.strip())
        has_cuisine = isinstance(cuisine, str) and bool(cuisine.strip())
        taxonomy_parts = int(has_category) + int(has_cuisine) + int(bool(tags))
        taxonomy_coverage = taxonomy_parts / 3.0
        if strong_taxonomy_focus and c_score < 0.18 and col_score < 0.08:
            continue
        if strong_taxonomy_focus and c_score <= 0 and col_score <= 0:
            mismatch_penalty += 0.18
        if strong_taxonomy_focus and taxonomy_coverage == 0:
            mismatch_penalty += 0.14
        elif strong_taxonomy_focus and taxonomy_coverage <= (1.0 / 3.0):
            mismatch_penalty += 0.08
        elif taxonomy_coverage == 0:
            mismatch_penalty += 0.03
        if negative_score >= 0.55 and c_score <= 0.10 and col_score < 0.12:
            continue

        score = (
            restaurant_weight * r_score
            + taxonomy_weight * c_score
            + W_COLLAB    * col_score
            + W_RATING    * rating_score
            + W_CONTEXT   * max(0.0, ctx)
            + exact_match_bonus
            - (W_NEGATIVE * negative_score)
            - mismatch_penalty
        )
        scored.append((score, m))

    scored.sort(key=lambda t: t[0], reverse=True)
    scored = _rebalance_multi_interest(scored, category_w, topn)

    # ── Diversity-aware selection ─────────────────────────────────────────────
    picked = _enforce_diversity(scored, topn, MAX_PER_RESTAURANT)

    # ── Backfill if needed ────────────────────────────────────────────────────
    if len(picked) < topn:
        picked_ids = {m.get("id") for m in picked}
        for m in visible_meals:
            if len(picked) >= topn:
                break
            mid = m.get("id")
            if mid in seen_set or mid in picked_ids:
                continue
            cat = m.get("category")
            cuisine = m.get("cuisine")
            tags = _meal_tags(m)
            category_score = category_w.get(cat, 0.0) if isinstance(cat, str) else 0.0
            cuisine_score = cuisine_w.get(cuisine, 0.0) if isinstance(cuisine, str) else 0.0
            tag_score = max((tag_w.get(tag, 0.0) for tag in tags), default=0.0)
            fallback_similarity = (0.65 * category_score) + (0.20 * cuisine_score) + (0.15 * tag_score)
            fallback_collab = collab_scores.get(mid, 0.0)
            if strong_taxonomy_focus and fallback_similarity < 0.12 and fallback_collab < 0.08:
                continue
            if fallback_similarity <= 0 and fallback_collab <= 0 and not tags:
                continue
            if (
                not isinstance(cat, str)
                and not isinstance(cuisine, str)
                and not tags
            ):
                continue
            if mid not in seen_set and mid not in picked_ids:
                picked.append(m)
                picked_ids.add(mid)

    return {
        "user_id": firebase_uid,
        "strategy": "hybrid_rules_v2",
        "meal_period": period,
        "generated_at": now_dt.isoformat(),
        "recommendations": picked[:topn],
        "recommended_offers": _recommend_offers_for_profile(
            supabase,
            profile_id,
            topn=topn_offers,
            candidate_limit=candidate_limit,
            now_dt=now_dt,
            period=period,
        ),
    }


# ══════════════════════════════════════════════════════════════════════════════
# Cached wrapper
# ══════════════════════════════════════════════════════════════════════════════

def _recommend_for_user_cached(
    supabase: Client,
    firebase_uid: str,
    topn: int,
    candidate_limit: int,
    strategy_hint: str = "default",
) -> Dict[str, Any]:
    topn = max(1, min(50, _coerce_int(topn, 10)))
    candidate_limit = max(50, min(1000, _coerce_int(candidate_limit, 400)))
    now_dt = _now_utc()
    period = _current_meal_period(now_dt)

    profile_id = _fetch_profile_id(supabase, firebase_uid)
    cache_key = _cache_key_hash(topn, candidate_limit, period, strategy_hint)
    cache_meta: Dict[str, Any] = {"enabled": True, "ttl_seconds": _cache_ttl_seconds()}

    if profile_id:
        cached_row, cache_err = _fetch_cached_recommendations(
            supabase,
            profile_id,
            cache_key,
            topn,
            candidate_limit,
        )
        if cached_row:
            raw_ids = cached_row.get("meal_ids")
            ids = raw_ids if isinstance(raw_ids, list) else []
            cached_meals = _fetch_meals_by_ids_visible(supabase, ids)
            if cached_meals:
                cache_meta.update({"hit": True})
                _log_info(
                    "recommend cache_hit user=%s profile=%s topn=%s candidate_limit=%s recs=%s",
                    firebase_uid,
                    profile_id,
                    topn,
                    candidate_limit,
                    len(cached_meals[:topn]),
                )
                return {
                    "user_id": firebase_uid,
                    "strategy": cached_row.get("strategy") or "cache",
                    "meal_period": period,
                    "generated_at": cached_row.get("generated_at") or now_dt.isoformat(),
                    "cached": True,
                    "cache": cache_meta,
                    "recommendations": cached_meals[:topn],
                    "recommended_offers": _recommend_offers_for_profile(
                        supabase,
                        profile_id,
                        topn=max(1, min(RECOMMEND_OFFERS_TOPN, topn)),
                        candidate_limit=candidate_limit,
                        now_dt=now_dt,
                        period=period,
                    ),
                }
        if cache_err:
            cache_meta.update({"enabled": False, "reason": cache_err})

    result = _recommend_for_user(supabase, firebase_uid, topn=topn, candidate_limit=candidate_limit)
    recs = result.get("recommendations") if isinstance(result, dict) else None
    meal_ids = [
        r["id"] for r in (recs or [])
        if isinstance(r, dict) and isinstance(r.get("id"), str) and r["id"].strip()
    ]

    if profile_id and cache_meta.get("enabled") is True and meal_ids:
        save_err = _save_cached_recommendations(
            supabase,
            profile_id=profile_id,
            cache_key=cache_key,
            topn=topn,
            candidate_limit=candidate_limit,
            strategy=str(result.get("strategy") or "computed"),
            meal_ids=meal_ids,
        )
        if save_err:
            cache_meta.update({"enabled": False, "reason": save_err})
        else:
            cache_meta.update({"hit": False, "saved": True})
            _log_info(
                "recommend cache_saved user=%s profile=%s topn=%s candidate_limit=%s recs=%s",
                firebase_uid,
                profile_id,
                topn,
                candidate_limit,
                len(meal_ids),
            )

    result["cached"] = False
    result["cache"] = cache_meta
    _log_info(
        "recommend computed user=%s topn=%s candidate_limit=%s cached=%s recs=%s",
        firebase_uid,
        topn,
        candidate_limit,
        False,
        len(result.get("recommendations") or []),
    )
    return result


# ══════════════════════════════════════════════════════════════════════════════
# A/B routing stub  (NEW)
# ══════════════════════════════════════════════════════════════════════════════

def _ab_strategy(firebase_uid: str) -> str:
    """
    Deterministically bucket user into an A/B group based on UID hash.
    Add new strategies here without touching the main pipeline.
    """
    if not ENABLE_AB:
        return "default"
    bucket = int(hashlib.md5(firebase_uid.encode()).hexdigest(), 16) % 100
    if bucket < 50:
        return "default"
    return "collab_heavy"   # placeholder for a future ML model variant


# ══════════════════════════════════════════════════════════════════════════════
# API endpoints
# ══════════════════════════════════════════════════════════════════════════════

@app.get("/")
def root() -> Dict[str, str]:
    return {"message": "Food Recommendation API v2"}


@app.get("/health")
def health() -> Dict[str, Any]:
    try:
        _get_supabase()
    except Exception as e:
        return {"status": "ERROR", "error": str(e)}
    return {
        "status": "OK",
        "meal_period": _current_meal_period(),
        "enforce_opening_hours": ENFORCE_OPENING_HOURS,
    }


@app.get("/recommend")
def recommend(
    user_id: str = Query(...),
    topn: int = Query(10),
    candidate_limit: int = Query(400),
    use_cache: int = Query(1),
    x_api_key: Optional[str] = Header(None),
) -> Dict[str, Any]:
    _require_api_key(x_api_key)
    uid = (user_id or "").strip()
    if not uid:
        raise HTTPException(status_code=400, detail="user_id is required")
    try:
        supabase = _get_supabase()
        strategy_hint = _ab_strategy(uid)
        if _coerce_int(use_cache, 1) == 1:
            return _recommend_for_user_cached(
                supabase, uid, topn=topn,
                candidate_limit=candidate_limit,
                strategy_hint=strategy_hint,
            )
        out = _recommend_for_user(supabase, uid, topn=topn, candidate_limit=candidate_limit)
        out["cached"] = False
        out["cache"] = {"enabled": False, "reason": "disabled_by_caller"}
        return out
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/recommend/{user_id}")
def recommend_path(
    user_id: str,
    topn: int = Query(10),
    candidate_limit: int = Query(400),
    x_api_key: Optional[str] = Header(None),
) -> Dict[str, Any]:
    return recommend(
        user_id=user_id, topn=topn,
        candidate_limit=candidate_limit,
        x_api_key=x_api_key,
    )


@app.post("/recommend/cache/invalidate/{user_id}")
def invalidate_recommendation_cache(
    user_id: str,
    x_api_key: Optional[str] = Header(None),
) -> Dict[str, Any]:
    _require_api_key(x_api_key)
    uid = (user_id or "").strip()
    if not uid:
        raise HTTPException(status_code=400, detail="user_id is required")
    try:
        supabase = _get_supabase()
        profile_id = _fetch_profile_id(supabase, uid)
        if not profile_id:
            return {"ok": True, "user_id": uid, "invalidated": False, "reason": "profile_not_found"}
        result = _invalidate_user_cache(supabase, profile_id)
        if not result.get("ok"):
            raise HTTPException(status_code=500, detail=result.get("detail") or result.get("reason") or "cache_invalidation_failed")
        _log_info(
            "recommend cache_invalidated user=%s profile=%s deleted=%s",
            uid,
            profile_id,
            result.get("deleted", 0),
        )
        return {
            "ok": True,
            "user_id": uid,
            "profile_id": profile_id,
            "invalidated": True,
            "deleted_rows": result.get("deleted", 0),
        }
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/restaurants/{restaurant_id}/orderability")
def restaurant_orderability(
    restaurant_id: str,
    x_api_key: Optional[str] = Header(None),
) -> Dict[str, Any]:
    _require_api_key(x_api_key)
    rid = (restaurant_id or "").strip()
    if not rid:
        raise HTTPException(status_code=400, detail="restaurant_id is required")
    try:
        supabase = _get_supabase()
        payload = _restaurant_orderability_payload(supabase, rid)
        if not payload:
            raise HTTPException(status_code=404, detail="restaurant_not_found")
        return payload
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/restaurants/{restaurant_id}/pause-ordering")
def pause_restaurant_ordering(
    restaurant_id: str,
    pause_reason: Optional[str] = Body(default=None),
    x_api_key: Optional[str] = Header(None),
) -> Dict[str, Any]:
    _require_api_key(x_api_key)
    rid = (restaurant_id or "").strip()
    if not rid:
        raise HTTPException(status_code=400, detail="restaurant_id is required")
    try:
        supabase = _get_supabase()
        row = _set_restaurant_accepting_orders(
            supabase,
            rid,
            is_accepting_orders=False,
            pause_reason=pause_reason,
        )
        if not row:
            raise HTTPException(status_code=404, detail="restaurant_not_found")
        payload = _restaurant_orderability_payload(supabase, rid)
        if not payload:
            raise HTTPException(status_code=404, detail="restaurant_not_found")
        return payload
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/restaurants/{restaurant_id}/resume-ordering")
def resume_restaurant_ordering(
    restaurant_id: str,
    x_api_key: Optional[str] = Header(None),
) -> Dict[str, Any]:
    _require_api_key(x_api_key)
    rid = (restaurant_id or "").strip()
    if not rid:
        raise HTTPException(status_code=400, detail="restaurant_id is required")
    try:
        supabase = _get_supabase()
        row = _set_restaurant_accepting_orders(
            supabase,
            rid,
            is_accepting_orders=True,
            pause_reason=None,
        )
        if not row:
            raise HTTPException(status_code=404, detail="restaurant_not_found")
        payload = _restaurant_orderability_payload(supabase, rid)
        if not payload:
            raise HTTPException(status_code=404, detail="restaurant_not_found")
        return payload
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.put("/restaurants/{restaurant_id}/opening-hours")
def update_restaurant_opening_hours(
    restaurant_id: str,
    opening_hours: List[Dict[str, Any]] = Body(...),
    x_api_key: Optional[str] = Header(None),
) -> Dict[str, Any]:
    _require_api_key(x_api_key)
    rid = (restaurant_id or "").strip()
    if not rid:
        raise HTTPException(status_code=400, detail="restaurant_id is required")
    if not isinstance(opening_hours, list):
        raise HTTPException(status_code=400, detail="opening_hours must be a list")
    try:
        supabase = _get_supabase()
        base = _fetch_restaurant_base(supabase, rid)
        if not base:
            raise HTTPException(status_code=404, detail="restaurant_not_found")
        updated_count = _replace_restaurant_opening_hours(supabase, rid, opening_hours)
        payload = _restaurant_orderability_payload(supabase, rid)
        if not payload:
            raise HTTPException(status_code=404, detail="restaurant_not_found")
        payload["updated_rows"] = updated_count
        return payload
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
